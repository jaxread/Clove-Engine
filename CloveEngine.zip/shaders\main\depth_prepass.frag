#version 450
#extension GL_EXT_nonuniform_qualifier : enable

// Companion to depth_prepass.vert -- see its comment. Alpha-testing is the
// original part of this fragment shader: OPAQUE materials need no fragment
// work at all, but MASK (and BLEND materials forced to MASK via
// GraphicsSettingsUI's "Force Alpha-Test for BLEND materials" toggle -- see
// forceMaskForBlend()'s comment, VulkanApp.h) alpha-test by discarding below
// their cutoff. Skipping that here would let a foliage/fence card's
// fully-transparent regions write full-quad depth, permanently occluding
// whatever's behind them once pass 1 (VulkanRender.cpp) starts testing with
// EQUAL and stops writing depth of its own. So this fragment shader mirrors
// shader.frag's exact alpha-test logic for OPAQUE/MASK/forced-MASK.
//
// Phase 2 (clustered-deferred conversion, see
// CLUSTERED_DEFERRED_PHASES_2-5.md): this pass now also samples the full
// material -- base color, normal map, metallic-roughness, occlusion,
// emissive -- and writes it all to the G-buffer for the Phase 3 deferred
// lighting pass to shade from, instead of just alpha-testing and writing
// the vertex normal. roughnessFloor/geometric-specular-AA clamping is
// deliberately NOT applied here -- this pass only has a truncated UBO
// prefix (see below), and the deferred lighting pass has the full UBO
// anyway, so it applies those the same way shader.frag used to.
layout(location = 2) in vec2 fragUV;
layout(location = 4) flat in int fragMaterialIndex;
layout(location = 5) in vec4 fragColor;
layout(location = 6) in vec2 fragUV2;
layout(location = 7) in vec3 fragViewNormal;
layout(location = 8) in float fragViewPosZ;
layout(location = 9) in vec4 fragViewTangent;

// View-space normal G-buffer (post normal-mapping as of Phase 2) -- SSAO's
// input (see shaders/ssao.frag) and the deferred lighting pass' shading
// normal. Alpha carries linear viewZ, piggybacking on a channel nothing
// else reads.
layout(location = 0) out vec4 outNormal;
// RGB = baseColor.rgb, A = glTF occlusion (1.0 if the material has none).
layout(location = 1) out vec4 outAlbedo;
// R = metallic, G = roughness -- both already resolved against the
// material's factors (unclamped, see this file's top comment).
layout(location = 2) out vec2 outMetallicRoughness;
// RGB = emissiveFactor * emissive texture (HDR). A = material.doubleSided
// (1.0/0.0) -- piggybacks on an otherwise-unused channel so the deferred
// lighting pass (deferred_lighting.frag) can reproduce shader.frag's
// foliage-translucency wrap term, which is gated on doubleSided.
layout(location = 3) out vec4 outEmissive;

// Prefix of shader.frag's UniformBufferObject up through forceMaskForBlend --
// lightViewProj (the one field after it) isn't needed here, so it's left off
// rather than declared and unused.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;
    vec3 lightColor;
    vec4 ambientColorIntensity;
    int forceMaskForBlend;
} ubo;

layout(binding = 4) uniform sampler2D bindlessTextures[];

// Mirrors GpuMaterial in VulkanApp.h field-for-field -- identical to
// shader.frag's Material struct, see its comment there.
struct Material {
    vec4 baseColorFactor;
    vec4 emissiveFactor;
    int baseColorTexture;
    int metallicRoughnessTexture;
    int normalTexture;
    int occlusionTexture;
    int emissiveTexture;
    float metallicFactor;
    float roughnessFactor;
    float normalScale;
    float occlusionStrength;
    float alphaCutoff;
    int alphaMode; // 0 = OPAQUE, 1 = MASK, 2 = BLEND
    int doubleSided;
    int texCoordSets;
    int _pad0;
    int _pad1;
    int _pad2;
};

layout(std430, binding = 1) readonly buffer MaterialBuffer {
    Material materials[];
} materialBuffer;

const float kZeroAlphaEpsilon = 0.02;

// Identical to shader.frag's texCoordFor() -- see its comment there.
vec2 texCoordFor(int texCoordSets, int bit) {
    return ((texCoordSets & bit) != 0) ? fragUV2 : fragUV;
}

// Identical to shader.frag's frontFacingSign() -- see its comment there.
float frontFacingSign() {
    return gl_FrontFacing ? 1.0 : -1.0;
}

void main() {
    // No glTF material at all -- shader.frag's unlitMaterialFallback() does
    // no alpha testing in this case either, so this instance always covers
    // every fragment it rasterizes. Approximated in the G-buffer as a flat
    // dielectric (metallic 0, fully rough, no emissive) using the vertex
    // color as albedo -- the deferred lighting pass then shades it with the
    // same standard PBR path as everything else, rather than
    // unlitMaterialFallback()'s bespoke diffuse-only term. This is a rare
    // debug-content path (meshes with no glTF material at all), so the
    // slightly different look here is an acceptable simplification.
    if (fragMaterialIndex < 0) {
        outNormal = vec4(normalize(fragViewNormal), fragViewPosZ);
        outAlbedo = vec4(fragColor.rgb, 1.0);
        outMetallicRoughness = vec2(0.0, 1.0);
        outEmissive = vec4(0.0, 0.0, 0.0, 0.0);
        return;
    }

    Material mat = materialBuffer.materials[fragMaterialIndex];

    // glTF spec: COLOR_0 multiplies into baseColor alongside baseColorFactor
    // and the base color texture -- same as shader.frag.
    vec4 baseColor = mat.baseColorFactor * fragColor;
    if (mat.baseColorTexture >= 0) {
        baseColor *= texture(bindlessTextures[nonuniformEXT(mat.baseColorTexture)], texCoordFor(mat.texCoordSets, 1));
    }

    if (baseColor.a < kZeroAlphaEpsilon) {
        discard;
    }

    if (mat.alphaMode == 1) { // MASK
        if (baseColor.a < mat.alphaCutoff) {
            discard;
        }
    } else if (mat.alphaMode == 2) { // BLEND, only reachable here when forced to MASK
        if (ubo.forceMaskForBlend != 0) {
            float cutoff = mat.alphaCutoff > 0.0 ? mat.alphaCutoff : 0.5;
            if (baseColor.a < cutoff) {
                discard;
            }
        }
    }
    // alphaMode == 0 (OPAQUE): no cutoff test, matches shader.frag.

    // Normal mapping, entirely in view space -- see fragViewTangent's own
    // comment (depth_prepass.vert) for why this is safe without a
    // world-space detour. Mirrors shader.frag's identical TBN construction.
    vec3 faceNormal = normalize(fragViewNormal) * frontFacingSign();
    vec3 N = faceNormal;
    if (mat.normalTexture >= 0 && dot(fragViewTangent.xyz, fragViewTangent.xyz) > 1e-8) {
        vec3 T = normalize(fragViewTangent.xyz - N * dot(fragViewTangent.xyz, N));
        vec3 B = cross(N, T) * (fragViewTangent.w * frontFacingSign());
        mat3 TBN = mat3(T, B, N);
        vec3 sampledN = texture(bindlessTextures[nonuniformEXT(mat.normalTexture)], texCoordFor(mat.texCoordSets, 4)).rgb * 2.0 - 1.0;
        sampledN.xy *= mat.normalScale;
        N = normalize(TBN * normalize(sampledN));
    }
    outNormal = vec4(N, fragViewPosZ);

    float metallic = mat.metallicFactor;
    float roughness = mat.roughnessFactor;
    if (mat.metallicRoughnessTexture >= 0) {
        // glTF packs this as (unused, roughness, metallic) in the G/B
        // channels -- a linear (non-sRGB) texture, see TextureData::isSRGB.
        vec3 mr = texture(bindlessTextures[nonuniformEXT(mat.metallicRoughnessTexture)], texCoordFor(mat.texCoordSets, 2)).rgb;
        roughness = mr.g * mat.roughnessFactor;
        metallic = mr.b * mat.metallicFactor;
    }
    outMetallicRoughness = vec2(clamp(metallic, 0.0, 1.0), clamp(roughness, 0.0, 1.0));

    float occlusion = 1.0;
    if (mat.occlusionTexture >= 0) {
        float ao = texture(bindlessTextures[nonuniformEXT(mat.occlusionTexture)], texCoordFor(mat.texCoordSets, 8)).r;
        occlusion = mix(1.0, ao, mat.occlusionStrength);
    }
    outAlbedo = vec4(baseColor.rgb, occlusion);

    vec3 emissive = mat.emissiveFactor.rgb;
    if (mat.emissiveTexture >= 0) {
        emissive *= texture(bindlessTextures[nonuniformEXT(mat.emissiveTexture)], texCoordFor(mat.texCoordSets, 16)).rgb;
    }
    outEmissive = vec4(emissive, mat.doubleSided != 0 ? 1.0 : 0.0);
}
