#version 450

// Screen-space ambient occlusion -- runs right after the depth (+ normal)
// pre-pass (recordCommandBuffer's "SSAO pass"), before pass 1's shading
// needs to sample the (blurred) result. Standard hemisphere-kernel
// technique: reconstructs each fragment's view-space position from depth
// (see SsaoUbo's own binding comment below for why via ssaoUbo.invProj,
// computed once per frame on the CPU, rather than a separate position
// G-buffer), builds a per-pixel-rotated TBN basis around the view-space
// normal (depth_prepass.vert/.frag's new output), and tests kKernelSize
// sample points against the same depth buffer for occluders. Output is a single
// scalar in [0,1] (1 = fully lit, 0 = fully occluded) written into a color
// attachment; blur.frag then smooths the result (see createSSAOResources'
// comment, VulkanApp.h) before shader.frag/shader_oit.frag ever sample it.
// Vertex stage is oit_composite.vert, same fullscreen-triangle reuse as
// tonemap.frag/blur.frag/bloom_threshold.frag.
layout(location = 0) in vec2 fragUV;

layout(location = 0) out vec4 outColor;

layout(binding = 0) uniform sampler2D depthBuffer;
layout(binding = 1) uniform sampler2D normalBuffer;
// Small (4x4) tiled texture of random unit vectors in the XY plane --
// rotates the hemisphere kernel differently per pixel so the fixed,
// low-sample-count kernel doesn't produce banding artifacts. REPEAT wrap
// tiles it across the whole screen (see createSSAOResources, VulkanResources.cpp).
layout(binding = 2) uniform sampler2D noiseTexture;
// proj + its inverse, both frame-constant -- a UBO rather than push
// constants (PushConstants below already uses its own block; two mat4s on
// top of that would exceed the spec's guaranteed-minimum 128-byte push
// constant budget, see SsaoPushConstants' own comment, VulkanTypes.h).
// invProj used to be computed here in-shader via inverse(pc.proj), on EVERY
// fragment invocation, for a value that's identical across this entire
// draw -- VulkanRender.cpp's updateUniformBuffer now computes it once on
// the CPU per frame instead (SsaoUbo, VulkanTypes.h) and this just reads it.
layout(binding = 3) uniform SsaoUboBlock {
    mat4 proj;
    mat4 invProj;
} ssaoUbo;

layout(push_constant) uniform PushConstants {
    float radius;
    float intensity;
    // Ever-increasing per-real-frame counter -- see its own comment,
    // VulkanTypes.h (SsaoPushConstants::frameIndex), for why main() below
    // mixes this into the per-pixel rotation instead of using noiseTexture's
    // sample as-is.
    int frameIndex;
} pc;

// Interleaved gradient noise (Jimenez, "Next Generation Post Processing in
// Call of Duty: Advanced Warfare", 2014) -- same formula shader.frag's own
// copy uses for its shadow-PCF tap rotation. A cheap, well-distributed
// per-pixel [0,1) value with no texture fetch needed.
float interleavedGradientNoise(vec2 screenPos) {
    return fract(52.9829189 * fract(dot(screenPos, vec2(0.06711056, 0.00583715))));
}

// 16 -> 8 (SSAO GOAL/STEP plan, Step 2): the dominant cost here is the
// scattered/incoherent texture fetch pattern (see this file's own top
// comment), not raw instruction count, so halving the tap count is
// expected to roughly halve the sample pass' GPU time. Still blurred
// afterward (blur.frag), which is what keeps 8 taps from reading as
// obviously noisier than 16 did.
const int kKernelSize = 8;

// Deterministic hash-based hemisphere sample generator, computed on the fly
// per invocation rather than uploaded as a precomputed kernel buffer --
// cheap (16 iterations of a couple sin()/fract() calls), and keeps this
// effect entirely self-contained (no extra buffer/descriptor just to hold
// 16 constant vectors). Not a high-quality RNG, just enough spread that
// combined with the per-pixel noise-texture rotation above, sampling
// artifacts stay well hidden.
vec3 hemisphereSample(int i) {
    float fi = float(i);
    float a = fract(sin(fi * 12.9898) * 43758.5453);
    float b = fract(sin(fi * 78.233) * 12345.6789);
    float c = fract(sin(fi * 37.719) * 98765.4321);

    // c in [0,1) keeps this in the +Z hemisphere (tangent space, where +Z is
    // the surface normal direction once transformed by TBN below).
    vec3 s = normalize(vec3(a * 2.0 - 1.0, b * 2.0 - 1.0, c));
    s *= a;

    // "Accelerating interpolation" (standard SSAO trick): bias samples to
    // cluster closer to the origin so nearby detail gets more sampling
    // weight than the outer edge of the radius.
    float scale = fi / float(kKernelSize);
    scale = mix(0.1, 1.0, scale * scale);
    return s * scale;
}

void main() {
    float depth = texture(depthBuffer, fragUV).r;
    if (depth >= 1.0) {
        // Nothing rendered here (sky/background, still at the pre-pass'
        // clear value) -- fully unoccluded (alpha=1, see the packing
        // comment on outColor below), and reconstructing a view-space
        // position/normal at the far plane would be meaningless besides, so
        // RGB is just an arbitrary placeholder view-space direction --
        // nothing genuinely samples SSAO at a sky pixel downstream.
        outColor = vec4(0.0, 0.0, 1.0, 1.0);
        return;
    }

    // Reconstruct view-space position from depth: NDC -> clip -> view via
    // inverse(proj), the standard trick every G-buffer-less-position SSAO
    // implementation uses. ssaoUbo.invProj is computed once per frame on the
    // CPU (see ssaoUbo's own binding comment above) rather than here.
    vec4 ndc = vec4(fragUV * 2.0 - 1.0, depth, 1.0);
    vec4 viewPosH = ssaoUbo.invProj * ndc;
    vec3 viewPos = viewPosH.xyz / viewPosH.w;

    vec3 normal = normalize(texture(normalBuffer, fragUV).xyz);

    // Tile the 4x4 noise texture across the whole screen -- textureSize()
    // gives the render target's own resolution without a separate uniform.
    // Rotated by an animated angle (IGN(pixel) walked forward by the golden
    // ratio each real frame -- see SsaoPushConstants::frameIndex's own
    // comment, VulkanTypes.h) on top of the texture's own static per-pixel
    // value: the texture alone gives good *spatial* decorrelation between
    // neighboring pixels, but is identical every frame, so a static world
    // point sliding across it as the camera moves reads as a slow-shifting
    // moire. Adding a frame-varying rotation on top means the
    // SAME pixel's sampling pattern also changes frame to frame, which is
    // what temporal accumulation downstream (ssao_temporal.frag) actually
    // needs something to average across.
    const float kGoldenRatio = 0.6180339887498949;
    float animatedPhase = fract(interleavedGradientNoise(gl_FragCoord.xy) + float(pc.frameIndex) * kGoldenRatio);
    float animatedAngle = animatedPhase * 6.2831853;
    float animSin = sin(animatedAngle);
    float animCos = cos(animatedAngle);

    vec2 noiseScale = vec2(textureSize(depthBuffer, 0)) / 4.0;
    vec2 staticNoise = texture(noiseTexture, fragUV * noiseScale).xy;
    vec2 rotatedNoise = vec2(
        staticNoise.x * animCos - staticNoise.y * animSin,
        staticNoise.x * animSin + staticNoise.y * animCos);
    vec3 randomVec = normalize(vec3(rotatedNoise, 0.0));

    // Gram-Schmidt to build an orthonormal basis around normal, rotated
    // per-pixel by randomVec -- standard TBN construction for orienting the
    // hemisphere kernel to each fragment's own surface.
    vec3 tangent = normalize(randomVec - normal * dot(randomVec, normal));
    vec3 bitangent = cross(normal, tangent);
    mat3 TBN = mat3(tangent, bitangent, normal);

    // Positive "distance from camera" for both the fragment itself and
    // (below) every sample/scene point -- view space here is right-handed
    // with the camera looking down -Z (GLM's standard convention), so raw Z
    // is negative and gets *more* negative the farther away something is;
    // negating it up front avoids relying on remembering that sign anywhere
    // else in this function.
    float fragDist = -viewPos.z;

    float occlusion = 0.0;
    for (int i = 0; i < kKernelSize; ++i) {
        vec3 samplePos = viewPos + (TBN * hemisphereSample(i)) * pc.radius;
        float sampleDist = -samplePos.z;

        // Re-project the hypothetical sample point back to screen space to
        // look up whatever's actually there.
        vec4 sampleClip = ssaoUbo.proj * vec4(samplePos, 1.0);
        vec2 sampleUV = (sampleClip.xy / sampleClip.w) * 0.5 + 0.5;

        float sceneDepthAtSample = texture(depthBuffer, sampleUV).r;
        vec4 sceneNdcAtSample = vec4(sampleUV * 2.0 - 1.0, sceneDepthAtSample, 1.0);
        vec4 sceneViewH = ssaoUbo.invProj * sceneNdcAtSample;
        float sceneDist = -(sceneViewH.xyz / sceneViewH.w).z;

        // Range check: only count this as an occluder if it's actually
        // close (in view-space depth) to our own fragment -- otherwise a
        // completely unrelated, much-closer object elsewhere on screen
        // would wrongly attenuate AO for surfaces nowhere near it.
        float rangeCheck = smoothstep(0.0, 1.0, pc.radius / max(abs(fragDist - sceneDist), 1e-4));
        // Occluded if the real surface at the sample's screen position is
        // closer to the camera (smaller distance) than the hypothetical
        // sample point -- i.e. something real is standing between the
        // sample point and the camera. 0.025 is a small fixed depth bias
        // avoiding self-occlusion from a fragment's own (near-)coplanar
        // neighbors.
        occlusion += (sceneDist <= sampleDist - 0.025 ? 1.0 : 0.0) * rangeCheck;
    }

    float ao = 1.0 - (occlusion / float(kKernelSize));
    ao = pow(clamp(ao, 0.0, 1.0), pc.intensity);
    // RGB=plain view-space geometric normal, A=AO -- sampled by shader.frag's
    // ambient/IBL term (see ssaoTexture's own comment there), and also read
    // by ssao_temporal.frag's normal-confidence check and blur_bilateral.frag's
    // normal-aware blur weight as "this fragment's normal" (neither has any
    // GTAO-specific assumption -- both just compare RGB channels generically).
    outColor = vec4(normal, ao);
}
