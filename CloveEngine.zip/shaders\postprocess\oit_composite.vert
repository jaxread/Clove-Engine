#version 450

// Classic "fullscreen triangle from just gl_VertexIndex" trick: 3 vertices,
// no vertex/index buffer bound (VulkanPipeline.cpp's createOitPipelines
// gives this pipeline an empty VkPipelineVertexInputStateCreateInfo). The
// triangle's outer edges fall outside the viewport; only the portion
// covering the screen actually rasterizes, and fragUV interpolates to
// exactly [0,1] across that visible portion.
layout(location = 0) out vec2 fragUV;

void main() {
    vec2 uv = vec2((gl_VertexIndex << 1) & 2, gl_VertexIndex & 2);
    fragUV = uv;
    gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0);
}
