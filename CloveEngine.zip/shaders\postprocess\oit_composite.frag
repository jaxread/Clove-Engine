#version 450

// Resolves the weighted-blended OIT accumulation (see shader_oit.frag) onto
// whatever pass 1 already wrote into the swapchain image. Bound with
// ordinary source-over alpha blending (srcColorBlendFactor = SRC_ALPHA,
// dstColorBlendFactor = ONE_MINUS_SRC_ALPHA -- see createOitPipelines,
// VulkanPipeline.cpp), so all the actual math needed is picking the right
// (color, alpha) to output here.
//
// Derivation: accum.rgb holds the sum over every transparent fragment at
// this pixel of (color * alpha * weight), and accum.a holds the sum of
// (alpha * weight) -- so accum.rgb / accum.a is the weight-averaged color
// of everything drawn here, independent of draw order. reveal.r holds the
// running product of (1 - alpha) across those same fragments -- the
// fraction of the background that's still visible through all of them
// combined. Standard source-over compositing of that averaged color at
// coverage (1 - revealage) on top of the opaque background underneath is
// exactly: background * revealage + averageColor * (1 - revealage), which
// is what SRC_ALPHA/ONE_MINUS_SRC_ALPHA blending gives for free when this
// shader's output alpha is (1 - revealage).

layout(location = 0) in vec2 fragUV;
layout(location = 0) out vec4 outColor;

layout(binding = 0) uniform sampler2D accumTex;
layout(binding = 1) uniform sampler2D revealTex;

void main() {
    float revealage = texture(revealTex, fragUV).r;
    // Nothing transparent was drawn at this pixel this frame (reveal still
    // at its clear value of 1.0) -- discard rather than blend a meaningless
    // 0/0 average color in, and skip writing over the opaque pixel
    // underneath entirely.
    if (revealage > 0.999) {
        discard;
    }

    vec4 accum = texture(accumTex, fragUV);
    // Extreme per-fragment weights (see shader_oit.frag) can push accum
    // into Inf/NaN territory in pathological cases (many overlapping
    // near-camera fragments); guard the divide rather than let that
    // propagate into a corrupted-looking pixel.
    float maxComponent = max(max(abs(accum.r), abs(accum.g)), max(abs(accum.b), abs(accum.a)));
    if (isinf(maxComponent) || isnan(maxComponent)) {
        accum = vec4(accum.a); // falls back to unweighted-ish average below
    }

    vec3 averageColor = accum.rgb / max(accum.a, 1e-5);
    outColor = vec4(averageColor, 1.0 - revealage);
}
