#version 450
#extension GL_EXT_nonuniform_qualifier : enable

// Tessellation evaluation shader for the POM displacement pipeline -- see
// pom_displace.tesc's comment for the pipeline this belongs to. Barycentric-
// interpolates each generated vertex's attributes from its patch's 3 control
// points (pom_displace.tesc's passthrough outputs), then displaces the
// interpolated world position along the interpolated normal by this
// material's heightmap -- this is what gives real, silhouette-correct
// tessellated geometry instead of shader.frag's parallax-occlusion-mapping
// ray-march (which only ever fakes depth via texture-coordinate shifting,
// never actually moves a vertex).
//
// ccw, matching VK_FRONT_FACE_COUNTER_CLOCKWISE (createGraphicsPipeline,
// VulkanPipeline.cpp) -- the whole engine's winding convention already
// assumes every triangle is CCW-wound post-projection (see that flag's own
// comment for why: proj[1][1] gets negated for Vulkan's clip space, which
// flips the winding the rasterizer sees), so patches generated here need the
// same qualifier to stay consistent with that, or backface culling would end
// up inverted for every tessellated draw.
layout(triangles, equal_spacing, ccw) in;

// Same partial-declaration convention as pom_displace.tesc/shader.vert --
// only the prefix (view/proj) this stage actually reads.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
} ubo;

// Full field-for-field mirror of GpuMaterial (VulkanTypes.h)/shader.frag's
// own Material struct -- unlike the UBO prefix trick above, this is an
// *array* of this struct (MaterialBuffer below), so its stride depends on
// the struct's full declared size; a truncated declaration here would
// silently compute the wrong per-element stride and read every material
// past index 0 from the wrong offset. Only heightTexture/heightScale are
// actually read below, but every field has to be present anyway.
struct Material {
    vec4 baseColorFactor;
    vec4 emissiveFactor;
    int baseColorTexture;
    int metallicRoughnessTexture;
    int normalTexture;
    int occlusionTexture;
    int emissiveTexture;
    float metallicFactor;
    float roughnessFactor;
    float normalScale;
    float occlusionStrength;
    float alphaCutoff;
    int alphaMode;
    int doubleSided;
    int texCoordSets;
    int heightTexture;
    float heightScale;
    int _pad0;
};

layout(std430, binding = 1) readonly buffer MaterialBuffer {
    Material materials[];
} materialBuffer;

// Same bindless array shader.frag samples from -- see its own comment
// (binding 4, highest-numbered in the set) for why.
layout(binding = 4) uniform sampler2D bindlessTextures[];

layout(location = 0) in vec3 inWorldPos[];
layout(location = 1) in vec3 inNormal[];
layout(location = 2) in vec2 inUV[];
layout(location = 3) in vec4 inTangent[];
layout(location = 5) in vec4 inColor[];
layout(location = 6) in vec2 inUV2[];
layout(location = 7) patch in int patchMaterialIndex;

layout(location = 0) out vec3 fragWorldPos;
layout(location = 1) out vec3 fragNormal;
layout(location = 2) out vec2 fragUV;
layout(location = 3) out vec4 fragTangent;
layout(location = 4) flat out int fragMaterialIndex;
layout(location = 5) out vec4 fragColor;
layout(location = 6) out vec2 fragUV2;

void main() {
    vec3 bary = gl_TessCoord;
    vec3 worldPos = inWorldPos[0] * bary.x + inWorldPos[1] * bary.y + inWorldPos[2] * bary.z;
    // Re-normalized after barycentric blending (3 unit normals averaged
    // together isn't unit-length in general) -- same reasoning shader.vert's
    // own normal transform already relies on downstream.
    vec3 normal = normalize(inNormal[0] * bary.x + inNormal[1] * bary.y + inNormal[2] * bary.z);
    vec2 uv = inUV[0] * bary.x + inUV[1] * bary.y + inUV[2] * bary.z;
    vec4 tangent = inTangent[0] * bary.x + inTangent[1] * bary.y + inTangent[2] * bary.z;
    vec4 color = inColor[0] * bary.x + inColor[1] * bary.y + inColor[2] * bary.z;
    vec2 uv2 = inUV2[0] * bary.x + inUV2[1] * bary.y + inUV2[2] * bary.z;

    Material mat = materialBuffer.materials[patchMaterialIndex];
    // Height convention: sampled value 1.0 = zero displacement (this
    // generated vertex sits exactly on the original, undisplaced surface),
    // 0.0 = recessed the full mat.heightScale inward along -normal. Matches
    // shader.frag's parallaxOcclusionOffset() convention exactly (see its
    // comment) -- both stages read the *same* heightmap the same way, so the
    // per-pixel POM illusion and the real per-vertex displacement never
    // disagree about which direction is "in". Deliberately recess-only
    // (never bulges outward past the original mesh) rather than an
    // additive-outward convention -- that would need the fragment-side POM
    // faded out by tessellation density to avoid double-counting the same
    // height twice (once as real vertex displacement, once as illusory
    // parallax); recess-only sidesteps that entirely, since POM's UV-shift
    // only ever biases *which texel* gets sampled at an already-correctly-
    // positioned fragment, never re-adds position.
    if (mat.heightTexture >= 0) {
        // textureLod, not texture(): implicit-LOD derivatives (dFdx/dFdy)
        // aren't available outside the fragment shader.
        float h = textureLod(bindlessTextures[nonuniformEXT(mat.heightTexture)], uv, 0.0).r;
        worldPos += normal * (h - 1.0) * mat.heightScale;
    }

    gl_Position = ubo.proj * ubo.view * vec4(worldPos, 1.0);
    fragWorldPos = worldPos;
    fragNormal = normal;
    fragUV = uv;
    fragTangent = tangent;
    fragMaterialIndex = patchMaterialIndex;
    fragColor = color;
    fragUV2 = uv2;
}
