#version 450

// Bright-pass extract for the standalone Bloom effect -- the first of its 3
// draws (see createBloomPipelines()'s comment, VulkanPipeline.cpp). Samples
// the fully composited linear HDR scene (hdrResolveImage, via
// postProcessHdrDescriptorSet -- the exact same source binding the Blur
// effect's own horizontal draw reads, see createPostProcessResources'
// comment, VulkanApp.h) and outputs only the over-threshold contribution.
// The result then goes through 2 draws reusing blurPipeline/blur.frag
// directly (no separate blur pipeline for Bloom) before being added on top
// of the scene in tonemap.frag. Vertex stage is oit_composite.vert, same
// reuse as blur.frag/tonemap.frag.
layout(location = 0) in vec2 fragUV;

layout(location = 0) out vec4 outColor;

layout(binding = 0) uniform sampler2D hdrColor;

layout(push_constant) uniform PushConstants {
    // GraphicsSettingsUI's Bloom "Threshold" slider -- brightness (max
    // channel) at or below this contributes nothing; the knee below softens
    // the region just above it instead of a hard cutoff.
    float threshold;
} pc;

void main() {
    vec3 color = texture(hdrColor, fragUV).rgb;
    float brightness = max(color.r, max(color.g, color.b));

    // Standard Karis/Unreal soft-knee quadratic (the same curve Unity's
    // post-processing bloom uses): rather than a hard step at pc.threshold,
    // ramps smoothly across [threshold - knee, threshold + knee] so bright
    // specular highlights/sun glints fade into the bloom instead of popping
    // in/out as they cross the cutoff -- this is what was flickering before
    // the equivalent fix in the (since-removed) old bloom pass. knee is a
    // fixed fraction of threshold rather than its own slider -- the
    // Threshold slider alone already gives enough control for this effect.
    float knee = pc.threshold * 0.5 + 1e-5;
    float rq = clamp(brightness - (pc.threshold - knee), 0.0, 2.0 * knee);
    rq = rq * rq * (0.25 / knee);

    float contribution = max(rq, brightness - pc.threshold) / max(brightness, 1e-5);
    outColor = vec4(color * contribution, 1.0);
}
