// ============================================================================
// pbr_brdf.glsl -- shared Cook-Torrance BRDF (Phase 3).
//
// Lifted verbatim from shader.frag so RT reflection/GI hit shading uses the
// exact same microfacet model as the raster pass -- otherwise reflections
// wouldn't match directly-lit surfaces. Include this in both shader.frag (and
// delete its local copies once verified) and the RT passes.
// ============================================================================

#ifndef PBR_BRDF_GLSL
#define PBR_BRDF_GLSL

const float kPi = 3.14159265359;

float distributionGGX(vec3 N, vec3 H, float roughness) {
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.0);
    float NdotH2 = NdotH * NdotH;
    float denom = (NdotH2 * (a2 - 1.0) + 1.0);
    return a2 / max(kPi * denom * denom, 1e-6);
}

float geometrySchlickGGX(float NdotV, float roughness) {
    float r = roughness + 1.0;
    float k = (r * r) / 8.0;
    return NdotV / max(NdotV * (1.0 - k) + k, 1e-6);
}

float geometrySmith(float NdotV, float NdotL, float roughness) {
    return geometrySchlickGGX(NdotV, roughness) * geometrySchlickGGX(NdotL, roughness);
}

vec3 fresnelSchlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

// One directional light's Cook-Torrance contribution -- the shared core of
// shader.frag's sun/point loops, reused to shade RT hits.
//   N,V,L : unit normal, view, light (L points TOWARD the light)
//   radiance : incoming light color * intensity (already shadow-scaled by caller)
vec3 evaluateDirectLight(vec3 N, vec3 V, vec3 L, vec3 radiance,
                         vec3 albedo, vec3 F0, float roughness, float metallic) {
    vec3 H = normalize(V + L);
    float NdotV = max(dot(N, V), 1e-4);
    float NdotL = max(dot(N, L), 0.0);
    if (NdotL <= 0.0) return vec3(0.0);

    float NDF = distributionGGX(N, H, roughness);
    float G   = geometrySmith(NdotV, NdotL, roughness);
    vec3  F   = fresnelSchlick(max(dot(H, V), 0.0), F0);

    vec3 specular = (NDF * G * F) / max(4.0 * NdotV * NdotL, 1e-4);
    // Firefly clamp: near-grazing N.V/N.L pushes the denominator toward its
    // 1e-4 floor while G doesn't fall fast enough to compensate, spiking
    // specular by orders of magnitude for a single ray. A directly-viewed
    // camera ray rarely lands in that regime, but a reflection ray's hit
    // (N,V here is the HIT's normal vs the incoming reflection direction,
    // not the camera's own view) has no such constraint -- one mirror ray
    // with no denoiser turns each spike into a visible bright/grainy pixel.
    // 32.0 is well above any physically-plausible direct-light specular
    // highlight at this scene's sun intensities, so this only suppresses
    // the singularity, not real highlights.
    specular = min(specular, vec3(32.0));
    vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);
    return (kD * albedo / kPi + specular) * radiance * NdotL;
}

#endif // PBR_BRDF_GLSL
