#version 450

// Depth- AND normal-aware (bilateral) variant of blur.frag, used ONLY for
// SSAO's own 2-pass separable blur (ssaoRawImage -> ssaoPingImage ->
// ssaoBlurredImage) -- NOT shared with Bloom's identical-shaped blur (see
// blur.frag's own top comment for why that pass stays on the plain
// Gaussian: this pass needs an extra depth binding blur.frag's pipeline
// layout doesn't have, so rather than touch the shared pipeline/layout both
// effects already use, this is a separate shader + pipeline just for SSAO's
// own 2 draws). Standard depth+normal-weighted blur: each of the same 9
// Gaussian taps blur.frag uses is additionally scaled by how close that
// tap's LINEAR (view-space) depth AND surface normal are to the center
// pixel's own, so occlusion doesn't bleed across a depth OR normal
// discontinuity (silhouette/crease edges) the way a plain spatial blur does.
// The normal check needs no extra binding -- `source` already carries
// RGB=plain view-space geometric normal in its own color channels (ssao.frag's
// own outColor packing), so each tap's normal comes free with the color/AO
// sample this blur already fetches.
//
// Linearized, not raw NDC depth: raw hardware depth is nonlinear (compresses
// hard toward 1.0 with distance), so a single fixed threshold in raw-depth
// units is wrong almost everywhere -- too loose far from the camera (barely
// rejects anything, defeating the point) and, worse, too TIGHT on any
// grazing-angle continuous surface close up (a flat floor or wall viewed at
// a shallow angle has a large raw-depth gradient across adjacent pixels even
// though it's one continuous surface), which read as noisy "staticky" lines
// baked right into the ground/walls once blurred. Comparing linear view-space
// depth, scaled RELATIVE to the center pixel's own distance (matching
// ssao_temporal.frag's identical "percentage of depth" disocclusion check),
// fixes both: the threshold naturally widens with distance the same way
// raw-depth precision itself does, and a grazing-angle continuous surface's
// linear depth still varies smoothly enough not to trip a relative cutoff.
layout(location = 0) in vec2 fragUV;

layout(location = 0) out vec4 outColor;

// Whichever source this draw is reading -- ssaoRawImage then ssaoPingImage,
// same 2-draw sequence blur.frag's own reuse for SSAO already followed (see
// recordCommandBuffer's "SSAO pass" comment).
layout(binding = 0) uniform sampler2D source;
layout(binding = 1) uniform sampler2D depthBuffer;

layout(push_constant) uniform PushConstants {
    // Same invProj ssao.frag reconstructs view-space position with (SsaoUbo,
    // VulkanTypes.h) -- pushed directly here instead of riding along on that
    // UBO since this pipeline's 2 descriptor sets aren't per-frame-in-flight
    // (see ssaoRawBilateralDescriptorSet's own comment, VulkanApp.h) and a
    // mat4 comfortably fits the guaranteed-minimum 128-byte push constant
    // budget alongside direction/spread/depthThreshold below.
    mat4 invProj;
    vec2 direction;
    float spread;
    // Max allowed linear-depth difference between two taps, as a FRACTION of
    // the center pixel's own linear depth (e.g. 0.05 = 5%) -- not raw depth
    // units, see this file's own top comment for why. Fixed rather than a
    // GraphicsUI slider -- SSAO's blur radius is already small/local enough
    // that this doesn't need per-scene tuning.
    float depthThreshold;
} pc;

// Same discretized-Gaussian 9-tap weights as blur.frag.
const float kWeights[5] = float[](0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216);

// Positive "distance from camera" -- same convention (and sign reasoning) as
// ssao.frag's own fragDist/sampleDist/sceneDist.
float linearDepth(vec2 uv, float rawDepth) {
    vec4 ndc = vec4(uv * 2.0 - 1.0, rawDepth, 1.0);
    vec4 viewH = pc.invProj * ndc;
    return -(viewH.z / viewH.w);
}

void main() {
    vec2 texelStep = pc.direction * pc.spread;
    vec4 centerSample = texture(source, fragUV);
    vec3 centerNormal = normalize(centerSample.rgb);
    float centerDepth = linearDepth(fragUV, texture(depthBuffer, fragUV).r);
    float threshold = max(pc.depthThreshold * centerDepth, 1e-4);

    vec4 result = centerSample * kWeights[0];
    float weightSum = kWeights[0];

    for (int i = 1; i < 5; ++i) {
        vec2 offset = texelStep * float(i);

        vec2 uvPos = fragUV + offset;
        vec4 samplePos = texture(source, uvPos);
        float depthPos = linearDepth(uvPos, texture(depthBuffer, uvPos).r);
        float depthWPos = 1.0 - smoothstep(0.0, threshold, abs(depthPos - centerDepth));
        float normalWPos = smoothstep(0.4, 0.9, dot(centerNormal, normalize(samplePos.rgb)));
        float wPos = kWeights[i] * depthWPos * normalWPos;
        result += samplePos * wPos;
        weightSum += wPos;

        vec2 uvNeg = fragUV - offset;
        vec4 sampleNeg = texture(source, uvNeg);
        float depthNeg = linearDepth(uvNeg, texture(depthBuffer, uvNeg).r);
        float depthWNeg = 1.0 - smoothstep(0.0, threshold, abs(depthNeg - centerDepth));
        float normalWNeg = smoothstep(0.4, 0.9, dot(centerNormal, normalize(sampleNeg.rgb)));
        float wNeg = kWeights[i] * depthWNeg * normalWNeg;
        result += sampleNeg * wNeg;
        weightSum += wNeg;
    }

    // Renormalize -- taps rejected by the depth/normal tests above would
    // otherwise darken/lighten the result toward the missing taps rather
    // than just being excluded, same reasoning any bilateral filter's own
    // renormalization step has.
    outColor = result / max(weightSum, 1e-4);
}
