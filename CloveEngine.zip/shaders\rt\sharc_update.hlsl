// ============================================================================
// sharc_update.hlsl -- Phase 4: SHaRC update pass.
//
// Dispatched over a DOWNSCALED grid (SharcFrameParams.screenParams.xy), one
// GI sample per thread: reconstructs a world-space point + normal from the
// depth/normal G-buffer, casts one single-bounce cosine-hemisphere ray, and
// feeds the hit's (or the sky's, on miss) radiance into the SHaRC hash grid.
//
// HLSL port of this project's GLSL RT shaders (shaders/rt/rt_surface.glsl,
// rt_shadows.glsl) -- same GpuVertex/RtInstance layouts and hit-fetch math,
// same rtSunShadowHard() shadow-ray shape, since they can't be #include'd
// directly into HLSL. First-cut simplification, same spirit as Phase 3's
// documented one (PHASE3_NOTES.md): single bounce (not the full
// SHARC_PROPAGATION_DEPTH multi-bounce chain SharcCommon.h supports), plain
// Lambertian direct light at the hit using vertex color as an albedo proxy
// (no material/texture fetch) -- SHaRC's own temporal accumulation is what
// turns this into usable multi-bounce-*feeling* GI over many frames, not a
// single frame's path depth.
// ============================================================================

#define SHARC_ENABLE_64_BIT_ATOMICS 1
#define SHARC_UPDATE 1
#define SHARC_QUERY 0

#include "SharcCommon.h"

// --- Scene resources (set 0) ---
[[vk::binding(0, 0)]] RaytracingAccelerationStructure rtTLAS : register(t0, space0);

// Matches GpuVertex (VulkanTypes.h): 40 bytes, tightly packed -- same layout
// rt_surface.glsl's GLSL mirror uses (scalar block layout there; HLSL
// StructuredBuffer is naturally tightly packed per its declared struct, no
// extra layout qualifier needed).
struct GpuVertex {
    float3 pos;    // offset 0
    uint normal;   // 12 -- A2B10G10R10_SNORM
    uint tangent;  // 16 -- A2B10G10R10_SNORM
    float2 uv;     // 20
    float2 uv2;    // 28
    uint color;    // 36 -- R8G8B8A8_UNORM
};

struct RtInstance {
    uint vertexOffset;
    uint indexOffset;
    int  materialIndex;
    uint pad0;
};

[[vk::binding(1, 0)]] StructuredBuffer<GpuVertex> RtVerts : register(t1, space0);
[[vk::binding(2, 0)]] StructuredBuffer<uint> RtIndices : register(t2, space0);
[[vk::binding(3, 0)]] StructuredBuffer<RtInstance> RtInsts : register(t3, space0);
// HLSL has no native combined-image-sampler type -- dxc's Vulkan target
// merges a Texture2D + SamplerState sharing the SAME vk::binding into one
// combined-image-sampler descriptor when both carry
// [[vk::combinedImageSampler]]. Matches the C++ side's
// VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER at these binding numbers (same
// depth/normal G-buffer + cullDepthSampler this engine's SSAO pass already
// reads).
[[vk::binding(4, 0)]] [[vk::combinedImageSampler]] Texture2D<float> depthBuffer : register(t4, space0);
[[vk::binding(4, 0)]] [[vk::combinedImageSampler]] SamplerState depthSampler : register(s4, space0);
[[vk::binding(5, 0)]] [[vk::combinedImageSampler]] Texture2D<float4> normalBuffer : register(t5, space0);
[[vk::binding(5, 0)]] [[vk::combinedImageSampler]] SamplerState normalSampler : register(s5, space0);

[[vk::binding(6, 0)]] RWStructuredBuffer<uint64_t> u_HashEntriesBuffer : register(u0, space0);
[[vk::binding(7, 0)]] RWStructuredBuffer<SharcAccumulationData> u_AccumulationBuffer : register(u1, space0);
[[vk::binding(8, 0)]] RWStructuredBuffer<SharcPackedData> u_ResolvedBuffer : register(u2, space0);

struct SharcFrameParamsCB {
    column_major float4x4 invView;
    column_major float4x4 invProj;
    float4 camPos;
    float4 camPosPrev;
    float4 sunDir;
    float4 sunColor;
    float4 gridParams;   // x=sceneScale, y=radianceScale
    uint4  intParams;    // x=frameIndex, y=accumulationFrameNum, z=staleFrameNumMax, w=capacity
    int4   screenParams; // x=update grid width, y=update grid height, z=full width, w=full height
};
[[vk::binding(9, 0)]] ConstantBuffer<SharcFrameParamsCB> pc : register(b0, space0);

static const float kPi = 3.14159265359;

// --- Vertex unpack (port of rt_surface.glsl) ---
float3 unpackNormalA2B10G10R10(uint p) {
    int x = int(p << 22) >> 22;
    int y = int(p << 12) >> 22;
    int z = int(p <<  2) >> 22;
    return normalize(float3(float(x), float(y), float(z)) / 511.0);
}

float4 unpackColorR8G8B8A8(uint p) {
    return float4(float(p & 0xFFu), float((p >> 8) & 0xFFu),
                  float((p >> 16) & 0xFFu), float((p >> 24) & 0xFFu)) / 255.0;
}

struct HitSurface {
    float3 worldPos;
    float3 worldNormal;
    float4 vColor;
};

HitSurface fetchHitSurface(RayQuery<RAY_FLAG_FORCE_OPAQUE> q, float3 rayOrigin, float3 rayDir) {
    HitSurface s;

    uint instIdx = q.CommittedInstanceID();
    uint prim = q.CommittedPrimitiveIndex();
    float2 bary = q.CommittedTriangleBarycentrics();
    float t = q.CommittedRayT();

    RtInstance ri = RtInsts[instIdx];

    uint base = ri.indexOffset + prim * 3u;
    uint i0 = RtIndices[base + 0u] + ri.vertexOffset;
    uint i1 = RtIndices[base + 1u] + ri.vertexOffset;
    uint i2 = RtIndices[base + 2u] + ri.vertexOffset;

    GpuVertex v0 = RtVerts[i0];
    GpuVertex v1 = RtVerts[i1];
    GpuVertex v2 = RtVerts[i2];

    float w = 1.0 - bary.x - bary.y;
    float3 nObj = normalize(
        unpackNormalA2B10G10R10(v0.normal) * w +
        unpackNormalA2B10G10R10(v1.normal) * bary.x +
        unpackNormalA2B10G10R10(v2.normal) * bary.y);

    float3x3 rot = (float3x3)q.CommittedObjectToWorld3x4();

    s.worldPos = rayOrigin + rayDir * t;
    s.worldNormal = normalize(mul(nObj, rot));
    s.vColor = unpackColorR8G8B8A8(v0.color) * w +
               unpackColorR8G8B8A8(v1.color) * bary.x +
               unpackColorR8G8B8A8(v2.color) * bary.y;
    return s;
}

// --- Shadow ray (port of rt_shadows.glsl's rtSunShadowHard) ---
float rtSunShadowHard(float3 worldPos, float3 worldNormal, float3 lightDir) {
    const float kNormalBias = 0.02;
    float3 origin = worldPos + worldNormal * kNormalBias;

    RayDesc ray;
    ray.Origin = origin;
    ray.Direction = lightDir;
    ray.TMin = 0.001;
    ray.TMax = 10000.0;

    RayQuery<RAY_FLAG_FORCE_OPAQUE | RAY_FLAG_ACCEPT_FIRST_HIT_AND_END_SEARCH> q;
    q.TraceRayInline(rtTLAS, RAY_FLAG_NONE, 0xFF, ray);
    while (q.Proceed()) {}

    return (q.CommittedStatus() == COMMITTED_TRIANGLE_HIT) ? 0.0 : 1.0;
}

// --- Cosine-weighted hemisphere sample around N, from a per-pixel hash ---
// Same interleaved-gradient-noise family this project already uses
// (shader.frag's PCF rotation, ssao.frag's kernel rotation) -- cheap,
// well-distributed, no texture fetch.
float ign(float2 p) {
    return frac(52.9829189 * frac(dot(p, float2(0.06711056, 0.00583715))));
}

float3 cosineSampleHemisphere(float3 N, float2 xi) {
    float r = sqrt(xi.x);
    float phi = 2.0 * kPi * xi.y;
    float3 localDir = float3(r * cos(phi), r * sin(phi), sqrt(max(0.0, 1.0 - xi.x)));

    float3 up = abs(N.z) < 0.999 ? float3(0, 0, 1) : float3(1, 0, 0);
    float3 tangent = normalize(cross(up, N));
    float3 bitangent = cross(N, tangent);
    return normalize(tangent * localDir.x + bitangent * localDir.y + N * localDir.z);
}

[numthreads(8, 8, 1)]
void main(uint3 dtid : SV_DispatchThreadID)
{
    if ((int)dtid.x >= pc.screenParams.x || (int)dtid.y >= pc.screenParams.y)
        return;

    // Downscaled grid -> full-res pixel at this block's center.
    int scaleX = max(pc.screenParams.z / max(pc.screenParams.x, 1), 1);
    int scaleY = max(pc.screenParams.w / max(pc.screenParams.y, 1), 1);
    int2 fullPixel = int2(dtid.xy) * int2(scaleX, scaleY) + int2(scaleX, scaleY) / 2;
    float2 uv = (float2(fullPixel) + 0.5) / float2(pc.screenParams.zw);

    float depth = depthBuffer.SampleLevel(depthSampler, uv, 0);
    if (depth >= 1.0)
        return; // sky -- nothing to seed the cache with here

    float4 normalSample = normalBuffer.SampleLevel(normalSampler, uv, 0);
    float3 viewNormal = normalize(normalSample.xyz);
    float3 worldNormal = normalize(mul(viewNormal, (float3x3)pc.invView));

    float4 ndc = float4(uv * 2.0 - 1.0, depth, 1.0);
    float4 viewPosH = mul(pc.invProj, ndc);
    float3 viewPos = viewPosH.xyz / viewPosH.w;
    float4 worldPosH = mul(pc.invView, float4(viewPos, 1.0));
    float3 worldPos = worldPosH.xyz;

    float2 rand2 = float2(ign(float2(dtid.xy)), ign(float2(dtid.xy) + 17.0 + float(pc.intParams.x)));
    float3 rayDir = cosineSampleHemisphere(worldNormal, rand2);
    float3 rayOrigin = worldPos + worldNormal * 0.02;

    SharcParameters sharcParameters;
    sharcParameters.gridParameters.cameraPosition = pc.camPos.xyz;
    sharcParameters.gridParameters.logarithmBase = SHARC_GRID_LOGARITHM_BASE;
    sharcParameters.gridParameters.sceneScale = pc.gridParams.x;
    sharcParameters.gridParameters.levelBias = SHARC_GRID_LEVEL_BIAS;
    sharcParameters.hashMapData.capacity = pc.intParams.w;
    sharcParameters.hashMapData.hashEntriesBuffer = u_HashEntriesBuffer;
    sharcParameters.accumulationBuffer = u_AccumulationBuffer;
    sharcParameters.resolvedBuffer = u_ResolvedBuffer;
    sharcParameters.radianceScale = pc.gridParams.y;
    sharcParameters.enableAntiFireflyFilter = true;

    SharcState sharcState;
    SharcInit(sharcState);

    RayDesc ray;
    ray.Origin = rayOrigin;
    ray.Direction = rayDir;
    ray.TMin = 0.001;
    ray.TMax = 10000.0;

    RayQuery<RAY_FLAG_FORCE_OPAQUE> q;
    q.TraceRayInline(rtTLAS, RAY_FLAG_NONE, 0xFF, ray);
    while (q.Proceed()) {}

    if (q.CommittedStatus() != COMMITTED_TRIANGLE_HIT) {
        // Miss -- flat sky radiance (matches this project's atmosphereColor
        // family's rough order of magnitude; not worth a full port here for
        // a first cut, see PHASE3_NOTES.md's own "documented simplification"
        // precedent).
        float3 skyValue = pc.sunColor.rgb * 0.15;
        SharcUpdateMiss(sharcParameters, sharcState, skyValue);
        return;
    }

    HitSurface hit = fetchHitSurface(q, rayOrigin, rayDir);

    float3 albedo = hit.vColor.rgb;
    float sunVis = rtSunShadowHard(hit.worldPos, hit.worldNormal, pc.sunDir.xyz);
    float NdotL = max(dot(hit.worldNormal, pc.sunDir.xyz), 0.0);
    float3 directLighting = albedo / kPi * NdotL * pc.sunColor.rgb * sunVis;

    SharcHitData sharcHitData;
    sharcHitData.positionWorld = hit.worldPos;
    sharcHitData.normalWorld = hit.worldNormal;

    SharcUpdateHit(sharcParameters, sharcState, sharcHitData, directLighting, ign(float2(dtid.xy) + 91.0));
}
