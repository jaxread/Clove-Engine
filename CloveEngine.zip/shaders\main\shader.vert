#version 450

// Only up through forceMaskForBlend is declared -- this stage doesn't read
// ambientColorIntensity/forceMaskForBlend either, but a uniform block's
// layout is positional, so every *preceding* field still has to appear in
// order to keep this prefix's offsets in sync with shader.frag's full
// declaration of the same binding. Nothing after forceMaskForBlend
// (lightViewProj[]/cascadeSplitDepths/etc.) is declared at all: this shader
// used to also compute fragLightSpacePos here (one lightViewProj multiply
// done once per vertex instead of once per fragment), but cascade selection
// has to happen per-fragment now (by view-space depth, a value that isn't
// known yet at this stage) -- see sampleShadow(), shader.frag/
// shader_oit.frag, which now do their own worldPos-based projection instead.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;
    vec3 lightColor;
    vec4 ambientColorIntensity;
    int forceMaskForBlend;
} ubo;

// Per-instance model matrix + normal matrix + material index, one entry per
// MeshInstance in the current scene, uploaded once at load time (see
// createInstancesBuffer, VulkanResources.cpp) rather than pushed per-draw --
// instances never move after load, so there's nothing to refresh between
// draws. Indexed by gl_InstanceIndex, which Vulkan defines as firstInstance
// (the vkCmdDrawIndexed parameter recordCommandBuffer sets per draw, see
// VulkanRender.cpp) plus the in-draw instance number, so a single instanced
// draw covering several consecutive instances still gets each one's own
// entry automatically.
//
// materialIndex isn't used in this stage -- it's read in shader.frag to
// index into the MaterialBuffer SSBO -- but it travels through this stage
// via fragMaterialIndex below since only the vertex stage reads
// InstanceBuffer (see its binding's stageFlags, createDescriptorSetLayout in
// VulkanPipeline.cpp).
//
// normalMatrix is declared as 3 separate vec4 columns, not mat3: std430's
// own column padding already lays a mat3 out as three 16-byte-aligned
// columns (48 bytes) inside a storage buffer, which happens to match this
// exactly -- so `mat3 normalMatrix;` here would work identically to what's
// declared below. It's spelled out as vec4[3] anyway so it's visually
// unambiguous that this matches GpuInstanceData::normalMatrix's C++ layout
// (VulkanApp.h) column-for-column, rather than relying on the reader
// already knowing GLSL's mat3-in-a-block padding rule.
struct InstanceData {
    mat4 model;
    vec4 normalMatrixCol0;
    vec4 normalMatrixCol1;
    vec4 normalMatrixCol2;
    int materialIndex;
    int pad0;
    int pad1;
    int pad2;
};

layout(std430, binding = 3) readonly buffer InstanceBuffer {
    InstanceData instances[];
} instanceBuffer;

layout(location = 0) in vec3 inPosition;
// A2B10G10R10_SNORM_PACK32 (see GpuVertex::normal's comment, VulkanApp.h)
// unpacks in hardware to a normalized vec4 regardless of only xyz being a
// meaningful direction -- w is unused padding, discarded in main() below.
layout(location = 1) in vec4 inNormal;
layout(location = 2) in vec2 inUV;
layout(location = 3) in vec4 inTangent;
layout(location = 4) in vec4 inColor;
// glTF's TEXCOORD_1 -- see Vertex::uv2's comment (VulkanApp.h). A separate
// vertex input attribute (location 5, independent of the fragUV*/location
// numbering below -- vertex input locations and vertex-to-fragment varying
// locations are two unrelated numbering spaces) rather than packing both
// UV sets into one vec4, so this input's format/binding mirrors uv's
// exactly instead of needing a swizzle.
layout(location = 5) in vec2 inUV2;

layout(location = 0) out vec3 fragWorldPos;
layout(location = 1) out vec3 fragNormal;
layout(location = 2) out vec2 fragUV;
layout(location = 3) out vec4 fragTangent;
layout(location = 4) flat out int fragMaterialIndex;
layout(location = 5) out vec4 fragColor;
layout(location = 6) out vec2 fragUV2;

void main() {
    InstanceData inst = instanceBuffer.instances[gl_InstanceIndex];

    vec4 worldPos = inst.model * vec4(inPosition, 1.0);
    gl_Position = ubo.proj * ubo.view * worldPos;

    // Correct normal transform for non-uniform scale: the inverse-transpose
    // of the model's upper-left 3x3, not the model matrix itself (using
    // mat3(inst.model) directly, as before PBR materials landed, skews
    // normals on any non-uniformly-scaled instance). Precomputed once per
    // instance at scene-load time (loadSceneFromFile, VulkanResources.cpp)
    // rather than recomputed here per vertex -- inverse() is identical for
    // every vertex of the same draw call (and every frame, since instances
    // never move), so doing it per-vertex was pure redundant work. Tangents
    // transform like ordinary vectors, not normals, so they still use the
    // plain model 3x3 -- matching glTF's own convention for how TANGENT
    // should be transformed.
    mat3 normalMatrix = mat3(inst.normalMatrixCol0.xyz, inst.normalMatrixCol1.xyz, inst.normalMatrixCol2.xyz);

    fragWorldPos = worldPos.xyz;
    fragNormal = normalize(normalMatrix * inNormal.xyz);
    fragTangent = vec4(normalize(mat3(inst.model) * inTangent.xyz), inTangent.w);
    fragUV = inUV;
    fragUV2 = inUV2;
    fragMaterialIndex = inst.materialIndex;
    fragColor = inColor;
}
