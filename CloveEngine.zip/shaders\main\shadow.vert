#version 450

// Depth-only pass from the directional light's point of view -- no
// fragment shader at all (see createShadowPipeline, VulkanPipeline.cpp),
// so this is the entire shadow map render. Reuses the main pipelineLayout/
// descriptorSetLayout (binding 0 = the same UniformBufferObject shader.frag
// reads, just for ubo.lightViewProj[] here) rather than a dedicated layout,
// since that's all this stage needs.
//
// lightViewProj is an array now (one entry per cascade, see
// kNumShadowCascades, VulkanTypes.h) -- recordCommandBuffer renders one
// cascade's depth at a time, so it can't decide *which* entry a given draw
// should use from data alone the way it could with a single matrix; that
// has to arrive as the push constant below instead.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;
    vec3 lightColor;
    vec4 ambientColorIntensity;
    int forceMaskForBlend;
    mat4 lightViewProj[4]; // literal 4 -- must match kNumShadowCascades (VulkanTypes.h)
} ubo;

// Which cascade recordCommandBuffer is currently rendering into -- set once
// per cascade sub-pass via vkCmdPushConstants (see the shadow pass loop
// there) rather than read from the UBO, since that loop, not anything
// per-vertex, is what decides which entry of ubo.lightViewProj[] applies to
// the draws about to be recorded.
layout(push_constant) uniform ShadowPushConstant {
    int cascadeIndex;
} pc;

// Shares the main descriptorSetLayout (and therefore this same binding) as
// shader.vert's InstanceBuffer (VulkanApp.h's GpuInstanceData). Unlike a
// push-constant block, an SSBO *array*'s per-element stride is derived from
// this struct's own declared size/alignment under std430 -- declaring only
// `model` here (unlike shader.vert's full field list) would give instances[]
// a 64-byte stride instead of the real 128-byte GpuInstanceData one, making
// every element past instances[0] read from the wrong byte offset. So the
// full field list has to be repeated here even though normalMatrix/
// materialIndex are never read in this stage. Indexed by gl_InstanceIndex,
// same as shader.vert -- see InstanceBuffer's comment there for why this
// replaced a per-draw push constant.
struct InstanceData {
    mat4 model;
    vec4 normalMatrixCol0;
    vec4 normalMatrixCol1;
    vec4 normalMatrixCol2;
    int materialIndex;
    int pad0;
    int pad1;
    int pad2;
};

layout(std430, binding = 3) readonly buffer InstanceBuffer {
    InstanceData instances[];
} instanceBuffer;

// Only position is needed to write depth -- VulkanPipeline.cpp's
// createShadowPipeline still declares the full Vertex layout (normal/uv/
// tangent/color included) for its VkPipelineVertexInputStateCreateInfo, so
// the same vertex/index buffers bind unchanged; this shader just doesn't
// consume the other attributes.
layout(location = 0) in vec3 inPosition;

void main() {
    mat4 lightVP = ubo.lightViewProj[pc.cascadeIndex];
    gl_Position = lightVP * instanceBuffer.instances[gl_InstanceIndex].model * vec4(inPosition, 1.0);
}
