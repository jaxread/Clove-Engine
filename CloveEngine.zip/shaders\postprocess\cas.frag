#version 450

// Contrast-adaptive sharpen, AMD FidelityFX CAS' public algorithm (a plus-
// shaped 5-tap neighborhood, local min/max contrast, adaptive weight clamped
// to avoid ringing on high-contrast edges) -- the final pass in the chain,
// now the one that actually writes the swapchain image (see
// recordCommandBuffer's "CAS pass" comment, VulkanRender.cpp, for why
// Tonemap was retargeted to an intermediate LDR image instead). Always runs;
// at Sharpness 0 this is a pure pass-through. texelFetch (not a filtered
// sampler read) for crisp unfiltered taps regardless of the shared sampler's
// filter mode.

layout(location = 0) in vec2 fragUV;
layout(location = 0) out vec4 outColor;

layout(binding = 0) uniform sampler2D ldrColor;

layout(push_constant) uniform PushConstants {
    // GraphicsUI's Sharpening "Sharpness" slider -- 0 disables the effect
    // entirely (w below becomes 0, so sharpened == c).
    float sharpness;
} pc;

void main() {
    ivec2 coord = ivec2(gl_FragCoord.xy);
    vec3 a = texelFetch(ldrColor, coord + ivec2(0, -1), 0).rgb;
    vec3 b = texelFetch(ldrColor, coord + ivec2(-1, 0), 0).rgb;
    vec3 c = texelFetch(ldrColor, coord, 0).rgb;
    vec3 d = texelFetch(ldrColor, coord + ivec2(1, 0), 0).rgb;
    vec3 e = texelFetch(ldrColor, coord + ivec2(0, 1), 0).rgb;

    // Local contrast from the plus-shaped neighborhood's min/max -- CAS'
    // adaptive term: sharpen less near already-high-contrast edges (where
    // ringing would be most visible) and more in flatter regions.
    vec3 mn = min(a, min(b, min(c, min(d, e))));
    vec3 mx = max(a, max(b, max(c, max(d, e))));
    vec3 amp = clamp(min(mn, 2.0 - mx) / max(mx, 1e-4), 0.0, 1.0);
    // CAS' own peak-sharpening range is roughly -1/8 (subtle) to -1/5
    // (strong) per tap; expressed here as the reciprocal "peak" divisor
    // (8 = subtle, 5 = strong) driven by the Sharpness slider.
    float peak = mix(8.0, 5.0, clamp(pc.sharpness, 0.0, 1.0));
    vec3 w = amp * (1.0 / peak) * pc.sharpness;

    vec3 sharpened = c * (1.0 + 4.0 * w) - (a + b + d + e) * w;
    outColor = vec4(clamp(sharpened, 0.0, 1.0), 1.0);
}
