#version 450

// Final pass of the frame: resolves the linear HDR scene color -- pass 1's
// opaque content plus, if any ran, the WBOIT composite's translucent
// contribution, both already combined into one R16G16B16A16_SFLOAT image
// (VulkanPipeline.cpp's createColorResources/createOitResources) -- into
// the swapchain's LDR sRGB image. This is the only place color leaves
// linear space for the whole frame; shader.frag/shader_oit.frag both stay
// linear all the way through specifically so this can tonemap the fully
// composited result once, instead of each pass compressing its own
// contribution on a separate curve before they're ever added together.
//
// Vertex stage is oit_composite.vert -- its "fullscreen triangle from
// gl_VertexIndex alone" trick and its single `fragUV` output are exactly
// what this needs too, so this pipeline just reuses that shader module
// rather than duplicating it (see createTonemapPipeline, VulkanPipeline.cpp).
layout(location = 0) in vec2 fragUV;

layout(location = 0) out vec4 outColor;

// Point-sampled 1:1 against the swapchain's own resolution -- no filtering
// is meaningful here, every output pixel reads exactly one input texel.
// (A binding 1 `blurredColor` sampler used to sit here for the standalone
// whole-scene "Blur" effect -- removed entirely along with that effect,
// user decision -- so bloomColor/colorGradeLUT below shifted down one slot.)
layout(binding = 0) uniform sampler2D hdrColor;
// The Bloom effect's blurred bright-pass result (bloomResultImage,
// VulkanApp.h) -- gets added on top of the scene (see main() below), scaled
// by pc.bloomIntensity (0 when Bloom is off), rather than blended toward it.
// Always sampled, never conditionally bound -- toggling Bloom is a value
// change, not a descriptor rebind.
layout(binding = 1) uniform sampler2D bloomColor;
// 32x32x32 lattice baked once in createColorGradeLUTResources() (VulkanApp.h/
// .cpp) -- device-lifetime, always bound regardless of whether Color Grading
// is on, same "always sampled, toggle is a value not a bind" reasoning as
// bloomColor above (pc.colorGradeAmount, 0 when off, is what actually
// controls whether this contributes anything).
layout(binding = 2) uniform sampler3D colorGradeLUT;

layout(push_constant) uniform PushConstants {
    // GraphicsSettingsUI's Exposure slider -- a plain linear multiplier
    // applied before tonemapping, the same role "exposure" plays on a
    // real camera: it doesn't change the tonemap curve itself, just how
    // bright a scene has to be before that curve starts rolling off.
    float exposure;
    // GraphicsSettingsUI's Bloom "Intensity" slider, already zeroed when
    // Bloom is off -- see TonemapPushConstants' comment, VulkanTypes.h, for
    // why this is an additive multiplier rather than a mix() target.
    float bloomIntensity;
    // GraphicsSettingsUI's Color Grading "Amount" slider, already zeroed
    // when Color Grading is off -- see TonemapPushConstants' comment,
    // VulkanTypes.h. mix() weight toward the LUT-graded color, applied last.
    float colorGradeAmount;
} pc;

// ACES filmic tonemap, Narkowicz 2015's compact analytic fit of the
// reference ACES RRT+ODT curve -- operates on and returns linear-light
// values in [0, ~), clamped to [0,1] for direct display. Chosen over a
// plain Reinhard for the filmic highlight rolloff and contrast it's
// designed to approximate without needing a LUT.
vec3 acesFilm(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// Interleaved gradient noise (Jimenez, "Next Generation Post Processing in
// Call of Duty: Advanced Warfare", 2014) -- a cheap, well-distributed
// per-pixel [0,1) value with no texture fetch needed. Used below purely to
// break up 8-bit banding, not for any lighting purpose.
float ditherNoise(vec2 fragCoord) {
    return fract(52.9829189 * fract(dot(fragCoord, vec2(0.06711056, 0.00583715))));
}

// Real sRGB OETF/EOTF (not an approximate pow(2.2)) -- needed because the
// dither below has to land as ~1 LSB in the *actual* encoded domain the
// swapchain's SRGB view will produce, and the sRGB curve's slope varies with
// brightness (a fixed offset in linear space would over-dither shadows and
// under-dither highlights).
vec3 linearToSrgb(vec3 c) {
    return mix(1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, c * 12.92, lessThan(c, vec3(0.0031308)));
}
vec3 srgbToLinear(vec3 c) {
    return mix(pow((c + 0.055) / 1.055, vec3(2.4)), c / 12.92, lessThan(c, vec3(0.0031308)));
}

void main() {
    // Bloom adds on top of the sharp scene rather than mixing toward it --
    // it only ever lifts already-bright areas (bloom_threshold.frag's
    // soft-knee extract), so additive is the correct combine here, not a
    // mix(). In linear HDR space, same as everything else in this pipeline
    // before exposure/tonemap.
    vec3 scene = texture(hdrColor, fragUV).rgb;
    scene += texture(bloomColor, fragUV).rgb * pc.bloomIntensity;
    vec3 hdr = scene * pc.exposure;
    // The swapchain's sRGB view format gamma-encodes on write automatically
    // -- this only needs to compress range (acesFilm), not degamma, same
    // reasoning the old inline Reinhard tonemap relied on.
    vec3 tonemapped = acesFilm(hdr);
    // Color grade looks up the LUT with the already-tonemapped (display-
    // referred, [0,1]) color as its own UVW coordinate -- baking the grade
    // for a linear HDR input isn't meaningful, a LUT can only usefully cover
    // a bounded [0,1]^3 cube, same reason every game engine's LUT grade
    // stage sits after tonemapping rather than before.
    vec3 graded = texture(colorGradeLUT, tonemapped).rgb;
    vec3 final = mix(tonemapped, graded, pc.colorGradeAmount);

    // Dither right before the swapchain's automatic linear->sRGB encode-on-
    // write quantizes this down to 8 bits/channel. Smooth, low-frequency
    // regions (sky, flat-lit walls with no texture detail to mask the steps)
    // band the hardest here since there's nothing else breaking up the
    // gradient -- perturbing by ~1 encoded LSB per pixel turns a visible hard
    // edge into imperceptible noise instead. Round-tripping through the real
    // sRGB curve (not the linear color directly) so the perturbation is
    // actually ~1 LSB in the space that gets quantized, not 1/255 of the
    // pre-encode linear value.
    vec3 encoded = linearToSrgb(clamp(final, 0.0, 1.0));
    float dither = (ditherNoise(gl_FragCoord.xy) - 0.5) / 255.0;
    vec3 dithered = srgbToLinear(clamp(encoded + dither, 0.0, 1.0));

    outColor = vec4(dithered, 1.0);
}
