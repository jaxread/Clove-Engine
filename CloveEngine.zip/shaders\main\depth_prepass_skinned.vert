#version 450

// Skinned variant of depth_prepass.vert -- pairs with the SAME
// depth_prepass.frag, reused unchanged (exactly the way shader_skinned.vert
// used to pair with shader.frag before skinned characters moved into the
// deferred G-buffer). Skinning math is copied verbatim from
// shader_skinned.vert's main().
//
// Own dedicated 2-set pipeline layout (SkinnedRenderer's
// depthPrepassPipelineLayout_) -- deliberately smaller than the old
// forward-shaded pipeline's 4 sets, since no lighting happens in the depth
// pre-pass: no envMap, no cluster-lighting data needed here at all.
//   set 0 = YOUR existing frame descriptor set (descriptorSetLayout),
//           reused by handle -- this stage reads the camera UBO
//           (binding 0) out of it; depth_prepass.frag reads MaterialBuffer
//           (binding 1) and bindlessTextures (binding 4) from the same set.
//   set 1 = skinning data OWNED by SkinnedRenderer: per-instance transforms
//           (binding 0) and the joint-matrix palette (binding 1) -- the
//           same set1Layout_ the old forward pipeline used (just bound at
//           set 3 there, since sets 1/2 were taken by envMap/cluster data
//           it needed and this pipeline doesn't).

layout(set = 0, binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
} ubo;

struct SkinnedInstanceData {
    mat4 model;
    vec4 normalMatrixCol0;
    vec4 normalMatrixCol1;
    vec4 normalMatrixCol2;
    int materialIndex;
    int jointOffset;   // first index into the palette for this instance's rig
    int jointCount;
    int pad0;
};

layout(std430, set = 1, binding = 0) readonly buffer SkinnedInstanceBuffer {
    SkinnedInstanceData instances[];
} instanceBuffer;

layout(std430, set = 1, binding = 1) readonly buffer JointPalette {
    mat4 jointMatrices[];
} palette;

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec4 inNormal;
layout(location = 2) in vec2 inUV;
layout(location = 3) in vec4 inTangent;
layout(location = 4) in vec4 inColor;
layout(location = 5) in vec2 inUV2;
layout(location = 6) in uvec4 inJoints;
layout(location = 7) in vec4 inWeights;

layout(location = 2) out vec2 fragUV;
layout(location = 4) flat out int fragMaterialIndex;
layout(location = 5) out vec4 fragColor;
layout(location = 6) out vec2 fragUV2;
// See depth_prepass.vert's identical outputs for what these carry --
// view-space normal/tangent (post-skinning) and linear view-space depth.
layout(location = 7) out vec3 fragViewNormal;
layout(location = 8) out float fragViewPosZ;
layout(location = 9) out vec4 fragViewTangent;

void main() {
    SkinnedInstanceData inst = instanceBuffer.instances[gl_InstanceIndex];
    int base = inst.jointOffset;

    mat4 skin =
        inWeights.x * palette.jointMatrices[base + int(inJoints.x)] +
        inWeights.y * palette.jointMatrices[base + int(inJoints.y)] +
        inWeights.z * palette.jointMatrices[base + int(inJoints.z)] +
        inWeights.w * palette.jointMatrices[base + int(inJoints.w)];

    if (inWeights.x + inWeights.y + inWeights.z + inWeights.w < 1e-4)
        skin = mat4(1.0);

    vec4 skinnedPos = skin * vec4(inPosition, 1.0);
    vec4 viewPos = ubo.view * (inst.model * skinnedPos);
    gl_Position = ubo.proj * viewPos;
    fragViewPosZ = -viewPos.z;

    // World normal/tangent via skinning then the instance's precomputed
    // inverse-transpose (handles non-uniform scale correctly, same
    // reasoning as shader_skinned.vert's own transform), then world -> view
    // via just the view matrix's upper 3x3 -- safe without its own
    // inverse-transpose since the camera view matrix is rigid, same
    // reasoning depth_prepass.vert's own normal transform relies on.
    mat3 normalMatrix = mat3(inst.normalMatrixCol0.xyz, inst.normalMatrixCol1.xyz, inst.normalMatrixCol2.xyz);
    mat3 skin3 = mat3(skin);
    vec3 worldNormal = normalize(normalMatrix * (skin3 * inNormal.xyz));
    fragViewNormal = normalize(mat3(ubo.view) * worldNormal);

    vec3 worldTangent = normalize(mat3(inst.model) * (skin3 * inTangent.xyz));
    fragViewTangent = vec4(normalize(mat3(ubo.view) * worldTangent), inTangent.w);

    fragUV = inUV;
    fragUV2 = inUV2;
    fragMaterialIndex = inst.materialIndex;
    fragColor = inColor;
}
