#version 450

// SSAO temporal accumulation -- reprojects and blends last real frame's own
// blended AO result (ssaoHistory) with this frame's fresh (spatially
// blurred) result (ssaoCurrent). Runs right after SSAO's own 2-pass
// separable bilateral blur (recordCommandBuffer's "SSAO pass"), before pass
// 1 ever samples the result.
//
// Reprojection: this view -> world -> previous view -> previous clip --
// finds where this fragment's own world position was on screen last frame
// using only the previous camera's view matrix. No per-object motion-vector
// buffer exists in this engine
// (scene geometry -- INCLUDING animated skinned characters -- has no
// per-vertex velocity output), so reprojection here only ever accounts for
// CAMERA motion. An animating character's own AO still mostly self-corrects
// frame to frame because its depth/normal (both checked below) change as it
// moves, tripping the same disocclusion rejection any other newly-revealed
// surface would -- just without the smoother tracking true motion vectors
// would give it. Real per-object motion vectors are a bigger, separate
// feature, not added here.
//
// Robustness (this is what actually fixes SSAO's fuzzy/blotchy/swimming
// look -- NOT just a stronger blur):
//   1. History is rejected/faded CONTINUOUSLY (not a hard on/off) based on
//      BOTH depth and normal similarity at the reprojected point. A hard
//      cutoff pops visibly every single frame something crosses its exact
//      threshold as the camera moves, which reads as swimming/shimmer.
//   2. History is clamped to the current frame's own local 3x3 neighborhood
//      (min/max box clip -- the same technique real-time TAA uses) BEFORE
//      blending. This is what actually prevents "large moving blobs"/
//      ghosting when Temporal Smoothing is pushed high: a stale history
//      value outside what the current frame's own geometry can support gets
//      pulled back into range instead of re-blending into itself forever.
//   3. The blend amount is adaptive, not fixed: pc.historyBlend
//      (GraphicsUI's "Temporal Smoothing" slider) is a CEILING, scaled down
//      per-pixel by how far the reprojected point actually moved on screen
//      this frame. Static pixels get the full slider value and converge
//      cleanly; fast-moving ones fall back toward the fresh (already
//      denoised) current-frame result instead of smearing.
layout(location = 0) in vec2 fragUV;

// [0] = the stable result envMapDescriptorSet's binding 1 (ssaoTexture,
// shader.frag/shader_oit.frag) always points at -- see
// ssaoTemporalResultImage's own comment, VulkanApp.h, for why this is a
// separate image from [1] below rather than pointing that binding directly
// at the ping-pong pair.
layout(location = 0) out vec4 outColor;
// [1]/[2] = this frame's own write side of the AO/depth history ping-pong
// pair (ssaoHistoryImages/ssaoDepthHistoryImages, VulkanApp.h) -- what NEXT
// frame's own reprojection reads as "last frame's result". Holds the exact
// same value as outColor above; only the different downstream role (fixed
// single target vs. next frame's read side) makes 2 separate targets
// worthwhile here (see ssaoTemporalResultImage's own comment for the
// per-frame-descriptor-rewrite hazard this avoids).
layout(location = 1) out vec4 outHistory;
layout(location = 2) out float outDepthHistory;

// This frame's fresh, spatially (bilaterally) blurred AO result
// (ssaoBlurredImage) -- RGB=plain view-space geometric normal, A=AO, same
// packing ssao.frag's own outColor uses. The RGB channel doubles as this
// pass' own "normal" input
// for history rejection below -- no separate normal buffer binding needed,
// it's already carried right here (same trick reused for both ssaoCurrent
// and ssaoHistory, whose RGB is exactly this same packing one frame back).
layout(binding = 0) uniform sampler2D ssaoCurrent;
// Same depth source SSAO's own sample pass reads (depthResolveImage/
// depthImage depending on MSAA) -- re-bound here under this pass' own
// descriptor set.
layout(binding = 1) uniform sampler2D depthBuffer;
// Last real frame's own blended result (outHistory above), read from
// whichever of ssaoHistoryImages ISN'T this frame's write target -- see
// VulkanApp::ssaoHistoryIndex's own comment for the per-frame ping-pong.
layout(binding = 2) uniform sampler2D ssaoHistory;
// Last real frame's own view-space depth at each pixel, same ping-pong as
// ssaoHistory above -- what the disocclusion check below compares this
// frame's own depth against.
layout(binding = 3) uniform sampler2D depthHistory;
// proj/invProj/invView, reused from SsaoUbo (VulkanTypes.h, ssaoUboBuffers)
// -- precomputed ONCE per frame on the CPU (updateUniformBuffer) instead of
// this shader calling inverse(proj)/inverse(view) itself on EVERY fragment
// invocation for values identical across the whole draw, the same "why a
// UBO" reasoning SsaoPushConstants' own comment already gives for ssao.frag's
// own proj/invProj.
layout(binding = 4) uniform SsaoUboBlock {
    mat4 proj;
    mat4 invProj;
    mat4 invView;
} ssaoUbo;

layout(push_constant) uniform PushConstants {
    // Last real frame's own view -- see ssaoPrevView's own comment,
    // VulkanApp.h. Combined with ssaoUbo.invView/proj above (both THIS
    // frame's) to find where a given world point was on screen last frame.
    mat4 prevView;
    // GraphicsUI's "Temporal Smoothing" slider -- a CEILING on how much
    // history this pixel is allowed to use, scaled down per-pixel by the
    // depth/normal/motion confidence computed below. See this file's own
    // top comment, point 3.
    float historyBlend;
} pc;

void main() {
    float depth = texture(depthBuffer, fragUV).r;
    vec4 current = texture(ssaoCurrent, fragUV);

    if (depth >= 1.0) {
        // Sky/background -- ssao.frag's own main() already special-cases
        // this (a fixed placeholder, see its comment), nothing meaningful
        // to reproject or accumulate here either. kFarDepthHistory is
        // deliberately far outside any real view-space depth in this scene
        // so a real surface later appearing at this screen position never
        // spuriously passes the disocclusion check against stale sky data.
        const float kFarDepthHistory = 1e6;
        outColor = current;
        outHistory = current;
        outDepthHistory = kFarDepthHistory;
        return;
    }

    // Reconstruct this fragment's own view-space position/depth from depth
    // -- identical trick ssao.frag already uses.
    vec4 ndc = vec4(fragUV * 2.0 - 1.0, depth, 1.0);
    vec4 viewPosH = ssaoUbo.invProj * ndc;
    vec3 viewPos = viewPosH.xyz / viewPosH.w;
    float viewDepth = -viewPos.z;

    // This view -> world -> previous view -> previous clip -- see this
    // file's own top comment for why world space is what makes this valid
    // regardless of how far the camera moved between frames.
    vec4 worldPosH = ssaoUbo.invView * vec4(viewPos, 1.0);
    vec4 prevViewPosH = pc.prevView * worldPosH;
    vec4 prevClip = ssaoUbo.proj * prevViewPosH;
    vec3 prevNdc = prevClip.xyz / prevClip.w;
    vec2 prevUV = prevNdc.xy * 0.5 + 0.5;

    // Valid only if the reprojected point actually lands on screen and was
    // in front of the previous camera -- otherwise (a point that just came
    // into view, or the very first frame with no real history yet) there's
    // nothing sensible to blend with.
    bool onScreen = prevClip.w > 0.0 &&
        prevUV.x >= 0.0 && prevUV.x <= 1.0 &&
        prevUV.y >= 0.0 && prevUV.y <= 1.0;

    vec4 blended = current;
    if (onScreen) {
        float depthPrev = texture(depthHistory, prevUV).r;
        vec4 history = texture(ssaoHistory, prevUV);

        // Continuous depth confidence (falls off between 5% and 15% of this
        // fragment's own linear depth) instead of a hard cutoff -- see this
        // file's own top comment, point 1.
        float depthDelta = abs(viewDepth - depthPrev);
        float depthConfidence = 1.0 - smoothstep(0.05 * viewDepth, 0.15 * viewDepth, depthDelta);

        // Normal confidence -- current/history RGB both already carry this
        // pass' own normal (see their shared binding comments above), so
        // this needs no extra texture binding. Catches a rotated/changed
        // surface (or a genuinely different one) even in the rarer cases
        // where depth alone doesn't move enough to trip the check above.
        float normalDot = dot(normalize(current.rgb), normalize(history.rgb));
        float normalConfidence = smoothstep(0.4, 0.9, normalDot);

        // Motion confidence -- how far (in pixels) the reprojected point
        // moved on screen this frame, a cheap proxy for "how much is
        // changing here" given this pass has no true per-object motion
        // vectors (see this file's own top comment). Large screen-space
        // motion falls back toward the fresh current-frame result instead
        // of blending in something sampled from a very different part of a
        // moving picture.
        vec2 motionPixels = (fragUV - prevUV) * vec2(textureSize(ssaoCurrent, 0));
        float motionConfidence = 1.0 - clamp(length(motionPixels) / 24.0, 0.0, 1.0);

        float confidence = depthConfidence * normalConfidence * motionConfidence;

        if (confidence > 0.0) {
            // Neighborhood AABB clamp (3x3, around THIS fragment's own UV --
            // clamping against the surface actually visible here right now,
            // not the reprojected one): pulls a stale/outlier history value
            // back into the range the current frame's own local
            // neighborhood actually supports before it's allowed to blend
            // in at all. See this file's own top comment, point 2, for why
            // this (not a stronger blur) is what stops ghosting/"large
            // moving blobs" once Temporal Smoothing is pushed high.
            vec2 texel = 1.0 / vec2(textureSize(ssaoCurrent, 0));
            vec4 neighMin = current;
            vec4 neighMax = current;
            for (int y = -1; y <= 1; ++y) {
                for (int x = -1; x <= 1; ++x) {
                    if (x == 0 && y == 0) continue;
                    vec4 tap = texture(ssaoCurrent, fragUV + vec2(x, y) * texel);
                    neighMin = min(neighMin, tap);
                    neighMax = max(neighMax, tap);
                }
            }
            vec4 clampedHistory = clamp(history, neighMin, neighMax);

            float adaptiveBlend = pc.historyBlend * confidence;
            blended = mix(current, clampedHistory, adaptiveBlend);
        }
    }

    outColor = blended;
    outHistory = blended;
    outDepthHistory = viewDepth;
}
