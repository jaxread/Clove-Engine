#version 450
// rt_debug.vert -- fullscreen triangle for the TLAS primary-ray debug pass.
// No vertex buffer: positions are generated from gl_VertexIndex (draw 3 verts).

layout(location = 0) out vec2 outUV;

void main() {
    outUV = vec2((gl_VertexIndex << 1) & 2, gl_VertexIndex & 2);
    gl_Position = vec4(outUV * 2.0 - 1.0, 0.0, 1.0);
}
