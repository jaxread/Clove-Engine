// 460 for general-purpose GLSL features used throughout this shader.
#version 460
#extension GL_EXT_nonuniform_qualifier : enable

layout(location = 0) in vec3 fragWorldPos;
layout(location = 1) in vec3 fragNormal;
layout(location = 2) in vec2 fragUV;
layout(location = 3) in vec4 fragTangent;
layout(location = 4) flat in int fragMaterialIndex;
layout(location = 5) in vec4 fragColor;
// glTF's TEXCOORD_1 -- see Vertex::uv2's comment (VulkanApp.h). Which
// texture types actually sample this instead of fragUV is decided
// per-material by Material::texCoordSets below.
layout(location = 6) in vec2 fragUV2;
// No precomputed light-space-position varying from shader.vert (unlike
// before cascades existed): which cascade covers a given fragment depends
// on its view-space depth, a per-fragment quantity the vertex stage can't
// resolve early the way a single fixed lightViewProj multiply once allowed.
// sampleShadow() below does the whole cascade-select-and-project itself
// from fragWorldPos, which it also needs raw (not pre-projected) anyway to
// offset the sampled point along the surface normal first (normal-offset
// shadow bias) -- see its comment -- an offset that needs gl_FrontFacing
// (for double-sided backface flipping), which only exists in the fragment
// shader.

layout(location = 0) out vec4 outColor;

layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;   // points FROM the light TOWARD the scene
    vec3 lightColor; // already color * intensity
    // xyz = ambient tint color, w = intensity (already 0 when the
    // LightingUI checkbox is off -- see updateUniformBuffer, VulkanRender.cpp).
    vec4 ambientColorIntensity;
    // GraphicsSettingsUI's "Force Alpha-Test for BLEND materials" toggle,
    // mirrored here each frame by updateUniformBuffer -- see the
    // forceMaskForBlend() comment in VulkanApp.h. 0/1, not bool: matches
    // the C++ side's plain int (GLSL UBO members can't be bool).
    int forceMaskForBlend;
    // View-projection matrix of each cascade of the shadow-casting
    // directional light -- see the C++-side UniformBufferObject::
    // lightViewProj comment (VulkanApp.h) for how each is built.
    // sampleShadow() below picks one entry per-fragment (by view-space
    // depth against cascadeSplitDepths below) and projects fragWorldPos
    // with it. Literal 4 -- must match kNumShadowCascades (VulkanTypes.h).
    mat4 lightViewProj[4];
    // View-space distance (from the camera) of each cascade's *far* edge --
    // sampleShadow() compares a fragment's own view-space depth against
    // these to pick which cascade (and lightViewProj entry) covers it,
    // blending across a small band near each boundary to avoid a hard seam.
    vec4 cascadeSplitDepths;
    // World-space distance one shadow-map texel covers at each cascade's
    // current orthographic fit, already multiplied by LightingUI's "Normal
    // Offset" slider (texels) -- see updateUniformBuffer, VulkanRender.cpp.
    // One component per cascade (.x = cascade 0, etc.), not a real GLSL
    // float[4] -- see the identical packing on the C++ side
    // (UniformBufferObject::shadowNormalOffsetWorldSize, VulkanTypes.h) for
    // why. These are the *base* (grazing-incidence) offsets; sampleShadow()
    // below further scales whichever component it selects by (1 - N.L)
    // before pushing the sampled point along the surface normal, so it's
    // only the full amount at a grazing light angle and shrinks toward 0 at
    // normal incidence. Not read by shader.vert/shadow.vert, so (like
    // forceMaskForBlend above) it's fine as a trailing member.
    vec4 shadowNormalOffsetWorldSize;
    // LightingUI's "Debug: Visualize Cascades" checkbox -- see main()'s use
    // below.
    int shadowDebugVisualizeCascades;
    // GraphicsSettingsUI's SSAO "Enabled" checkbox -- see main()'s ambient
    // term below for the only place this is read.
    int ssaoEnabled;
    // Everything below is appended after the C++ struct's original last
    // member (ssaoEnabled) -- see UniformBufferObject's own comment
    // (VulkanTypes.h) for why new fields are always appended at the very end
    // rather than inserted in the middle.
    //
    // Tunable floor under the final direct+ambient result (GraphicsUI's
    // "Ambient" section) -- see main()'s use below.
    float minAmbientFloor;
    // Specular-aliasing fix (GraphicsUI's "Specular AA" section) -- see
    // main()'s use of both, and normalFiltering()'s own comment, for the
    // full reasoning.
    float roughnessFloor;
    int geometricSpecularAAEnabled;
    // Day/night stepped-brightness fix -- see its own comment,
    // VulkanTypes.h. Multiplies into sampleEnvironment()'s return and
    // unlitMaterialFallback()'s direct env sample below, so the (lazily
    // rebaked) cubemap's own detail can stay cheaply cached while its
    // perceived brightness still fades smoothly every frame.
    float envBrightnessCorrection;
    // GraphicsUI's PCSS section -- see pcfShadow()'s use below, and the
    // identical fields' comments on the C++ side (UniformBufferObject,
    // VulkanTypes.h) for the full reasoning.
    int pcssEnabled;
    float pcssLightSize;
    float pcssQuality;
    // GraphicsUI's "Foliage Translucency" Strength slider -- see its use
    // below near the direct-light block (0 disables the term entirely).
    float foliageTranslucencyStrength;
    // --- Clustered light culling ---
    // How many of lightsBuffer's entries are valid this frame -- unused
    // directly here (pointLightsContribution() below only ever touches a
    // fragment's own cluster's assigned lights, see clusterLightGrid),
    // mirrors the C++ side's identical comment (UniformBufferObject::
    // lightCount, VulkanTypes.h).
    int lightCount;
    // Cluster grid dimensions this frame's clusterAABBBuffer/
    // clusterLightGridBuffer were built against -- .xyz = (gridX, gridY,
    // gridZ), .w unused.
    ivec4 clusterGridDim;
    // Logarithmic depth-slicing constants (Doom 2016 clustered shading) --
    // clusterIndexForFragment() below uses these to turn view-space depth
    // into a depth-slice index; see the identical C++-side comment
    // (UniformBufferObject::clusterDepthSliceScaleBias, VulkanTypes.h) for
    // the formula.
    vec2 clusterDepthSliceScaleBias;
    // Screen-space tile size in pixels -- clusterIndexForFragment() divides
    // gl_FragCoord.xy by this to find which tile column/row a fragment
    // falls into.
    vec2 clusterScreenTileSize;
} ubo;

// --- Clustered light culling: SSBOs (own set, 2) ---
// Own descriptor set (not more bindings crammed into set 0 or 1) since
// these are populated by a separate compute pre-pass (cluster_aabb_build.comp/
// light_cull.comp, VulkanRender.cpp) each frame rather than written
// alongside everything else in set 0 -- keeping them on their own set keeps
// that compute pass' descriptor layout simple and independent of set 0's
// own (much larger, bindless-texture-carrying) layout. Set 1 is already
// envMapSetLayout (envMap/ssaoTexture/shadowMapRaw, see its own comment
// further up), so this is set 2.
struct Light {
    vec4 posRange;        // xyz = world pos, w = range
    vec4 colorIntensity;  // rgb = color, a = intensity
    vec4 coneDir;         // xyz = world dir, w = 1 if cone enabled
    vec4 coneAngles;      // x = cos(inner), y = cos(outer)
};
layout(std430, set = 2, binding = 0) readonly buffer LightsBuffer {
    Light lights[];
};

struct ClusterLightGridEntry {
    uint offset;
    uint count;
};
layout(std430, set = 2, binding = 1) readonly buffer ClusterLightIndicesBuffer {
    uint clusterLightIndices[];
};
layout(std430, set = 2, binding = 2) readonly buffer ClusterLightGridBuffer {
    ClusterLightGridEntry clusterLightGrid[];
};

// Turns a fragment's screen position + view-space depth (both readily
// available at every call site below) into a flat index into
// clusterLightGrid -- same grid buildClusterAABBs()/cullLightsForCurrentFrame()
// (VulkanRender.cpp) built this frame's clusterAABBBuffer/
// clusterLightGridBuffer against, so this MUST use the identical formula
// cluster_aabb_build.comp's own depth-slicing does (see its comment there).
uint clusterIndexForFragment(vec2 fragCoord, float fragViewDepth) {
    ivec3 gridDim = ubo.clusterGridDim.xyz;
    ivec2 tileXY = ivec2(fragCoord / ubo.clusterScreenTileSize);
    tileXY = clamp(tileXY, ivec2(0), gridDim.xy - ivec2(1));
    // fragViewDepth is a positive distance-from-camera value (see its own
    // call sites below) -- log2 of a positive value, matches
    // cluster_aabb_build.comp's own "sliceNear = -zNear * pow(...)" (that
    // function works in signed view-space Z, this one in the positive
    // distance convention already used elsewhere in this file).
    int slice = int(log2(max(fragViewDepth, 0.0001)) * ubo.clusterDepthSliceScaleBias.x - ubo.clusterDepthSliceScaleBias.y);
    slice = clamp(slice, 0, gridDim.z - 1);
    return uint(tileXY.x + gridDim.x * (tileXY.y + gridDim.y * slice));
}


// Cascaded shadow map from the directional light's point of view
// (shaders/shadow.vert, VulkanPipeline.cpp's createShadowPipeline), one
// array layer per cascade. Declared as sampler2DArrayShadow -- paired with
// shadowSampler's compareEnable=VK_TRUE (VulkanResources.cpp) -- so a single
// texture() call returns a hardware-filtered (bilinear) pass/fail against
// the reference depth passed as its 4th (Dref) argument, rather than
// needing a separate manual comparison.
layout(binding = 2) uniform sampler2DArrayShadow shadowMap;

// One shared bindless array for every texture type (base color, metallic-
// roughness, normal, occlusion, emissive) -- GltfLoader.cpp just hands out
// more indices into the same array rather than needing a separate binding
// per texture type. nonuniformEXT is required whenever the index used to
// access this array isn't dynamically uniform across the invocation group,
// which is the case here since different fragments/draws use different
// material indices.
//
// This is binding 3, not 1: VK_DESCRIPTOR_BINDING_VARIABLE_DESCRIPTOR_COUNT_BIT
// (set on this binding in createDescriptorSetLayout, VulkanPipeline.cpp) is
// only legal on the highest-numbered binding in the set, so this has to sit
// after MaterialBuffer and shadowMap above rather than before them.
layout(binding = 4) uniform sampler2D bindlessTextures[];

// Baked environment cubemap (VulkanApp.h's envMapImage/envMapView) -- a
// small HDR bake of the procedural sky (shaders/sky_cubemap.frag), reused
// (via its own ordinary mip chain, not a real convolution/GGX prefilter) as
// a cheap stand-in for both diffuse irradiance and prefiltered specular --
// see sampleEnvironment() below. Set 1, not set 0: descriptorSetLayout's
// bindlessTextures[] above has to stay the *highest*-numbered binding in
// its set (VARIABLE_DESCRIPTOR_COUNT_BIT's constraint), so this lives in
// its own small dedicated set instead of being squeezed in ahead of it --
// see createEnvironmentResources' comment, VulkanResources.cpp.
layout(set = 1, binding = 0) uniform samplerCube envMap;

// SSAO's final blurred result (VulkanApp.h's ssaoBlurredImage) -- rides
// along on this same set purely because it already exists this early (see
// createEnvironmentResources' comment, VulkanResources.cpp, for why this
// binding is unrelated to environment mapping but lives here anyway rather
// than a dedicated set 2 just for one more sampler). Sampled by screen-space
// UV (gl_FragCoord.xy / render target size), not fragUV -- this is a
// full-screen buffer, not a per-material texture.
layout(set = 1, binding = 1) uniform sampler2D ssaoTexture;

// Same shadowImage as shadowMap (binding 2, set 0) but through a
// non-comparison sampler (VulkanApp.h's shadowRawSampler) -- PCSS's
// blockerSearch() below needs actual stored depth values to average, which
// shadowMap's comparison sampler can only ever answer as a 0/1 pass/fail
// (see shadowRawSampler's own comment, VulkanResources.cpp, for why a
// second sampler over the same image was needed). Rides along on set 1 for
// the same "descriptorSetLayout's bindless array must stay the highest
// binding" reason ssaoTexture above does.
layout(set = 1, binding = 2) uniform sampler2DArray shadowMapRaw;

// Mirrors GpuMaterial in VulkanApp.h field-for-field, same order -- see the
// layout comment there for why the std430/C++ byte layouts line up exactly
// with no manual padding needed.
struct Material {
    vec4 baseColorFactor;
    vec4 emissiveFactor;
    int baseColorTexture;
    int metallicRoughnessTexture;
    int normalTexture;
    int occlusionTexture;
    int emissiveTexture;
    float metallicFactor;
    float roughnessFactor;
    float normalScale;
    float occlusionStrength;
    float alphaCutoff;
    int alphaMode; // 0 = OPAQUE, 1 = MASK, 2 = BLEND
    int doubleSided;
    // Bit N set means that texture type samples fragUV2 (TEXCOORD_1)
    // instead of fragUV (TEXCOORD_0) -- see texCoordFor() below and
    // GpuMaterial::texCoordSets' comment (VulkanApp.h) for the bit-order
    // convention (0=baseColor, 1=metallicRoughness, 2=normal, 3=occlusion,
    // 4=emissive).
    int texCoordSets;
    // Height/displacement map for the tessellated POM pipeline -- see
    // GpuMaterial::heightTexture/heightScale's comment (VulkanTypes.h).
    // -1 = no heightmap, meaning this fragment shader never runs the
    // parallax step below (this pipeline is also shared by the ordinary,
    // non-tessellated pass -- see createGraphicsPipeline, VulkanPipeline.cpp
    // -- where every material has heightTexture == -1 by construction, since
    // only pom_displace-pipeline draws ever reach a material that has one).
    int heightTexture;
    float heightScale;
    int _pad0;
};

layout(std430, binding = 1) readonly buffer MaterialBuffer {
    Material materials[];
} materialBuffer;

const float kZeroAlphaEpsilon = 0.02;
const float kPi = 3.14159265359;

// Cook-Torrance microfacet BRDF -- standard GGX distribution + Smith
// geometry term + Schlick Fresnel approximation.
float distributionGGX(vec3 N, vec3 H, float roughness) {
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.0);
    float NdotH2 = NdotH * NdotH;
    float denom = (NdotH2 * (a2 - 1.0) + 1.0);
    denom = kPi * denom * denom;
    return a2 / max(denom, 0.0000001);
}

float geometrySchlickGGX(float NdotV, float roughness) {
    float r = (roughness + 1.0);
    float k = (r * r) / 8.0;
    float denom = NdotV * (1.0 - k) + k;
    return NdotV / max(denom, 0.0000001);
}

float geometrySmith(float NdotV, float NdotL, float roughness) {
    float ggx2 = geometrySchlickGGX(NdotV, roughness);
    float ggx1 = geometrySchlickGGX(NdotL, roughness);
    return ggx1 * ggx2;
}

vec3 fresnelSchlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

// Direct (analytic) light contribution for a single light with the given
// direction (surface-to-light, normalized), radiance, and material terms --
// shared by the sun, point-light, and spotlight paths below.
vec3 evaluateDirectLight(vec3 N, vec3 V, vec3 L, vec3 radiance, vec3 albedo, float roughness, float metallic, vec3 F0) {
    vec3 H = normalize(V + L);
    float NdotL = max(dot(N, L), 0.0);
    float NdotV = max(dot(N, V), 0.0);

    float NDF = distributionGGX(N, H, roughness);
    float G = geometrySmith(NdotV, NdotL, roughness);
    vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);

    vec3 numerator = NDF * G * F;
    float denom = 4.0 * NdotV * NdotL + 0.0001;
    vec3 specular = numerator / denom;

    vec3 kS = F;
    vec3 kD = (vec3(1.0) - kS) * (1.0 - metallic);

    return (kD * albedo / kPi + specular) * radiance * NdotL;
}


// Tangent-space UV offset from the parallax-occlusion ray-march in main()
// below, applied by texCoordFor() to every subsequent texture sample
// (baseColor, metallic-roughness, normal, occlusion, emissive all route
// through texCoordFor already) -- a plain mutable global rather than
// threading an extra parameter through every one of those call sites.
// Stays (0,0) for materials with no heightTexture, so this is a no-op for
// every material that isn't part of the POM pipeline.
vec2 parallaxOffset = vec2(0.0);

// Picks fragUV vs fragUV2 for one texture type on this material -- bit is
// 1<<N for texture type N, matching Material::texCoordSets' bit order.
vec2 texCoordFor(int texCoordSets, int bit) {
    return (((texCoordSets & bit) != 0) ? fragUV2 : fragUV) + parallaxOffset;
}

// +1 on a front-facing fragment, -1 on a back-facing one. gl_FrontFacing is
// only meaningful in the fragment shader (rasterization decides it, not the
// vertex stage), which is why this can't live in shader.vert alongside the
// rest of the normal transform. Only actually matters for double-sided
// materials (VulkanRender.cpp sets VK_CULL_MODE_NONE for those, per each
// material's doubleSided flag) -- a single-sided material's backfaces are
// culled before rasterization ever produces a fragment, so this is always
// +1 there regardless. Without flipping N by this on a double-sided
// backface, the interpolated normal keeps pointing the way it did for the
// *front* face -- i.e. into the surface from the camera's side on the back
// -- which sends NdotL/NdotV dark or wrong, and turns normal-mapped
// backfaces inside-out. The tangent's handedness (fragTangent.w) needs the
// same flip wherever a TBN gets built from it, for the same reason.
float frontFacingSign() {
    return gl_FrontFacing ? 1.0 : -1.0;
}

// Actual shadow map resolution, set by VulkanPipeline.cpp's
// createGraphicsPipeline() to match VulkanApp.h's kShadowMapSize exactly via
// a specialization constant, rather than this and shadow.vert/VulkanApp.h
// each hardcoding their own copy of the number -- three independent copies
// of the same constant is exactly how they'd eventually silently desync
// (one gets tuned, the other two don't). The 2048.0 here is only a fallback
// for a context that doesn't set the specialization (there isn't one in this
// project), not a value this shader actually runs with.
layout(constant_id = 0) const float kShadowMapSize = 2048.0;

// Highest valid mip index of envMap above (kEnvMapMipLevels - 1,
// VulkanApp.h), set the same specialization-constant way kShadowMapSize is
// -- see its comment for why. 6.0 here (matching the default 7-level chain
// a 64x64 base would produce) is only the GLSL-side fallback, not a value
// this shader actually runs with.
layout(constant_id = 1) const float kMaxEnvLod = 6.0;

// Karis/Lazarov analytic approximation of the environment-BRDF split-sum
// term (Lazarov 2013, "Getting More Physically Based") -- returns a
// (scale, bias) pair applied as `F0 * scale + bias` to a prefiltered
// specular sample, standing in for a real baked 2D BRDF LUT. Deliberately
// the cheap option (a handful of scalar ops, no extra texture/pass) to
// match how the rest of this environment-lighting feature was asked for:
// "even a cheap one, not real convolution".
vec2 envBRDFApprox(float NdotV, float roughness) {
    const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
    const vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
    vec4 r = roughness * c0 + c1;
    float a004 = min(r.x * r.x, exp2(-9.28 * NdotV)) * r.x + r.y;
    return vec2(-1.04, 1.04) * a004 + r.zw;
}

// Single-scattering Rayleigh + Mie sky color -- IDENTICAL copy of
// shaders/sky/sky.frag's own atmosphereColor(); see that file for the full
// rationale/comments. Keep all four copies (sky.frag, sky_cubemap.frag, this
// one, shader_oit.frag's) in sync -- no shared-GLSL-include mechanism exists
// in this codebase.
vec3 atmosphereColor(vec3 dir, vec3 sunDir, vec3 sunColor) {
    const vec3 betaR = vec3(5.8e-6, 13.5e-6, 33.1e-6) * 2.5e5;
    const float betaM = 21e-6 * 2.5e5;
    // Mie asymmetry -- lowered from 0.76, see sky.frag's identical constant
    // for why (the day-cycle "too bright" fix: the phase peak at cosTheta==1
    // scales like 1/(1-g)^3, and hemisphericAmbient() below feeds this
    // function a fixed dir=(0,1,0), so the peak hits whenever the sun
    // transits near zenith -- not just when looking straight at it).
    const float g = 0.65;

    float cosTheta = dot(dir, sunDir);
    float phaseR = 3.0 / (16.0 * kPi) * (1.0 + cosTheta * cosTheta);
    float g2 = g * g;
    float phaseM = (1.0 - g2) / (4.0 * kPi * pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5));

    float cosZenith = max(dir.y, -0.02);
    float zenithDeg = degrees(acos(clamp(cosZenith, -1.0, 1.0)));
    float airmass = 1.0 / (cosZenith + 0.50572 * pow(96.07995 - zenithDeg, -1.6364));

    vec3 extinction = exp(-(betaR + betaM) * airmass);
    vec3 inscatter = (betaR * phaseR + betaM * phaseM) * (1.0 - extinction) / max(betaR + betaM, 1e-6);
    return sunColor * inscatter;
}

// Cheap hemispheric ambient, replacing the old "sample the cubemap's
// flattest mip by N" approximation -- that mip has no cross-face blending
// (generateMipmaps' per-face box-filter chain, VulkanPipeline.cpp), so it
// was 6 flat step-function colors (one per cube face), not a real gradient
// -- the actual cause of flat-looking daytime ambient. This instead
// evaluates the SAME atmosphere model the sky itself uses, straight up, and
// blends it with a plausible ground-bounce color by how much N points up vs
// down -- real directional shading (a ceiling/upward face reads sky-lit, a
// floor/downward face reads ground-bounce-lit) for one extra
// atmosphereColor() call, no texture fetch, no baking. Unlike the cubemap
// sample it replaces, this is always exactly current (evaluated live from
// this frame's own ubo.lightDir/lightColor), so it needs no
// envBrightnessCorrection -- that correction stays scoped to the specular
// half below, which still reads the lazily-rebaked cubemap.
vec3 hemisphericAmbient(vec3 N) {
    vec3 sunDir = normalize(-ubo.lightDir);
    vec3 skyColor = atmosphereColor(vec3(0.0, 1.0, 0.0), sunDir, ubo.lightColor);
    // Plausible ground albedo (dry earth/rock/vegetation average) tinting
    // and dimming the sky color that would be bouncing back up off it -- a
    // stand-in for "what the ground under this scene roughly looks like
    // lit," not sampled from anything.
    const vec3 kGroundAlbedo = vec3(0.30, 0.28, 0.22);
    vec3 groundColor = skyColor * kGroundAlbedo * 0.5;
    return mix(groundColor, skyColor, dot(N, vec3(0.0, 1.0, 0.0)) * 0.5 + 0.5);
}

// Cheap image-based lighting: diffuse now comes from hemisphericAmbient()
// above (real directional sky/ground shading); specular still reuses
// envMap's own ordinary mip chain (generateMipmaps' plain box-filter blit
// downsample, VulkanPipeline.cpp) as a stand-in for prefiltered specular,
// instead of a real GGX importance-sampled prefilter pass -- sampled by a
// roughness-mapped mip level via the reflection vector (roughness 0 ->
// sharpest mip, i.e. a genuine mirror reflection; roughness 1 -> blurriest
// mip). Returns the *sum* of both indirect contributions -- occlusion is
// applied once by the caller, same as before.
vec3 indirectSkyRadiance(vec3 N) {
    return hemisphericAmbient(N);
}

vec3 sampleEnvironment(vec3 N, vec3 V, vec3 albedo, vec3 F0, float roughness, float metallic, bool includeSpecularIBL) {
    vec3 diffuseIBL = indirectSkyRadiance(N) * albedo * (1.0 - metallic);
    if (!includeSpecularIBL) return diffuseIBL;

    vec3 R = reflect(-V, N);
    vec3 prefiltered = textureLod(envMap, R, roughness * kMaxEnvLod).rgb;
    float NdotV = max(dot(N, V), 0.0);
    vec2 brdf = envBRDFApprox(NdotV, roughness);
    // envBrightnessCorrection stays scoped to specular only -- see
    // hemisphericAmbient's own comment for why the diffuse half no longer
    // needs it (it's live-evaluated every frame, never stale, unlike this
    // specular term which still reads the lazily-rebaked cubemap).
    vec3 specularIBL = prefiltered * (F0 * brdf.x + brdf.y) * ubo.envBrightnessCorrection;

    return diffuseIBL + specularIBL;
}

// Fraction of light reaching a fragment from the directional light, in
// [0,1] -- 1.0 fully lit, 0.0 fully shadowed. worldPos/normal are the
// fragment's own surface point and (geometric, not normal-mapped --
// see main()'s geometricN) normal; the light-space projection now happens
// right here, per fragment, rather than being precomputed per vertex and
// interpolated the way it used to be (see fragLightSpacePos's comment
// above) -- normal-offset bias needs to shift worldPos *before*
// projecting, and how far depends on gl_FrontFacing (double-sided
// backface flipping), which only exists at this stage.
//
// Normal-offset bias pushes the sampled point a few shadow-map texels'
// worth of world space along the surface normal before comparing it
// against the shadow map, instead of (or alongside) the fixed-function
// slope/constant depth bias already applied when the shadow map was
// rendered (see createShadowPipeline, VulkanPipeline.cpp). The two attack
// the same problem -- shadow acne from a surface's own depth being
// compared against itself at finite shadow-map resolution -- from
// different sides: depth bias pushes the *recorded* depth back along the
// slope, normal-offset instead moves *where* on the surface gets sampled.
// Depth bias alone tends to need a steep slope factor to fully suppress
// acne at grazing light angles (the exact symptom this was added for),
// which then risks peter-panning (shadows detaching from their casters);
// normal-offset handles the grazing-angle case more gracefully since the
// offset is along the surface itself, not along the light's view axis.
// Both are exposed as LightingUI sliders (see VulkanApp.h/LightingUI.cpp)
// so they can be balanced against each other live instead of guessed at.
//
// Fragments beyond the shadow frustum's far plane (or outside its side
// planes) are treated as fully lit rather than clamped/wrapped into a
// wrong answer -- content outside the light's fitted frustum has no shadow
// data either way, and "unshadowed" is the safer default than "unshadowed
// vs. randomly shadowed depending on clamp behavior".
// Jimenez 2014's interleaved gradient noise -- a cheap, no-texture-lookup
// per-pixel pseudo-random value in [0,1) used below to rotate the PCF tap
// pattern differently at every screen pixel. Without this, a *fixed* tap
// pattern (same 4 offsets at every pixel) aliases into a coherent, clearly
// visible diagonal stripe pattern across flat surfaces at grazing light
// angles -- exactly the kind of banding a low sun angle exposes -- instead
// of the soft penumbra it's supposed to approximate. Rotating per-pixel
// turns that coherent stripe into imperceptible per-pixel noise instead.
float interleavedGradientNoise(vec2 screenPos) {
    return fract(52.9829189 * fract(dot(screenPos, vec2(0.06711056, 0.00583715))));
}

// Camera-relative depth (positive, increasing with distance) -- what
// selectCascade() below compares against ubo.cascadeSplitDepths to decide
// which cascade covers a fragment. View space in this project looks down
// -Z (standard glm::lookAt/perspective convention), hence the negation.
float viewSpaceDepth(vec3 worldPos) {
    return -(ubo.view * vec4(worldPos, 1.0)).z;
}

// Picks which of ubo.lightViewProj[]'s kNumShadowCascades (VulkanTypes.h)
// entries covers a given camera-relative depth: the first cascade whose
// far split (ubo.cascadeSplitDepths[i]) is beyond it, or the last cascade
// if the fragment is past every split (its own far split already covers
// out to the shadow-relevant view distance -- see updateUniformBuffer's
// cascade-split comment, VulkanRender.cpp).
int selectCascade(float viewDepth) {
    for (int i = 0; i < 3; ++i) {
        if (viewDepth < ubo.cascadeSplitDepths[i]) return i;
    }
    return 3;
}

// Uniform-density disk sample (Vogel/Fibonacci spiral), unlike kRotatedTaps
// below's fixed 8-entry array -- generates any tap count on the fly, which
// PCSS needs since both its blocker search and PCF loop tap counts are
// driven by the live "Quality" slider rather than a compile-time constant.
// phi is a per-pixel rotation (interleavedGradientNoise-derived, same
// dithering purpose kRotatedTaps' own per-pixel rotation serves below) so
// neighboring pixels' spirals don't align into visible banding.
vec2 vogelDiskSample(int i, int count, float phi) {
    const float kGoldenAngle = 2.39996323;
    float r = sqrt((float(i) + 0.5) / float(count));
    float theta = float(i) * kGoldenAngle + phi;
    return r * vec2(cos(theta), sin(theta));
}

// Static upper bounds for blockerSearch()/pcfShadow()'s PCSS loops below --
// same "static trip count, dynamic break" shape parallaxOcclusionOffset()
// above already uses for a quality-driven sample count.
const int kMaxPcssBlockerTaps = 16;
const int kMaxPcssPcfTaps = 32;

// PCSS blocker search: average depth (in the cascade's own [0,1] shadow-map
// depth space, where smaller = closer to the light -- see shadowSampler's
// VK_COMPARE_OP_LESS comment, VulkanResources.cpp) of every sampled texel
// within searchRadiusTexels of shadowUV that's closer to the light than
// compareDepth, i.e. would actually occlude this receiver. Returns
// (avgBlockerDepth, numBlockers) -- numBlockers == 0.0 means no occluder was
// found in the search radius, so pcfShadow() below has nothing to derive a
// penumbra from.
vec2 blockerSearch(vec2 shadowUV, float layer, float compareDepth, float searchRadiusTexels, int numTaps, float phi) {
    vec2 texelSize = 1.0 / vec2(kShadowMapSize);
    float blockerSum = 0.0;
    float blockerCount = 0.0;
    for (int i = 0; i < kMaxPcssBlockerTaps; ++i) {
        if (i >= numTaps) break;
        vec2 uv = shadowUV + vogelDiskSample(i, numTaps, phi) * searchRadiusTexels * texelSize;
        float depth = texture(shadowMapRaw, vec3(uv, layer)).r;
        if (depth < compareDepth) {
            blockerSum += depth;
            blockerCount += 1.0;
        }
    }
    return vec2(blockerCount > 0.0 ? blockerSum / blockerCount : 0.0, blockerCount);
}

// 8-tap rotated-grid PCF (two interleaved rings) against one cascade's
// array layer, instead of a 3x3 (9-tap) box: each tap already gets hardware
// bilinear filtering from the comparison sampler (see shadowMap's
// declaration above), and a rotated pattern spreads taps across a wider
// footprint than a tight grid would, getting close to a 9-tap box filter's
// softness for less than the texture reads. The per-pixel rotation angle
// (see interleavedGradientNoise above) is what actually keeps this from
// banding -- without it, "rotated" only means rotated once relative to a
// plain grid, still identical at every pixel. Bumped from 4 taps to 8 (a
// second ring at a different radius/rotation) specifically to smooth out
// visible banding at the resolutions a single non-cascaded map used to
// force everything into -- cascades already reduce that texel-scale
// banding on their own by shrinking near-camera texels, but a denser tap
// pattern helps the remaining farther-cascade coverage too.
//
// When ubo.pcssEnabled is set, this fixed kernel is skipped entirely in
// favor of a blocker search (above) followed by a variable-radius PCF using
// the same Vogel-disk pattern blockerSearch() uses -- a switch, not a
// blend, so PCSS off is byte-for-byte the original behavior.
float pcfShadow(vec2 shadowUV, float layer, float compareDepth) {
    vec2 texelSize = 1.0 / vec2(kShadowMapSize);
    float noiseAngle = interleavedGradientNoise(gl_FragCoord.xy) * 6.2831853;

    if (ubo.pcssEnabled == 0) {
        const vec2 kRotatedTaps[8] = vec2[](
            vec2(-1.5, 0.5), vec2(0.5, 1.5), vec2(1.5, -0.5), vec2(-0.5, -1.5),
            vec2(-2.5, -1.0), vec2(-1.0, 2.5), vec2(2.5, 1.0), vec2(1.0, -2.5)
        );
        float sinA = sin(noiseAngle);
        float cosA = cos(noiseAngle);
        mat2 tapRotation = mat2(cosA, sinA, -sinA, cosA);
        float shadow = 0.0;
        for (int i = 0; i < 8; ++i) {
            vec2 uv = shadowUV + (tapRotation * kRotatedTaps[i]) * texelSize;
            shadow += texture(shadowMap, vec4(uv, layer, compareDepth));
        }
        return shadow / 8.0;
    }

    // "Quality" (0-100) drives both search/PCF tap density -- more taps at
    // higher quality for a smoother penumbra, fewer at lower quality to stay
    // cheap. Blocker search radius is fixed (not quality-scaled): it only
    // has to be wide enough to *find* a nearby occluder, not to resolve the
    // penumbra itself -- that's what the PCF radius below is for.
    float q = clamp(ubo.pcssQuality, 0.0, 100.0) / 100.0;
    int blockerTaps = int(mix(6.0, float(kMaxPcssBlockerTaps), q));
    int pcfTaps = int(mix(14.0, float(kMaxPcssPcfTaps), q));
    const float kBlockerSearchRadiusTexels = 5.0;

    vec2 blockerResult = blockerSearch(shadowUV, layer, compareDepth, kBlockerSearchRadiusTexels, blockerTaps, noiseAngle);
    if (blockerResult.y < 1.0) {
        // No occluder within the search radius -- nothing casting a
        // penumbra here, same "unshadowed by default" convention
        // sampleCascade() uses for content outside a cascade's own frustum.
        return 1.0;
    }
    float avgBlockerDepth = blockerResult.x;

    // Similar-triangles penumbra estimate, adapted for a directional
    // (orthographic) light -- see pcssLightSize's own comment
    // (UniformBufferObject, VulkanTypes.h) for why there's no "/ blocker"
    // divide here the way a perspective-light PCSS formula would have.
    // kPenumbraScale converts the (very small, cascade-fit-dependent)
    // shadow-map depth-space difference into a texel count at a scale
    // pcssLightSize's slider range was tuned against -- empirically chosen,
    // not a physical constant. kMaxPenumbraTexels is deliberately modest
    // (not just "whatever looks softest"): a wide penumbra spread across
    // only pcfTaps' worth of samples reads as visible dot/grain noise
    // rather than a smooth blur (classic PCSS undersampling), so this caps
    // the radius low enough that even the default Quality's tap count
    // stays reasonably dense across it.
    const float kPenumbraScale = 50000.0;
    const float kMaxPenumbraTexels = 14.0;
    float penumbraTexels = clamp(
        ubo.pcssLightSize * (compareDepth - avgBlockerDepth) * kPenumbraScale,
        1.0, kMaxPenumbraTexels);

    float shadow = 0.0;
    for (int i = 0; i < kMaxPcssPcfTaps; ++i) {
        if (i >= pcfTaps) break;
        vec2 uv = shadowUV + vogelDiskSample(i, pcfTaps, noiseAngle) * penumbraTexels * texelSize;
        shadow += texture(shadowMap, vec4(uv, layer, compareDepth));
    }
    return shadow / float(pcfTaps);
}

// Projects worldPos (already normal-offset-biased for cascade `cascade`)
// through that cascade's own lightViewProj and samples its array layer --
// shared by sampleShadow()'s cascade blend below so both the selected and
// blended-neighbor cascade go through identical projection/sampling code.
// Returns 1.0 (fully lit) for anything outside that cascade's own fitted
// frustum, same reasoning as the single-cascade version this replaced:
// content outside the light's fitted frustum has no shadow data either
// way, and "unshadowed" is the safer default than a wrong answer from
// clamping.
float sampleCascade(int cascade, vec3 worldPos, vec3 normal, float grazingFactor) {
    vec3 offsetWorldPos = worldPos + normal * (ubo.shadowNormalOffsetWorldSize[cascade] * grazingFactor);
    vec4 lightClip = ubo.lightViewProj[cascade] * vec4(offsetWorldPos, 1.0);
    vec3 lightNDC = lightClip.xyz / lightClip.w;
    if (lightNDC.z < 0.0 || lightNDC.z > 1.0 ||
        lightNDC.x < -1.0 || lightNDC.x > 1.0 || lightNDC.y < -1.0 || lightNDC.y > 1.0) {
        return 1.0;
    }
    vec2 shadowUV = lightNDC.xy * 0.5 + 0.5;
    return pcfShadow(shadowUV, float(cascade), lightNDC.z);
}

// Fraction of light reaching a fragment from the directional light, in
// [0,1] -- selects a cascade by view-space depth (selectCascade above),
// then samples it (and, within a blend band near the split, the next
// cascade too, cross-fading between them) rather than switching cascades
// with a hard cutoff -- a hard seam is otherwise clearly visible as a
// resolution/bias discontinuity right where two cascades meet.
float sampleShadow(vec3 worldPos, vec3 normal) {
    // See sampleCascade's normal-offset comment (moved there since it's now
    // per-cascade) for why this scales the base offset by (1 - N.L).
    vec3 L = normalize(-ubo.lightDir);
    float grazingFactor = 1.0 - clamp(dot(normal, L), 0.0, 1.0);

    float viewDepth = viewSpaceDepth(worldPos);
    int cascade = selectCascade(viewDepth);
    float shadow = sampleCascade(cascade, worldPos, normal, grazingFactor);

    if (cascade < 3) {
        // Blend band: the last 30% of this cascade's own span (previous
        // split to this one), derived purely from cascadeSplitDepths (no
        // extra CPU-side data needed) -- prevSplit is 0 for cascade 0's
        // sake, which is fine since kCameraNearPlane (the real lower bound)
        // is close enough to 0 for the blend band's width not to matter.
        // Wider than a first cut at this (10%) specifically because the
        // *shadow value* isn't the only thing that changes at a cascade
        // boundary -- each cascade's own texel size (so its PCF blur
        // radius) differs too, and blending only the former still leaves a
        // visible "sharpness pop" right at the seam if the band is too
        // narrow to make the difference gradual. Widening the band spreads
        // that sharpness change over more world distance instead of making
        // it read as instant.
        float prevSplit = cascade == 0 ? 0.0 : ubo.cascadeSplitDepths[cascade - 1];
        float split = ubo.cascadeSplitDepths[cascade];
        float blendBand = (split - prevSplit) * 0.3;
        float blendStart = split - blendBand;
        if (viewDepth > blendStart) {
            float nextShadow = sampleCascade(cascade + 1, worldPos, normal, grazingFactor);
            float t = clamp((viewDepth - blendStart) / max(blendBand, 1e-4), 0.0, 1.0);
            // smoothstep's ease-in/ease-out instead of a raw linear ramp --
            // a linear blend still has a visible slope discontinuity at
            // both ends of the band (where it snaps from "not blending" to
            // "blending"); smoothstep's derivative is zero at both ends, so
            // the transition itself has no perceptible start/end edge.
            t = t * t * (3.0 - 2.0 * t);
            shadow = mix(shadow, nextShadow, t);
        }
    }
    return shadow;
}

// LightingUI's "Debug: Visualize Cascades" checkbox: tints a fragment by
// which cascade covers it instead of hiding that information behind a
// resolution/banding difference that's otherwise hard to eyeball directly.
// Blended at partial strength onto the real shaded+shadowed color (not a
// flat replacement) so the actual shadow result stays visible underneath
// while checking split placement.
vec3 cascadeDebugColor(int cascade) {
    if (cascade == 0) return vec3(1.0, 0.3, 0.3);
    if (cascade == 1) return vec3(0.3, 1.0, 0.3);
    if (cascade == 2) return vec3(0.3, 0.4, 1.0);
    return vec3(1.0, 1.0, 0.3);
}

vec3 applyCascadeDebugTint(vec3 color, vec3 worldPos) {
    if (ubo.shadowDebugVisualizeCascades == 0) {
        return color;
    }
    int cascade = selectCascade(viewSpaceDepth(worldPos));
    return mix(color, cascadeDebugColor(cascade), 0.35);
}

// Fallback shading for a primitive with no glTF material at all
// (fragMaterialIndex < 0), so it doesn't index materialBuffer out of range.
// This used to just be flat normal-as-color debug output regardless of any
// other data the primitive carried -- but plenty of real, legitimately
// materialless primitives (notably meshes converted from DAE/Collada by
// exporters that bake color into the per-vertex COLOR_0 attribute instead
// of authoring a material+texture) DO carry real surface color via
// fragColor. Using that as a lit albedo instead of discarding it in favor
// of a solid debug tint is what actually renders those meshes' real colors
// rather than flat red/green blobs. A basic Lambertian diffuse + the same
// hemisphere ambient the main path uses is enough here -- full PBR
// (metallic/roughness/specular) has no material data to draw on for a
// primitive with no material at all.
vec3 unlitMaterialFallback() {
    vec3 N = normalize(fragNormal) * frontFacingSign();
    vec3 L = normalize(-ubo.lightDir);
    float NdotL = max(dot(N, L), 0.0);

    // Diffuse-only ambient (no specular term -- this path has no
    // roughness/metallic/F0 data to build one from) -- see
    // hemisphericAmbient()'s own comment above for why this real,
    // live-evaluated sky/ground blend replaced the old flat cubemap-mip
    // sample, and why it needs no envBrightnessCorrection (only the
    // still-cubemap-sampled specular term in sampleEnvironment() does).
    vec3 ambientTint = ubo.ambientColorIntensity.rgb * ubo.ambientColorIntensity.a;
    vec3 ambientLight = indirectSkyRadiance(N) * ambientTint;

    vec3 albedo = fragColor.rgb;
    float shadowFactor = sampleShadow(fragWorldPos, N);

    // Point lights, Lambertian-only (no specular/F0/metallic data exists for
    // a materialless primitive to build one from) -- same windowed
    // inverse-square falloff as pointLightsContribution()'s full PBR path
    // below, just without the specular term. Only this fragment's own
    // cluster's assigned lights (clusterLightGrid), not every light in the
    // scene -- see clusterIndexForFragment()'s own comment above.
    vec3 pointLit = vec3(0.0);
    {
        uint clusterIdx = clusterIndexForFragment(gl_FragCoord.xy, viewSpaceDepth(fragWorldPos));
        ClusterLightGridEntry grid = clusterLightGrid[clusterIdx];
        for (uint gi = 0u; gi < grid.count; ++gi) {
            uint i = clusterLightIndices[grid.offset + gi];
            vec3 toLight = lights[i].posRange.xyz - fragWorldPos;
            float dist = length(toLight);
            vec3 pl = toLight / max(dist, 1e-4);
            float pNdotL = max(dot(N, pl), 0.0);
            if (pNdotL <= 0.0) continue;
            float coneFactor = 1.0;
            if (lights[i].coneDir.w > 0.5) {
                float cosAngle = dot(lights[i].coneDir.xyz, -pl);
                coneFactor = smoothstep(lights[i].coneAngles.y, lights[i].coneAngles.x, cosAngle);
                if (coneFactor <= 0.0) continue;
            }
            float range = max(lights[i].posRange.w, 0.01);
            float distFactor = 1.0 / max(dist * dist, 0.01);
            float rangeWindow = clamp(1.0 - pow(dist / range, 4.0), 0.0, 1.0);
            distFactor *= rangeWindow * rangeWindow * coneFactor;
            vec3 lightColor = lights[i].colorIntensity.rgb * lights[i].colorIntensity.a;
            pointLit += albedo * lightColor * pNdotL * distFactor;
        }
    }

    // Stays linear -- see main()'s comment on the identical point for why
    // tonemapping moved out of every per-material shader and into a single
    // final pass (tonemap.frag) that runs once the whole HDR scene,
    // opaque and translucent alike, is fully composited.
    vec3 litColor = albedo * ambientLight + albedo * ubo.lightColor * NdotL * shadowFactor + pointLit;
    // Tunable floor under the final result -- see main()'s identical use for
    // the full reasoning (material-independent, applied post-combination).
    litColor = max(litColor, vec3(ubo.minAmbientFloor));
    return applyCascadeDebugTint(litColor, fragWorldPos);
}

// Cook-Torrance microfacet BRDF (distributionGGX/geometrySchlickGGX/
// geometrySmith/fresnelSchlick/evaluateDirectLight) is defined earlier in
// this file, right after kPi.

// Geometric specular AA (Toksvig-style normal-derivative variance -- the
// same technique published as Filament's normalFiltering(), itself a
// production-proven descendant of Tokuyoshi/Kaplanyan's "Practical Analytic
// Filtering" and the original LEAN/Toksvig mapping papers). Fixes specular
// fireflies -- fine metallic geometry (gold embroidery, chains, foliage-edge
// normal maps) whose shading normal changes faster than one pixel can
// resolve produces a per-pixel specular highlight that pops on/off between
// frames as the camera moves, reading as a twinkling/crawling
// sparkle that bloom's threshold then amplifies. Screen-space derivatives of
// the *final* shading normal (dFdx/dFdy, taken on N after normal mapping --
// this needs to see normal-map high-frequency detail too, not just geometric
// curvature, since embroidery/chain detail is often normal-mapped rather
// than modeled) measure exactly that per-pixel rate of change; converting it
// into extra roughness widens the highlight just enough to stay stable
// under one pixel's worth of normal variation, while a flat surface (normal
// derivative ~0) passes through unaffected -- see this function's own
// variance term for the clamp that guarantees that.
//
// perceptualRoughness here is glTF's roughnessFactor convention (this
// codebase's `roughness` throughout -- distributionGGX squares it to get
// alpha itself), matching Filament's own naming exactly.
float normalFiltering(float perceptualRoughness, vec3 N) {
    vec3 du = dFdx(N);
    vec3 dv = dFdy(N);
    // 0.15 (variance scale) / 0.20 (kernel clamp) are Filament's published
    // defaults -- chosen there to noticeably calm high-frequency normals
    // without visibly softening genuinely smooth surfaces, and not exposed
    // as their own sliders here since GraphicsUI's on/off toggle plus the
    // roughness floor below are the two knobs actually asked for.
    const float kSpecularAAVariance = 0.15;
    const float kSpecularAAThreshold = 0.20;
    float variance = kSpecularAAVariance * (dot(du, du) + dot(dv, dv));

    float alpha = perceptualRoughness * perceptualRoughness;
    // Clamped so a rapidly-changing normal can only push roughness up to a
    // bounded amount per pixel, not runaway to fully rough -- this is what
    // keeps the effect proportional to actual normal variation instead of a
    // flat blur.
    float kernelAlpha = min(2.0 * variance, kSpecularAAThreshold);
    float filteredAlphaSquared = clamp(alpha * alpha + kernelAlpha, 0.0, 1.0);
    // sqrt(sqrt(x)): filteredAlphaSquared is alpha^2 with the kernel term
    // added in, so one sqrt recovers the new alpha, a second converts that
    // back to perceptualRoughness (alpha = perceptualRoughness^2) --
    // identical two-step round-trip Filament's own implementation uses.
    return sqrt(sqrt(filteredAlphaSquared));
}

// Point lights (editor toolbar's "Spawn Point Light") -- omnidirectional by
// default, or an optional soft-edged cone (PropertiesUI's "Cone (Spot
// Light)" checkbox) -- windowed-inverse-square falloff (same shape this
// project's old flashlight punctual light used), no shadow of any kind
// (deliberately out of scope, see ubo.lightCount's own comment,
// VulkanTypes.h). Same Cook-Torrance terms as the sun's own direct
// contribution below, just accumulated once per light this fragment's own
// cluster was assigned (clusterLightGrid/clusterLightIndices, built each
// frame by cluster_aabb_build.comp + light_cull.comp, VulkanRender.cpp) --
// NOT every light in the scene, which is the entire point of clustering:
// cost now scales with how many lights are actually near a given fragment,
// not with total scene light count.
vec3 pointLightsContribution(vec3 worldPos, vec3 N, vec3 V, vec3 albedo, vec3 F0, float roughness, float metallic) {
    vec3 result = vec3(0.0);
    float NdotV = max(dot(N, V), 0.0);

    uint clusterIdx = clusterIndexForFragment(gl_FragCoord.xy, viewSpaceDepth(worldPos));
    ClusterLightGridEntry grid = clusterLightGrid[clusterIdx];
    for (uint gi = 0u; gi < grid.count; ++gi) {
        uint i = clusterLightIndices[grid.offset + gi];
        vec3 toLight = lights[i].posRange.xyz - worldPos;
        float dist = length(toLight);
        vec3 L = toLight / max(dist, 1e-4);
        float NdotL = max(dot(N, L), 0.0);
        if (NdotL <= 0.0) continue;

        // Cone falloff, only when this light is in spot mode (w == 1) --
        // same angle-between-forward-and-light-to-fragment/smoothstep shape
        // the old flashlight used. Skipped entirely (coneFactor left at 1.0)
        // for a plain omnidirectional light -- coneDir defaults to an
        // all-zero vector when disabled, which would otherwise read as a
        // degenerate (zero-length) direction if this weren't gated.
        float coneFactor = 1.0;
        if (lights[i].coneDir.w > 0.5) {
            float cosAngle = dot(lights[i].coneDir.xyz, -L);
            coneFactor = smoothstep(lights[i].coneAngles.y, lights[i].coneAngles.x, cosAngle);
            if (coneFactor <= 0.0) continue;
        }

        // Inverse-square falloff with a soft windowed cutoff at range --
        // same "windowed inverse-square" punctual-light falloff as the sun's
        // old flashlight counterpart, see its own comment (removed) for why:
        // reads as a natural hot spot near the light with no hard pop to
        // zero right at the range boundary.
        float range = max(lights[i].posRange.w, 0.01);
        float distFactor = 1.0 / max(dist * dist, 0.01);
        float rangeWindow = clamp(1.0 - pow(dist / range, 4.0), 0.0, 1.0);
        distFactor *= rangeWindow * rangeWindow * coneFactor;
        if (distFactor <= 0.0) continue;

        vec3 H = normalize(V + L);
        float NDF = distributionGGX(N, H, roughness);
        float G = geometrySmith(NdotV, NdotL, roughness);
        vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);
        vec3 specular = (NDF * G * F) / max(4.0 * NdotV * NdotL, 1e-4);
        vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);

        vec3 lightColor = lights[i].colorIntensity.rgb * lights[i].colorIntensity.a;
        result += (kD * albedo / kPi + specular) * lightColor * NdotL * distFactor;
    }
    return result;
}

// Steep parallax mapping with an occlusion-mapping refinement step (Brawley
// & Tatarchuk's original POM formulation) -- ray-marches the heightmap in
// tangent space to find where the view ray actually enters the displaced
// surface, and returns the resulting tangent-space UV offset. This is the
// fine, per-pixel half of the "tessellated displacement + POM" combo --
// pom_displace.tese displaces the actual triangle vertices for a correct
// coarse silhouette (real geometry, so it deforms the mesh's outline); this
// function adds per-pixel relief and self-occlusion *within* one tessellated
// micro-triangle, at a resolution finer than tessellation alone could afford
// to subdivide to. Height convention matches pom_displace.tese exactly:
// texture value 1.0 = fully raised (sits at the tessellated surface, zero
// additional offset), 0.0 = fully recessed (mat.heightScale below it) -- see
// that shader's own comment for why both stages have to agree on this.
vec2 parallaxOcclusionOffset(vec3 viewDirTangent, int heightTex, float heightScale) {
    const int kMinSamples = 8;
    const int kMaxSamples = 32;
    // More ray-march steps at grazing angles (viewDirTangent.z near 0),
    // where a single UV step covers far more of the heightmap's depth range
    // -- fewer, cheaper steps suffice when looking straight at the surface.
    int numSamples = int(mix(float(kMaxSamples), float(kMinSamples), abs(viewDirTangent.z)));
    float layerDepth = 1.0 / float(numSamples);
    float currentLayerDepth = 0.0;
    vec2 deltaUV = (viewDirTangent.xy / max(abs(viewDirTangent.z), 1e-3)) * heightScale / float(numSamples);

    vec2 currentUV = vec2(0.0);
    float currentHeight = texture(bindlessTextures[nonuniformEXT(heightTex)], fragUV).r;

    // Bounded by kMaxSamples (not a data-dependent while loop) -- numSamples
    // is itself already <= kMaxSamples, this just gives the compiler a
    // static trip count to work with.
    for (int i = 0; i < kMaxSamples; ++i) {
        if (i >= numSamples || currentLayerDepth >= currentHeight) break;
        currentUV -= deltaUV;
        currentHeight = texture(bindlessTextures[nonuniformEXT(heightTex)], fragUV + currentUV).r;
        currentLayerDepth += layerDepth;
    }

    // Occlusion-mapping refinement: linearly interpolate between the last
    // step before the ray crossed the surface and the step that crossed it,
    // instead of accepting the coarse step's UV outright -- removes the
    // layered/banded look plain steep parallax mapping has at low sample
    // counts, for the cost of one extra texture sample.
    vec2 prevUV = currentUV + deltaUV;
    float afterDepth = currentHeight - currentLayerDepth;
    float beforeHeight = texture(bindlessTextures[nonuniformEXT(heightTex)], fragUV + prevUV).r;
    float beforeDepth = beforeHeight - (currentLayerDepth - layerDepth);
    float weight = afterDepth / max(afterDepth - beforeDepth, 1e-4);
    return mix(currentUV, prevUV, weight);
}

void main() {
    if (fragMaterialIndex < 0) {
        outColor = vec4(unlitMaterialFallback(), fragColor.a);
        return;
    }

    Material mat = materialBuffer.materials[fragMaterialIndex];

    // Geometric normal/tangent basis and view vector, computed up front
    // (rather than where they used to sit, right before normal-map sampling
    // further down) because the parallax offset below has to be resolved
    // *before* baseColorTexture is sampled -- every texCoordFor() call from
    // here on (baseColor, metallic-roughness, normal, occlusion, emissive)
    // picks up parallaxOffset automatically. faceSign/geometricN/V are only
    // computed once now; the code further down that used to (re)compute them
    // just reuses these.
    float faceSign = frontFacingSign();
    vec3 geometricN = normalize(fragNormal) * faceSign;
    vec3 V = normalize(ubo.camPos - fragWorldPos);

    if (mat.heightTexture >= 0 && dot(fragTangent.xyz, fragTangent.xyz) > 1e-8) {
        vec3 T = normalize(fragTangent.xyz - geometricN * dot(fragTangent.xyz, geometricN));
        vec3 B = cross(geometricN, T) * (fragTangent.w * faceSign);
        mat3 TBN = mat3(T, B, geometricN);
        // transpose(TBN), not inverse(TBN): T/B/N are orthonormal, so the
        // transpose *is* the inverse -- world-to-tangent instead of TBN's
        // own tangent-to-world direction, at no extra cost.
        vec3 viewDirTangent = normalize(transpose(TBN) * V);
        parallaxOffset = parallaxOcclusionOffset(viewDirTangent, mat.heightTexture, mat.heightScale);
    }

    // glTF spec: COLOR_0 multiplies into baseColor alongside baseColorFactor
    // and the base color texture, regardless of which of those are present.
    vec4 baseColor = mat.baseColorFactor * fragColor;
    if (mat.baseColorTexture >= 0) {
        baseColor *= texture(bindlessTextures[nonuniformEXT(mat.baseColorTexture)], texCoordFor(mat.texCoordSets, 1));
    }

    // Fragments with essentially zero alpha are dropped regardless of
    // alpha_mode -- there's nothing meaningful to shade or blend there
    // either way, and this keeps fully-transparent cutout regions (e.g.
    // outside a leaf sprite's silhouette) from ever reaching the BRDF below.
    if (baseColor.a < kZeroAlphaEpsilon) {
        discard;
    }

    // Alpha handling per glTF alpha_mode: OPAQUE ignores the texture's
    // alpha channel entirely -- many "opaque"-tagged materials carry
    // incidental non-255 alpha that has nothing to do with masking, and
    // testing it there was exactly the "takes away too much" bug this
    // material system replaces. MASK alpha-tests: a hard discard below the
    // material's own cutoff, nothing fancier -- this pipeline still writes
    // depth and participates in shadows, which is what makes it the right
    // choice for foliage/fences/hair over real blending or WBOIT. BLEND
    // passes the real alpha through to the WBOIT accumulation shader
    // (shader_oit.frag) instead of this pipeline.
    float outAlpha = 1.0;
    if (mat.alphaMode == 1) { // MASK
        if (baseColor.a < mat.alphaCutoff) {
            discard;
        }
    } else if (mat.alphaMode == 2) { // BLEND
        if (ubo.forceMaskForBlend != 0) {
            // Treated as MASK instead: recordCommandBuffer (VulkanRender.cpp)
            // already drew this in pass 1 with real depth writes and no
            // sort, so shading has to match -- alpha-test using the
            // material's own cutoff (or a sane default if the content never
            // specified one, since MASK-authored assets have alphaCutoff set
            // but BLEND-authored ones may leave it at 0).
            float cutoff = mat.alphaCutoff > 0.0 ? mat.alphaCutoff : 0.5;
            if (baseColor.a < cutoff) {
                discard;
            }
            // outAlpha stays 1.0 -- same as MASK, texture alpha was only
            // ever meant to cut a silhouette, not modulate translucency.
        } else {
            outAlpha = baseColor.a;
        }
    }
    // alphaMode == 0 (OPAQUE): outAlpha stays 1.0, texture alpha ignored.

    float metallic = mat.metallicFactor;
    // ubo.roughnessFloor replaces what used to be a hardcoded 0.04 literal
    // here -- see GraphicsUI's "Specular AA" section / roughnessFloor()'s
    // comment (VulkanApp.h). Applied to the sampled/computed roughness
    // before anything downstream (direct sun specular, IBL specular) ever
    // reads it, so both stay consistent.
    float roughness = clamp(mat.roughnessFactor, ubo.roughnessFloor, 1.0);
    if (mat.metallicRoughnessTexture >= 0) {
        // glTF packs this as (unused, roughness, metallic) in the G/B
        // channels -- a linear (non-sRGB) texture, see TextureData::isSRGB.
        vec3 mr = texture(bindlessTextures[nonuniformEXT(mat.metallicRoughnessTexture)], texCoordFor(mat.texCoordSets, 2)).rgb;
        roughness = clamp(mr.g * mat.roughnessFactor, ubo.roughnessFloor, 1.0);
        metallic = mr.b * mat.metallicFactor;
    }

    // faceSign/geometricN already computed above (needed there for the
    // parallax offset, before baseColor was sampled) -- N starts as a copy
    // of that same geometric normal and normal mapping below may overwrite
    // it; sampleShadow() further down still uses geometricN (not N) for its
    // normal-offset bias, same reasoning as before this refactor: offsetting
    // the shadow-sampled point by high-frequency normal-map detail would
    // just trade shadow acne for shadow noise at the same frequency as the
    // normal map's texture.
    vec3 N = geometricN;
    if (mat.normalTexture >= 0 && dot(fragTangent.xyz, fragTangent.xyz) > 1e-8) {
        vec3 T = normalize(fragTangent.xyz - N * dot(fragTangent.xyz, N)); // re-orthogonalize post-interpolation
        // The tangent's handedness needs the same flip as N -- it decides
        // which way the bitangent points relative to T and N, and that
        // relationship inverts on a mirrored/back-facing triangle the same
        // way the normal does.
        vec3 B = cross(N, T) * (fragTangent.w * faceSign);
        mat3 TBN = mat3(T, B, N);
        vec3 sampledN = texture(bindlessTextures[nonuniformEXT(mat.normalTexture)], texCoordFor(mat.texCoordSets, 4)).rgb * 2.0 - 1.0;
        sampledN.xy *= mat.normalScale;
        N = normalize(TBN * normalize(sampledN));
    }

    // Geometric specular AA -- must run after N is fully resolved (post
    // normal-map) so dFdx/dFdy inside normalFiltering() see the same
    // high-frequency detail the BRDF below actually shades with, not just
    // the coarser geometric normal. Re-floors afterward: normalFiltering()
    // can only ever increase roughness (the kernel term is non-negative and
    // sqrt(sqrt(x)) is monotonic), so this is a defensive re-clamp rather
    // than something expected to actually trigger.
    if (ubo.geometricSpecularAAEnabled != 0) {
        roughness = normalFiltering(roughness, N);
        roughness = clamp(roughness, ubo.roughnessFloor, 1.0);
    }

    float occlusion = 1.0;
    if (mat.occlusionTexture >= 0) {
        float ao = texture(bindlessTextures[nonuniformEXT(mat.occlusionTexture)], texCoordFor(mat.texCoordSets, 8)).r;
        occlusion = mix(1.0, ao, mat.occlusionStrength);
    }

    vec3 emissive = mat.emissiveFactor.rgb;
    if (mat.emissiveTexture >= 0) {
        emissive *= texture(bindlessTextures[nonuniformEXT(mat.emissiveTexture)], texCoordFor(mat.texCoordSets, 16)).rgb;
    }

    // V already computed above (needed there for the parallax offset).
    vec3 L = normalize(-ubo.lightDir);
    vec3 H = normalize(V + L);

    vec3 albedo = baseColor.rgb;
    // Dielectrics get a flat ~4% reflectance at normal incidence; metals
    // reflect their own albedo color instead -- the standard
    // metallic-workflow F0 split.
    vec3 F0 = mix(vec3(0.04), albedo, metallic);

    float NdotL = max(dot(N, L), 0.0);
    float NdotV = max(dot(N, V), 0.0);
    // Shadow only attenuates the direct term -- ambient/emissive below are
    // unaffected, same as real sun+sky lighting (a shadowed patch of ground
    // still gets sky light and any emissive surfaces nearby still glow).
    // Hoisted out of the NdotL branch below since the foliage translucency
    // term also needs it (a backlit leaf still needs the sun to actually
    // reach it, unoccluded, to glow).
    float shadowFactor = sampleShadow(fragWorldPos, geometricN);

    vec3 lighting = vec3(0.0);
    if (NdotL > 0.0) {
        float NDF = distributionGGX(N, H, roughness);
        float G = geometrySmith(NdotV, NdotL, roughness);
        vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);

        vec3 specular = (NDF * G * F) / max(4.0 * NdotV * NdotL, 1e-4);

        // Energy conservation: light that goes into specular reflection
        // (F) doesn't also go into diffuse, and metals have no diffuse
        // term at all.
        vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);
        lighting = (kD * albedo / kPi + specular) * ubo.lightColor * NdotL * shadowFactor;
    }

    lighting += pointLightsContribution(fragWorldPos, N, V, albedo, F0, roughness, metallic);

    // Cheap backlit-foliage transmission -- lets sunlight glow through thin
    // double-sided geometry (leaf cards, grass) instead of the shadowed side
    // reading flat black under the NdotL gate above. Standard "wrap
    // lighting" approximation (Barre-Brisebois & Bouchard, GDC 2011) -- no
    // thickness map, distortion/power/scale are fixed starting constants.
    // doubleSided is used as the "this is foliage/thin geometry" signal
    // since GltfLoader already gets that for free from glTF authoring and
    // nothing else in Material distinguishes thin surfaces. See
    // shader_oit.frag's copy for the OIT/BLEND path.
    if (mat.doubleSided != 0 && ubo.foliageTranslucencyStrength > 0.0) {
        const float kTranslucencyDistortion = 0.5;
        const float kTranslucencyPower = 4.0;
        const float kTranslucencyScale = 2.0;
        vec3 transmissionDir = L + N * kTranslucencyDistortion;
        float transmissionDot = pow(clamp(dot(V, -transmissionDir), 0.0, 1.0), kTranslucencyPower);
        lighting += albedo * ubo.lightColor * transmissionDot * kTranslucencyScale
            * shadowFactor * ubo.foliageTranslucencyStrength;
    }

    // Real (if cheap) image-based lighting: sampleEnvironment() combines a
    // live hemisphericAmbient() diffuse term (real sky/ground directional
    // shading, driven by the same atmosphere model the sky itself uses) with
    // a prefiltered-specular sample from the baked sky cubemap -- see its
    // comment above. ambientTint (LightingUI's Ambient Light section --
    // enabled checkbox folded into intensity=0, color-wheel picker, see
    // updateUniformBuffer in VulkanRender.cpp) still works as a single
    // artistic multiplier over the whole indirect contribution, same role
    // it played over the old flat hemisphere term.
    vec3 ambientTint = ubo.ambientColorIntensity.rgb * ubo.ambientColorIntensity.a;
    // Screen-space AO (recordCommandBuffer's "SSAO pass") multiplies in here
    // too, alongside the glTF occlusion map -- both are ambient-occlusion
    // sources and combine the same way. gl_FragCoord.xy/textureSize() gives
    // this fragment's screen-space UV directly, no separate varying needed.
    // Skipped (1.0, no occlusion) when the feature's off rather than trusting
    // ssaoTexture's possibly-stale contents -- see ssaoEnabled's comment,
    // VulkanTypes.h. RGB=view-space geometric normal, A=AO -- see ssao.frag's
    // outColor packing comment. The RGB channel used to also carry GTAO's
    // occluder-leaning "bent" normal, blended into the ambient/IBL sample
    // direction below at 25% strength; now that GTAO is gone this texture's
    // RGB is always just the plain (temporally-accumulated) G-buffer normal,
    // which is the *same* normal N already is (modulo normal-map detail and
    // this texture's own blur/temporal smoothing) -- blending toward it no
    // longer has a real "lean away from occluders" effect to justify the
    // extra ALU/NaN-guard complexity that blend used to need, so it's been
    // removed; the ambient/IBL sample direction is just N directly now.
    vec2 screenUV = gl_FragCoord.xy / vec2(textureSize(ssaoTexture, 0));
    vec4 ssaoSample = texture(ssaoTexture, screenUV);
    float ssaoFactor = ubo.ssaoEnabled != 0 ? ssaoSample.a : 1.0;
    vec3 ambient = sampleEnvironment(N, V, albedo, F0, roughness, metallic, true) * ambientTint * occlusion * ssaoFactor;

    // glTF spec (occlusionTexture): AO attenuates indirect light only --
    // ambient above, not the direct light term. Direct light comes from a
    // specific, known direction the AO bake knows nothing about (it's
    // typically baked from an omnidirectional/hemisphere sample), so
    // applying it here as well double-darkens anything both shadowed *and*
    // occluded, and incorrectly darkens direct-lit surfaces that just
    // happen to sit in a crevice an AO bake flagged as occluded from *other*
    // directions.
    // Deliberately left in linear HDR, no tonemap here anymore: this
    // pipeline now renders into an R16G16B16A16_SFLOAT offscreen target
    // (VulkanPipeline.cpp's createColorResources/createOitResources), and
    // the WBOIT composite blends translucent content onto it in that same
    // linear space -- tonemapping *before* that composite (the old
    // per-shader Reinhard) would have compressed the opaque and
    // translucent contributions on two different curves before they ever
    // got added together, which isn't how light actually mixes. A single
    // final pass (tonemap.frag) now tonemaps the fully-composited HDR
    // result once, with exposure control, after everything -- opaque and
    // translucent alike -- has already been combined.
    vec3 color = ambient + lighting;
    // Tunable floor under the combined direct+ambient result (GraphicsUI's
    // "Ambient" section, minAmbientFloor) -- guarantees unlit-and-not-
    // flashlit areas stay barely navigable instead of true black, without
    // darkening anything already brighter than the floor (max() never
    // reduces). Deliberately NOT albedo-modulated (see
    // UniformBufferObject::minAmbientFloor's comment, VulkanTypes.h) and
    // applied *before* emissive is added back in -- emissive is a "glows on
    // its own" term, not something a visibility floor is about.
    color = max(color, vec3(ubo.minAmbientFloor));
    color += emissive;

    outColor = vec4(applyCascadeDebugTint(color, fragWorldPos), outAlpha);
}
