// ============================================================================
// sharc_sample.hlsl -- Phase 4: SHaRC sample/query pass.
//
// Full-resolution (unlike sharc_update.hlsl's downscaled grid): for every
// pixel, reconstructs world position + normal from the depth/normal
// G-buffer (same math as the update pass) and queries the resolved cache,
// writing the result into sharcGiImage -- shader.frag's RT_SUPPORTED build
// then just samples that as an ordinary sampler2D (PHASE3_NOTES.md: "avoids
// porting SHaRC's hash lookup to GLSL").
// ============================================================================

#define SHARC_ENABLE_64_BIT_ATOMICS 1
#define SHARC_UPDATE 0
#define SHARC_QUERY 1

#include "SharcCommon.h"

[[vk::binding(0, 0)]] RWStructuredBuffer<uint64_t> u_HashEntriesBuffer : register(u0, space0);
[[vk::binding(1, 0)]] RWStructuredBuffer<SharcPackedData> u_ResolvedBuffer : register(u1, space0);
[[vk::binding(2, 0)]] [[vk::combinedImageSampler]] Texture2D<float> depthBuffer : register(t2, space0);
[[vk::binding(2, 0)]] [[vk::combinedImageSampler]] SamplerState depthSampler : register(s2, space0);
[[vk::binding(3, 0)]] [[vk::combinedImageSampler]] Texture2D<float4> normalBuffer : register(t3, space0);
[[vk::binding(3, 0)]] [[vk::combinedImageSampler]] SamplerState normalSampler : register(s3, space0);
[[vk::binding(4, 0)]] RWTexture2D<float4> giOutput : register(u3, space0);

struct SharcFrameParamsCB {
    column_major float4x4 invView;
    column_major float4x4 invProj;
    float4 camPos;
    float4 camPosPrev;
    float4 sunDir;
    float4 sunColor;
    float4 gridParams;   // x=sceneScale, y=radianceScale
    uint4  intParams;    // x=frameIndex, y=accumulationFrameNum, z=staleFrameNumMax, w=capacity
    int4   screenParams; // x=update grid width, y=update grid height, z=full width, w=full height
};
[[vk::binding(5, 0)]] ConstantBuffer<SharcFrameParamsCB> pc : register(b0, space0);

[numthreads(8, 8, 1)]
void main(uint3 dtid : SV_DispatchThreadID)
{
    int fullWidth = pc.screenParams.z;
    int fullHeight = pc.screenParams.w;
    if ((int)dtid.x >= fullWidth || (int)dtid.y >= fullHeight)
        return;

    float2 uv = (float2(dtid.xy) + 0.5) / float2(fullWidth, fullHeight);
    float depth = depthBuffer.SampleLevel(depthSampler, uv, 0);
    if (depth >= 1.0) {
        giOutput[dtid.xy] = float4(0, 0, 0, 0);
        return;
    }

    float4 normalSample = normalBuffer.SampleLevel(normalSampler, uv, 0);
    float3 viewNormal = normalize(normalSample.xyz);
    float3 worldNormal = normalize(mul(viewNormal, (float3x3)pc.invView));

    float4 ndc = float4(uv * 2.0 - 1.0, depth, 1.0);
    float4 viewPosH = mul(pc.invProj, ndc);
    float3 viewPos = viewPosH.xyz / viewPosH.w;
    float4 worldPosH = mul(pc.invView, float4(viewPos, 1.0));
    float3 worldPos = worldPosH.xyz;

    SharcParameters sharcParameters;
    sharcParameters.gridParameters.cameraPosition = pc.camPos.xyz;
    sharcParameters.gridParameters.logarithmBase = SHARC_GRID_LOGARITHM_BASE;
    sharcParameters.gridParameters.sceneScale = pc.gridParams.x;
    sharcParameters.gridParameters.levelBias = SHARC_GRID_LEVEL_BIAS;
    sharcParameters.hashMapData.capacity = pc.intParams.w;
    sharcParameters.hashMapData.hashEntriesBuffer = u_HashEntriesBuffer;
    sharcParameters.resolvedBuffer = u_ResolvedBuffer;
    sharcParameters.radianceScale = pc.gridParams.y;
    sharcParameters.enableAntiFireflyFilter = true;

    SharcHitData sharcHitData;
    sharcHitData.positionWorld = worldPos;
    sharcHitData.normalWorld = worldNormal;

    float3 radiance;
    bool found = SharcGetCachedRadiance(sharcParameters, sharcHitData, radiance, false);
    giOutput[dtid.xy] = found ? float4(radiance, 1.0) : float4(0, 0, 0, 0);
}
