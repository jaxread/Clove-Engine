#version 460

// Phase 3 of the clustered-deferred conversion (see
// CLUSTERED_DEFERRED_PHASES_2-5.md): fullscreen pass that reads the Phase 2
// G-buffer (depth_prepass.frag's outputs) + the same cluster/shadow/env
// inputs shader.frag's forward path used, and shades every pixel the depth
// pre-pass covered. Paired with oit_composite.vert's fullscreen-triangle
// trick (no vertex buffer) -- see createDeferredLightingPipeline(),
// VulkanPipeline.cpp.
//
// This intentionally does NOT port shader.frag's per-material machinery
// (bindless texture sampling, texCoordFor/parallax, alpha testing) -- all of
// that already happened once, in depth_prepass.frag, and its result is
// exactly what the G-buffer holds. What's ported below is everything that
// runs AFTER material sampling in shader.frag's main(): sun light + shadows,
// ambient/IBL, clustered point lights, and the final composition tail
// (SSAO, minAmbientFloor, emissive, foliage translucency, cascade debug
// tint) -- copied verbatim except where noted.
//
// Known simplifications vs. the forward path (documented, not fixed here):
//  - sampleShadow()'s normal-offset bias uses the G-buffer's normal-mapped
//    N, not the pre-normal-map geometric normal shader.frag's forward path
//    uses -- the G-buffer only stores one normal (Phase 2 decision), so
//    normal-map-frequency detail can reintroduce a little shadow noise on
//    heavily normal-mapped surfaces. shader_oit.frag's forward path is
//    unaffected (still uses its own geometricN).
//  - geometric specular AA (normalFiltering()) isn't reapplied here.
//  - fragMaterialIndex < 0 ("no glTF material") fragments were already
//    approximated as flat dielectric in depth_prepass.frag -- see its own
//    comment -- rather than reproducing unlitMaterialFallback()'s bespoke
//    diffuse-only shading here.

layout(location = 0) out vec4 outColor;

// Identical to shader.frag's UniformBufferObject -- see its own comment
// there field-by-field. Declared in full (not a truncated prefix) since
// this pass needs almost all of it (shadows, clustering, ambient, SSAO,
// cascade debug) anyway.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;
    vec3 lightColor;
    vec4 ambientColorIntensity;
    int forceMaskForBlend;
    mat4 lightViewProj[4];
    vec4 cascadeSplitDepths;
    vec4 shadowNormalOffsetWorldSize;
    int shadowDebugVisualizeCascades;
    int ssaoEnabled;
    float minAmbientFloor;
    float roughnessFloor;
    int geometricSpecularAAEnabled;
    float envBrightnessCorrection;
    int pcssEnabled;
    float pcssLightSize;
    float pcssQuality;
    float foliageTranslucencyStrength;
    int lightCount;
    ivec4 clusterGridDim;
    vec2 clusterDepthSliceScaleBias;
    vec2 clusterScreenTileSize;
} ubo;

// --- Clustered light culling: SSBOs (set 2) -- identical to shader.frag's
// own declaration, see its comment there.
struct Light {
    vec4 posRange;
    vec4 colorIntensity;
    vec4 coneDir;
    vec4 coneAngles;
};
layout(std430, set = 2, binding = 0) readonly buffer LightsBuffer {
    Light lights[];
};

struct ClusterLightGridEntry {
    uint offset;
    uint count;
};
layout(std430, set = 2, binding = 1) readonly buffer ClusterLightIndicesBuffer {
    uint clusterLightIndices[];
};
layout(std430, set = 2, binding = 2) readonly buffer ClusterLightGridBuffer {
    ClusterLightGridEntry clusterLightGrid[];
};

// Identical to shader.frag's clusterIndexForFragment() -- see its comment.
uint clusterIndexForFragment(vec2 fragCoord, float fragViewDepth) {
    ivec3 gridDim = ubo.clusterGridDim.xyz;
    ivec2 tileXY = ivec2(fragCoord / ubo.clusterScreenTileSize);
    tileXY = clamp(tileXY, ivec2(0), gridDim.xy - ivec2(1));
    int slice = int(log2(max(fragViewDepth, 0.0001)) * ubo.clusterDepthSliceScaleBias.x - ubo.clusterDepthSliceScaleBias.y);
    slice = clamp(slice, 0, gridDim.z - 1);
    return uint(tileXY.x + gridDim.x * (tileXY.y + gridDim.y * slice));
}

// Set 0, binding 2 -- same shadowMap as shader.frag's forward path.
layout(binding = 2) uniform sampler2DArrayShadow shadowMap;

// Set 1 -- identical to shader.frag's own declarations, see its comments.
layout(set = 1, binding = 0) uniform samplerCube envMap;
layout(set = 1, binding = 1) uniform sampler2D ssaoTexture;
layout(set = 1, binding = 2) uniform sampler2DArray shadowMapRaw;

// Set 3 -- the Phase 2 G-buffer, written by depth_prepass.frag. All 5
// sampled via cullDepthSampler (NEAREST/CLAMP_TO_EDGE, createDeferredLightingResources()
// VulkanResources.cpp) -- exact per-pixel fetch, no filtering across surface
// boundaries.
layout(set = 3, binding = 0) uniform sampler2D gbufferDepth;
layout(set = 3, binding = 1) uniform sampler2D gbufferNormal;
layout(set = 3, binding = 2) uniform sampler2D gbufferAlbedo;
layout(set = 3, binding = 3) uniform sampler2D gbufferMetallicRoughness;
layout(set = 3, binding = 4) uniform sampler2D gbufferEmissive;

// Recomputed on the CPU each frame (glm::inverse(proj * view)) and passed as
// a push constant rather than a UBO field -- same "cheap, per-frame-only,
// doesn't need double-buffering" reasoning BilateralBlurPushConstants'
// invProj already uses (VulkanTypes.h). Used below to reconstruct world
// position from this pass' own screen-space + the G-buffer's stored depth.
layout(push_constant) uniform PushConstants {
    mat4 invViewProj;
} pc;

const float kPi = 3.14159265359;

// Cook-Torrance microfacet BRDF -- identical to shader.frag's own copies,
// see its comments.
float distributionGGX(vec3 N, vec3 H, float roughness) {
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.0);
    float NdotH2 = NdotH * NdotH;
    float denom = (NdotH2 * (a2 - 1.0) + 1.0);
    denom = kPi * denom * denom;
    return a2 / max(denom, 0.0000001);
}

float geometrySchlickGGX(float NdotV, float roughness) {
    float r = (roughness + 1.0);
    float k = (r * r) / 8.0;
    float denom = NdotV * (1.0 - k) + k;
    return NdotV / max(denom, 0.0000001);
}

float geometrySmith(float NdotV, float NdotL, float roughness) {
    float ggx2 = geometrySchlickGGX(NdotV, roughness);
    float ggx1 = geometrySchlickGGX(NdotL, roughness);
    return ggx1 * ggx2;
}

vec3 fresnelSchlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

// Same specialization-constant pattern as shader.frag -- see its own
// comment. Set by createDeferredLightingPipeline() (VulkanPipeline.cpp) to
// the same real values createGraphicsPipeline() uses.
layout(constant_id = 0) const float kShadowMapSize = 2048.0;
layout(constant_id = 1) const float kMaxEnvLod = 6.0;

// Identical to shader.frag's envBRDFApprox() -- see its comment.
vec2 envBRDFApprox(float NdotV, float roughness) {
    const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
    const vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
    vec4 r = roughness * c0 + c1;
    float a004 = min(r.x * r.x, exp2(-9.28 * NdotV)) * r.x + r.y;
    return vec2(-1.04, 1.04) * a004 + r.zw;
}

// Identical to shader.frag's atmosphereColor() -- keep in sync with that
// file's own comment on why every copy of this exists (no shared-GLSL-
// include mechanism in this codebase).
vec3 atmosphereColor(vec3 dir, vec3 sunDir, vec3 sunColor) {
    const vec3 betaR = vec3(5.8e-6, 13.5e-6, 33.1e-6) * 2.5e5;
    const float betaM = 21e-6 * 2.5e5;
    const float g = 0.65;

    float cosTheta = dot(dir, sunDir);
    float phaseR = 3.0 / (16.0 * kPi) * (1.0 + cosTheta * cosTheta);
    float g2 = g * g;
    float phaseM = (1.0 - g2) / (4.0 * kPi * pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5));

    float cosZenith = max(dir.y, -0.02);
    float zenithDeg = degrees(acos(clamp(cosZenith, -1.0, 1.0)));
    float airmass = 1.0 / (cosZenith + 0.50572 * pow(96.07995 - zenithDeg, -1.6364));

    vec3 extinction = exp(-(betaR + betaM) * airmass);
    vec3 inscatter = (betaR * phaseR + betaM * phaseM) * (1.0 - extinction) / max(betaR + betaM, 1e-6);
    return sunColor * inscatter;
}

// Identical to shader.frag's hemisphericAmbient() -- see its comment.
vec3 hemisphericAmbient(vec3 N) {
    vec3 sunDir = normalize(-ubo.lightDir);
    vec3 skyColor = atmosphereColor(vec3(0.0, 1.0, 0.0), sunDir, ubo.lightColor);
    const vec3 kGroundAlbedo = vec3(0.30, 0.28, 0.22);
    vec3 groundColor = skyColor * kGroundAlbedo * 0.5;
    return mix(groundColor, skyColor, dot(N, vec3(0.0, 1.0, 0.0)) * 0.5 + 0.5);
}

vec3 indirectSkyRadiance(vec3 N) {
    return hemisphericAmbient(N);
}

// Identical to shader.frag's sampleEnvironment() -- see its comment.
vec3 sampleEnvironment(vec3 N, vec3 V, vec3 albedo, vec3 F0, float roughness, float metallic, bool includeSpecularIBL) {
    vec3 diffuseIBL = indirectSkyRadiance(N) * albedo * (1.0 - metallic);
    if (!includeSpecularIBL) return diffuseIBL;

    vec3 R = reflect(-V, N);
    vec3 prefiltered = textureLod(envMap, R, roughness * kMaxEnvLod).rgb;
    float NdotV = max(dot(N, V), 0.0);
    vec2 brdf = envBRDFApprox(NdotV, roughness);
    vec3 specularIBL = prefiltered * (F0 * brdf.x + brdf.y) * ubo.envBrightnessCorrection;

    return diffuseIBL + specularIBL;
}

// Identical to shader.frag's interleavedGradientNoise()/viewSpaceDepth()/
// selectCascade() -- see their comments.
float interleavedGradientNoise(vec2 screenPos) {
    return fract(52.9829189 * fract(dot(screenPos, vec2(0.06711056, 0.00583715))));
}

float viewSpaceDepth(vec3 worldPos) {
    return -(ubo.view * vec4(worldPos, 1.0)).z;
}

int selectCascade(float viewDepth) {
    for (int i = 0; i < 3; ++i) {
        if (viewDepth < ubo.cascadeSplitDepths[i]) return i;
    }
    return 3;
}

// Identical to shader.frag's vogelDiskSample()/blockerSearch()/pcfShadow()/
// sampleCascade()/sampleShadow() -- see their comments.
vec2 vogelDiskSample(int i, int count, float phi) {
    const float kGoldenAngle = 2.39996323;
    float r = sqrt((float(i) + 0.5) / float(count));
    float theta = float(i) * kGoldenAngle + phi;
    return r * vec2(cos(theta), sin(theta));
}

const int kMaxPcssBlockerTaps = 16;
const int kMaxPcssPcfTaps = 32;

vec2 blockerSearch(vec2 shadowUV, float layer, float compareDepth, float searchRadiusTexels, int numTaps, float phi) {
    vec2 texelSize = 1.0 / vec2(kShadowMapSize);
    float blockerSum = 0.0;
    float blockerCount = 0.0;
    for (int i = 0; i < kMaxPcssBlockerTaps; ++i) {
        if (i >= numTaps) break;
        vec2 uv = shadowUV + vogelDiskSample(i, numTaps, phi) * searchRadiusTexels * texelSize;
        float depth = texture(shadowMapRaw, vec3(uv, layer)).r;
        if (depth < compareDepth) {
            blockerSum += depth;
            blockerCount += 1.0;
        }
    }
    return vec2(blockerCount > 0.0 ? blockerSum / blockerCount : 0.0, blockerCount);
}

float pcfShadow(vec2 shadowUV, float layer, float compareDepth) {
    vec2 texelSize = 1.0 / vec2(kShadowMapSize);
    float noiseAngle = interleavedGradientNoise(gl_FragCoord.xy) * 6.2831853;

    if (ubo.pcssEnabled == 0) {
        const vec2 kRotatedTaps[8] = vec2[](
            vec2(-1.5, 0.5), vec2(0.5, 1.5), vec2(1.5, -0.5), vec2(-0.5, -1.5),
            vec2(-2.5, -1.0), vec2(-1.0, 2.5), vec2(2.5, 1.0), vec2(1.0, -2.5)
        );
        float sinA = sin(noiseAngle);
        float cosA = cos(noiseAngle);
        mat2 tapRotation = mat2(cosA, sinA, -sinA, cosA);
        float shadow = 0.0;
        for (int i = 0; i < 8; ++i) {
            vec2 uv = shadowUV + (tapRotation * kRotatedTaps[i]) * texelSize;
            shadow += texture(shadowMap, vec4(uv, layer, compareDepth));
        }
        return shadow / 8.0;
    }

    float q = clamp(ubo.pcssQuality, 0.0, 100.0) / 100.0;
    int blockerTaps = int(mix(6.0, float(kMaxPcssBlockerTaps), q));
    int pcfTaps = int(mix(14.0, float(kMaxPcssPcfTaps), q));
    const float kBlockerSearchRadiusTexels = 5.0;

    vec2 blockerResult = blockerSearch(shadowUV, layer, compareDepth, kBlockerSearchRadiusTexels, blockerTaps, noiseAngle);
    if (blockerResult.y < 1.0) {
        return 1.0;
    }
    float avgBlockerDepth = blockerResult.x;

    const float kPenumbraScale = 50000.0;
    const float kMaxPenumbraTexels = 14.0;
    float penumbraTexels = clamp(
        ubo.pcssLightSize * (compareDepth - avgBlockerDepth) * kPenumbraScale,
        1.0, kMaxPenumbraTexels);

    float shadow = 0.0;
    for (int i = 0; i < kMaxPcssPcfTaps; ++i) {
        if (i >= pcfTaps) break;
        vec2 uv = shadowUV + vogelDiskSample(i, pcfTaps, noiseAngle) * penumbraTexels * texelSize;
        shadow += texture(shadowMap, vec4(uv, layer, compareDepth));
    }
    return shadow / float(pcfTaps);
}

float sampleCascade(int cascade, vec3 worldPos, vec3 normal, float grazingFactor) {
    vec3 offsetWorldPos = worldPos + normal * (ubo.shadowNormalOffsetWorldSize[cascade] * grazingFactor);
    vec4 lightClip = ubo.lightViewProj[cascade] * vec4(offsetWorldPos, 1.0);
    vec3 lightNDC = lightClip.xyz / lightClip.w;
    if (lightNDC.z < 0.0 || lightNDC.z > 1.0 ||
        lightNDC.x < -1.0 || lightNDC.x > 1.0 || lightNDC.y < -1.0 || lightNDC.y > 1.0) {
        return 1.0;
    }
    vec2 shadowUV = lightNDC.xy * 0.5 + 0.5;
    return pcfShadow(shadowUV, float(cascade), lightNDC.z);
}

float sampleShadow(vec3 worldPos, vec3 normal) {
    vec3 L = normalize(-ubo.lightDir);
    float grazingFactor = 1.0 - clamp(dot(normal, L), 0.0, 1.0);

    float viewDepth = viewSpaceDepth(worldPos);
    int cascade = selectCascade(viewDepth);
    float shadow = sampleCascade(cascade, worldPos, normal, grazingFactor);

    if (cascade < 3) {
        float prevSplit = cascade == 0 ? 0.0 : ubo.cascadeSplitDepths[cascade - 1];
        float split = ubo.cascadeSplitDepths[cascade];
        float blendBand = (split - prevSplit) * 0.3;
        float blendStart = split - blendBand;
        if (viewDepth > blendStart) {
            float nextShadow = sampleCascade(cascade + 1, worldPos, normal, grazingFactor);
            float t = clamp((viewDepth - blendStart) / max(blendBand, 1e-4), 0.0, 1.0);
            t = t * t * (3.0 - 2.0 * t);
            shadow = mix(shadow, nextShadow, t);
        }
    }
    return shadow;
}

// Identical to shader.frag's cascadeDebugColor()/applyCascadeDebugTint().
vec3 cascadeDebugColor(int cascade) {
    if (cascade == 0) return vec3(1.0, 0.3, 0.3);
    if (cascade == 1) return vec3(0.3, 1.0, 0.3);
    if (cascade == 2) return vec3(0.3, 0.4, 1.0);
    return vec3(1.0, 1.0, 0.3);
}

vec3 applyCascadeDebugTint(vec3 color, vec3 worldPos) {
    if (ubo.shadowDebugVisualizeCascades == 0) {
        return color;
    }
    int cascade = selectCascade(viewSpaceDepth(worldPos));
    return mix(color, cascadeDebugColor(cascade), 0.35);
}

// Identical to shader.frag's pointLightsContribution() -- see its comment.
vec3 pointLightsContribution(vec3 worldPos, vec3 N, vec3 V, vec3 albedo, vec3 F0, float roughness, float metallic) {
    vec3 result = vec3(0.0);
    float NdotV = max(dot(N, V), 0.0);

    uint clusterIdx = clusterIndexForFragment(gl_FragCoord.xy, viewSpaceDepth(worldPos));
    ClusterLightGridEntry grid = clusterLightGrid[clusterIdx];
    for (uint gi = 0u; gi < grid.count; ++gi) {
        uint i = clusterLightIndices[grid.offset + gi];
        vec3 toLight = lights[i].posRange.xyz - worldPos;
        float dist = length(toLight);
        vec3 L = toLight / max(dist, 1e-4);
        float NdotL = max(dot(N, L), 0.0);
        if (NdotL <= 0.0) continue;

        float coneFactor = 1.0;
        if (lights[i].coneDir.w > 0.5) {
            float cosAngle = dot(lights[i].coneDir.xyz, -L);
            coneFactor = smoothstep(lights[i].coneAngles.y, lights[i].coneAngles.x, cosAngle);
            if (coneFactor <= 0.0) continue;
        }

        float range = max(lights[i].posRange.w, 0.01);
        float distFactor = 1.0 / max(dist * dist, 0.01);
        float rangeWindow = clamp(1.0 - pow(dist / range, 4.0), 0.0, 1.0);
        distFactor *= rangeWindow * rangeWindow * coneFactor;
        if (distFactor <= 0.0) continue;

        vec3 H = normalize(V + L);
        float NDF = distributionGGX(N, H, roughness);
        float G = geometrySmith(NdotV, NdotL, roughness);
        vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);
        vec3 specular = (NDF * G * F) / max(4.0 * NdotV * NdotL, 1e-4);
        vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);

        vec3 lightColor = lights[i].colorIntensity.rgb * lights[i].colorIntensity.a;
        result += (kD * albedo / kPi + specular) * lightColor * NdotL * distFactor;
    }
    return result;
}

// Reconstructs world-space position from this fragment's screen position +
// the G-buffer's stored hardware depth, via pc.invViewProj -- standard
// "unproject NDC with clip.w = 1, then divide by the result's own w"
// technique (correct for any projection matrix, not just the direction-only
// use cluster_aabb_build.comp's screenToView() puts it to).
vec3 reconstructWorldPos(vec2 fragCoord, float rawDepth) {
    vec2 screenSize = vec2(textureSize(gbufferDepth, 0));
    vec2 ndcXY = (fragCoord / screenSize) * 2.0 - 1.0;
    vec4 worldH = pc.invViewProj * vec4(ndcXY, rawDepth, 1.0);
    return worldH.xyz / worldH.w;
}

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);

    // Sky/background pixels: depth_prepass.frag never wrote real depth here
    // (the pre-pass' depth attachment clears to 1.0 -- see recordCommandBuffer's
    // "Depth pre-pass" comment) -- port of the old forward path's implicit
    // "EQUAL against pre-pass depth" skip (graphicsPipeline's depthCompareOp),
    // just done as an explicit depth-sample check since a fullscreen
    // triangle has no per-pixel depth of its own to test with hardware
    // EQUAL the way real geometry did.
    float rawDepth = texelFetch(gbufferDepth, texel, 0).r;
    if (rawDepth >= 1.0) {
        discard;
    }

    vec3 worldPos = reconstructWorldPos(gl_FragCoord.xy, rawDepth);

    // G-buffer normal is view-space (Phase 2) -- rotate back to world space
    // via the view matrix's transpose, which equals its inverse since the
    // camera view matrix is rigid (rotation + translation only, no scale) --
    // same reasoning depth_prepass.vert's own world->view normal transform
    // relies on, just run in reverse.
    vec3 viewN = normalize(texelFetch(gbufferNormal, texel, 0).xyz);
    vec3 N = normalize(transpose(mat3(ubo.view)) * viewN);

    vec4 albedoSample = texelFetch(gbufferAlbedo, texel, 0);
    vec3 albedo = albedoSample.rgb;
    float occlusion = albedoSample.a;

    vec2 mr = texelFetch(gbufferMetallicRoughness, texel, 0).rg;
    float metallic = mr.r;
    // roughnessFloor clamp deliberately applied here, not in depth_prepass.frag
    // -- see that file's top comment for why (this pass has the full UBO,
    // the G-buffer write doesn't).
    float roughness = clamp(mr.g, ubo.roughnessFloor, 1.0);

    vec4 emissiveSample = texelFetch(gbufferEmissive, texel, 0);
    vec3 emissive = emissiveSample.rgb;
    bool isDoubleSided = emissiveSample.a > 0.5;

    vec3 V = normalize(ubo.camPos - worldPos);
    vec3 L = normalize(-ubo.lightDir);
    vec3 H = normalize(V + L);

    vec3 F0 = mix(vec3(0.04), albedo, metallic);

    float NdotL = max(dot(N, L), 0.0);
    float NdotV = max(dot(N, V), 0.0);
    // See this file's top comment: uses the G-buffer's (normal-mapped) N for
    // the normal-offset bias, not a separate pre-normal-map geometric normal
    // the way shader.frag's forward path does.
    float shadowFactor = sampleShadow(worldPos, N);

    vec3 lighting = vec3(0.0);
    if (NdotL > 0.0) {
        float NDF = distributionGGX(N, H, roughness);
        float G = geometrySmith(NdotV, NdotL, roughness);
        vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);

        vec3 specular = (NDF * G * F) / max(4.0 * NdotV * NdotL, 1e-4);
        vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);
        lighting = (kD * albedo / kPi + specular) * ubo.lightColor * NdotL * shadowFactor;
    }

    lighting += pointLightsContribution(worldPos, N, V, albedo, F0, roughness, metallic);

    // Identical to shader.frag's foliage-translucency wrap term -- see its
    // comment there -- gated on the doubleSided flag depth_prepass.frag
    // packed into gbufferEmissive.a.
    if (isDoubleSided && ubo.foliageTranslucencyStrength > 0.0) {
        const float kTranslucencyDistortion = 0.5;
        const float kTranslucencyPower = 4.0;
        const float kTranslucencyScale = 2.0;
        vec3 transmissionDir = L + N * kTranslucencyDistortion;
        float transmissionDot = pow(clamp(dot(V, -transmissionDir), 0.0, 1.0), kTranslucencyPower);
        lighting += albedo * ubo.lightColor * transmissionDot * kTranslucencyScale
            * shadowFactor * ubo.foliageTranslucencyStrength;
    }

    vec3 ambientTint = ubo.ambientColorIntensity.rgb * ubo.ambientColorIntensity.a;
    vec2 screenUV = gl_FragCoord.xy / vec2(textureSize(ssaoTexture, 0));
    vec4 ssaoSample = texture(ssaoTexture, screenUV);
    float ssaoFactor = ubo.ssaoEnabled != 0 ? ssaoSample.a : 1.0;
    vec3 ambient = sampleEnvironment(N, V, albedo, F0, roughness, metallic, true) * ambientTint * occlusion * ssaoFactor;

    vec3 color = ambient + lighting;
    color = max(color, vec3(ubo.minAmbientFloor));
    color += emissive;

    outColor = vec4(applyCascadeDebugTint(color, worldPos), 1.0);
}
