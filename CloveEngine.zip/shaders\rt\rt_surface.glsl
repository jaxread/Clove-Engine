// ============================================================================
// rt_surface.glsl -- fetch + unpack the surface at a ray-query hit (Phase 3).
//
// Reads the merged GpuVertex/index buffers (40-byte packed vertex) using the
// per-instance geometry offsets from AccelBuilder::instanceDataBuffer(), keyed
// by the TLAS instanceCustomIndex. Uses scalar block layout so the GLSL struct
// matches the tight C++ GpuVertex packing exactly (std430 would pad vec3->16).
//
// Requires in the including shader:
//   #extension GL_EXT_ray_query : require
//   #extension GL_EXT_scalar_block_layout : require
//   the three SSBO bindings declared below (set/binding per INTEGRATION).
// ============================================================================

#ifndef RT_SURFACE_GLSL
#define RT_SURFACE_GLSL

// Matches GpuVertex (VulkanTypes.h): 40 bytes, tightly packed.
struct GpuVertex {
    vec3 pos;      // offset 0
    uint normal;   // 12 -- A2B10G10R10_SNORM
    uint tangent;  // 16 -- A2B10G10R10_SNORM
    vec2 uv;       // 20
    vec2 uv2;      // 28
    uint color;    // 36 -- R8G8B8A8_UNORM
};

// Matches AccelBuilder::RtInstanceData.
struct RtInstance {
    uint vertexOffset;
    uint indexOffset;
    int  materialIndex;
    uint _pad;
};

layout(scalar, set = 2, binding = 1) readonly buffer RtVerts   { GpuVertex v[]; } rtVerts;
layout(std430, set = 2, binding = 2) readonly buffer RtIndices { uint       i[]; } rtIndices;
layout(std430, set = 2, binding = 3) readonly buffer RtInsts   { RtInstance inst[]; } rtInsts;

// Unpack a signed 10-10-10-2 normal to a unit vec3.
vec3 unpackNormalA2B10G10R10(uint p) {
    int x = int(p << 22) >> 22;   // sign-extend low 10 bits
    int y = int(p << 12) >> 22;
    int z = int(p <<  2) >> 22;
    return normalize(vec3(float(x), float(y), float(z)) / 511.0);
}

vec4 unpackColorR8G8B8A8(uint p) {
    return vec4(float(p & 0xFFu), float((p >> 8) & 0xFFu),
                float((p >> 16) & 0xFFu), float((p >> 24) & 0xFFu)) / 255.0;
}

struct HitSurface {
    vec3 worldPos;
    vec3 worldNormal;
    vec2 uv;
    vec4 vColor;
    int  materialIndex;
};

// Build the surface at a COMMITTED ray-query hit. worldPos is taken from the
// ray parametrization (origin + dir*t) for robustness; the normal is fetched,
// interpolated, and rotated into world space by the instance's object-to-world.
HitSurface fetchHitSurface(rayQueryEXT rq, vec3 rayOrigin, vec3 rayDir) {
    HitSurface s;

    uint instIdx = uint(rayQueryGetIntersectionInstanceCustomIndexEXT(rq, true));
    uint prim    = uint(rayQueryGetIntersectionPrimitiveIndexEXT(rq, true));
    vec2 bary    = rayQueryGetIntersectionBarycentricsEXT(rq, true);
    float t      = rayQueryGetIntersectionTEXT(rq, true);

    RtInstance ri = rtInsts.inst[instIdx];

    uint base = ri.indexOffset + prim * 3u;
    uint i0 = rtIndices.i[base + 0u] + ri.vertexOffset;
    uint i1 = rtIndices.i[base + 1u] + ri.vertexOffset;
    uint i2 = rtIndices.i[base + 2u] + ri.vertexOffset;

    GpuVertex v0 = rtVerts.v[i0];
    GpuVertex v1 = rtVerts.v[i1];
    GpuVertex v2 = rtVerts.v[i2];

    float w = 1.0 - bary.x - bary.y;
    vec3 nObj = normalize(
        unpackNormalA2B10G10R10(v0.normal) * w +
        unpackNormalA2B10G10R10(v1.normal) * bary.x +
        unpackNormalA2B10G10R10(v2.normal) * bary.y);

    // Object-to-world (4x3, row-major-ish) for this instance.
    mat4x3 o2w = rayQueryGetIntersectionObjectToWorldEXT(rq, true);
    mat3 rot = mat3(o2w[0], o2w[1], o2w[2]);

    s.worldPos    = rayOrigin + rayDir * t;
    s.worldNormal = normalize(rot * nObj);
    s.uv          = v0.uv * w + v1.uv * bary.x + v2.uv * bary.y;
    s.vColor      = unpackColorR8G8B8A8(v0.color) * w +
                    unpackColorR8G8B8A8(v1.color) * bary.x +
                    unpackColorR8G8B8A8(v2.color) * bary.y;
    s.materialIndex = ri.materialIndex;
    return s;
}

#endif // RT_SURFACE_GLSL
