#version 450

// Tessellation control shader for the POM displacement pipeline
// (createTessellatedGraphicsPipeline/createTessellatedShadowPipeline,
// VulkanPipeline.cpp). Only ever bound for draws whose material has a
// heightTexture assigned (see the renderInstances heightmap-subset
// partition, VulkanResources.cpp/VulkanRender.cpp) -- shader.vert (reused
// unchanged as this pipeline's vertex/control-point stage) already computed
// everything per-vertex; this stage's only real job is passing that through
// and deciding how many times pom_displace.tese subdivides each triangle.
layout(vertices = 3) out;

// Only the prefix this stage actually needs (view/proj/camPos) is declared --
// same partial-declaration convention shader.vert itself uses for this same
// binding (see its own comment): a uniform block's layout is positional, so
// every *preceding* field has to appear in order, but trailing fields this
// stage never reads can just be omitted.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
} ubo;

layout(push_constant) uniform TessellationPushConstants {
    // GraphicsUI's Max Tessellation Level slider -- gl_TessLevelOuter/Inner
    // approach this at the falloff distance's near edge, down to 1
    // (untessellated) far past it. See TessellationPushConstants' own
    // comment, VulkanTypes.h, for why this occupies push-constant offset 4,
    // not 0.
    float maxTessLevel;
    // World-space distance from the camera at which tessellation has fully
    // ramped down to 1 -- patches closer than this interpolate up toward
    // maxTessLevel; patches farther than this stay untessellated.
    float falloffDistance;
} pc;

layout(location = 0) in vec3 fragWorldPos[];
layout(location = 1) in vec3 fragNormal[];
layout(location = 2) in vec2 fragUV[];
layout(location = 3) in vec4 fragTangent[];
layout(location = 4) in int fragMaterialIndex[];
layout(location = 5) in vec4 fragColor[];
layout(location = 6) in vec2 fragUV2[];

layout(location = 0) out vec3 outWorldPos[];
layout(location = 1) out vec3 outNormal[];
layout(location = 2) out vec2 outUV[];
layout(location = 3) out vec4 outTangent[];
layout(location = 5) out vec4 outColor[];
layout(location = 6) out vec2 outUV2[];
// Patch-constant, not arrayed like the varyings above -- every control point
// of a triangle drawn by this engine already shares the same material (one
// GpuMaterial per draw call, see DrawRun/GpuInstanceData), so there's
// nothing to interpolate; a single patch out avoids pom_displace.tese having
// to pick one of 3 identical array entries.
layout(location = 7) patch out int patchMaterialIndex;

void main() {
    outWorldPos[gl_InvocationID] = fragWorldPos[gl_InvocationID];
    outNormal[gl_InvocationID] = fragNormal[gl_InvocationID];
    outUV[gl_InvocationID] = fragUV[gl_InvocationID];
    outTangent[gl_InvocationID] = fragTangent[gl_InvocationID];
    outColor[gl_InvocationID] = fragColor[gl_InvocationID];
    outUV2[gl_InvocationID] = fragUV2[gl_InvocationID];

    // Tessellation levels are patch-constant data -- only one invocation
    // needs to (and per spec, only one should) write them.
    if (gl_InvocationID == 0) {
        patchMaterialIndex = fragMaterialIndex[0];

        vec3 patchCenter = (fragWorldPos[0] + fragWorldPos[1] + fragWorldPos[2]) / 3.0;
        float dist = length(ubo.camPos - patchCenter);
        float t = clamp(1.0 - dist / max(pc.falloffDistance, 1e-3), 0.0, 1.0);
        float level = mix(1.0, max(pc.maxTessLevel, 1.0), t);

        gl_TessLevelOuter[0] = level;
        gl_TessLevelOuter[1] = level;
        gl_TessLevelOuter[2] = level;
        gl_TessLevelInner[0] = level;
    }
}
