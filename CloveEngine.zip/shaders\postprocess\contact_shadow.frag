#version 450

// Screen-space contact shadows -- ray-marches the depth buffer toward the
// light to catch small-scale, close-contact occlusion (e.g. a foot touching
// the ground, or a leg against a wall) that the shadow map's own texel
// resolution can't resolve. Runs right after SSAO (recordCommandBuffer's
// "Contact shadow pass"), reads the same depth buffer, same fullscreen-
// triangle shape (oit_composite.vert reused, see ssao.frag's identical top
// comment). Output is a single scalar in [0,1] (1 = fully lit, 0 = fully
// occluded), multiplied into shader.frag's direct lighting term alongside
// the PCSS shadow-map result (see contactFactor's sample site there) --
// unlike SSAO, this attenuates DIRECT light, not ambient, since it's
// approximating the same thing a shadow map does, just at a resolution the
// shadow map's own texel size can't reach.
layout(location = 0) in vec2 fragUV;

layout(location = 0) out float outFactor;

layout(binding = 0) uniform sampler2D depthBuffer;
// Reuses SSAO's own per-frame UBO buffer (SsaoUbo, VulkanTypes.h) -- proj/
// invProj for view-space reconstruction (identical need to ssao.frag's own),
// plus lightDirView (this pass' only genuinely new per-frame input). See
// SsaoUbo's own comment for why riding on that buffer beats a dedicated one.
layout(binding = 1) uniform SsaoUboBlock {
    mat4 proj;
    mat4 invProj;
    vec3 lightDirView;
} ssaoUbo;

layout(push_constant) uniform PushConstants {
    float maxDistance;
    float thickness;
    float intensity;
    int stepCount;
    int frameIndex;
} pc;

// Same formula as ssao.frag's own copy (Jimenez et al., "Next Generation
// Post Processing in Call of Duty: Advanced Warfare", 2014).
float interleavedGradientNoise(vec2 screenPos) {
    return fract(52.9829189 * fract(dot(screenPos, vec2(0.06711056, 0.00583715))));
}

void main() {
    float depth = texture(depthBuffer, fragUV).r;
    if (depth >= 1.0) {
        // Sky/background -- nothing to shadow.
        outFactor = 1.0;
        return;
    }

    vec4 ndc = vec4(fragUV * 2.0 - 1.0, depth, 1.0);
    vec4 viewPosH = ssaoUbo.invProj * ndc;
    vec3 viewPos = viewPosH.xyz / viewPosH.w;

    // lightDirView already points TOWARD the light (negated from
    // UniformBufferObject::lightDir -- see updateUniformBuffer's own
    // comment where this is filled in), so marching straight along it walks
    // from the shaded surface toward the light source.
    vec3 marchDir = normalize(ssaoUbo.lightDirView);

    // Per-pixel jittered step offset (not a fixed lockstep grid) -- same
    // "animated IGN" trick ssao.frag's own noise rotation uses, so a small,
    // fixed step count reads as soft dithering rather than banded
    // stair-stepping. Rotated by frameIndex too since this pass has no
    // temporal accumulation of its own to lean on the way SSAO does -- the
    // dither still needs to not be static frame to frame.
    const float kGoldenRatio = 0.6180339887498949;
    float jitter = fract(interleavedGradientNoise(gl_FragCoord.xy) + float(pc.frameIndex) * kGoldenRatio);

    float stepSize = pc.maxDistance / float(pc.stepCount);
    float occlusion = 0.0;
    for (int i = 0; i < pc.stepCount; ++i) {
        float t = (float(i) + jitter) * stepSize;
        vec3 samplePos = viewPos + marchDir * t;

        vec4 sampleClip = ssaoUbo.proj * vec4(samplePos, 1.0);
        if (sampleClip.w <= 0.0) break; // marched behind the camera
        vec2 sampleUV = (sampleClip.xy / sampleClip.w) * 0.5 + 0.5;
        if (sampleUV.x < 0.0 || sampleUV.x > 1.0 || sampleUV.y < 0.0 || sampleUV.y > 1.0) break;

        float sceneDepth = texture(depthBuffer, sampleUV).r;
        if (sceneDepth >= 1.0) continue; // sky/background -- can't occlude anything

        vec4 sceneNdc = vec4(sampleUV * 2.0 - 1.0, sceneDepth, 1.0);
        vec4 sceneViewH = ssaoUbo.invProj * sceneNdc;
        vec3 sceneViewPos = sceneViewH.xyz / sceneViewH.w;

        // Positive "distance from camera", same convention (and sign
        // reasoning) as ssao.frag's own fragDist/sampleDist/sceneDist.
        float sampleDist = -samplePos.z;
        float sceneDist = -sceneViewPos.z;

        // Occluded once the marched point has gone BEHIND the real surface
        // stored at that screen position (sampleDist > sceneDist) but not so
        // far behind that it's actually some unrelated, much-farther object
        // (sampleDist < sceneDist + thickness) -- `thickness` stands in for
        // how "thick" a real occluder is assumed to be, the same self-
        // occlusion guard ssao.frag's own fixed 0.025 bias serves, just
        // sized in view-space units here since a marched ray (unlike SSAO's
        // fixed-radius hemisphere) can travel arbitrarily far.
        if (sampleDist > sceneDist && sampleDist < sceneDist + pc.thickness) {
            occlusion = 1.0;
            break;
        }
    }

    float factor = 1.0 - occlusion;
    outFactor = pow(clamp(factor, 0.0, 1.0), pc.intensity);
}
