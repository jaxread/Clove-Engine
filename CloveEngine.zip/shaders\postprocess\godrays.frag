#version 450

// Screen-space "crepuscular rays" (Sousa 2007 / GPU Gems 3 "Volumetric Light
// Scattering as a Post-Process") -- radially samples a bright-pass-extracted
// mask toward the sun's projected screen position, decaying each step.
// brightMask (bound below) is NOT the raw composited scene -- it's
// hdrResolveImage already run through bloomThresholdPipeline/
// bloom_threshold.frag first (see recordCommandBuffer's "God Rays pass"
// comment, VulkanRender.cpp), so it's bright only at the sky/sun and
// genuinely dark everywhere occluding geometry sits. That dark/bright
// contrast is what this walk actually carves into visible shafts -- radially
// blurring the full scene directly (the previous version of this pass) has
// nowhere near enough contrast to read as anything but a uniform glow.
// Cheap, single-pass, no temporal accumulation -- see recordCommandBuffer for
// how sunScreenPos/strength are derived on the CPU side each frame.

layout(location = 0) in vec2 fragUV;
layout(location = 0) out vec4 outColor;

layout(binding = 0) uniform sampler2D brightMask;

layout(push_constant) uniform PushConstants {
    vec2 sunScreenPos;
    // GraphicsUI's God Rays "Intensity" slider, with the off-screen/
    // behind-camera edge fade already folded in on the CPU side -- see this
    // struct's own comment (VulkanTypes.h). Zero here just makes the pass a
    // wasted (if harmless) draw; recordCommandBuffer skips the draw entirely
    // instead when God Rays is disabled.
    float strength;
} pc;

const int kNumSamples = 24;
const float kDecay = 0.95;
const float kWeight = 0.4;
const float kDensity = 0.9;

void main() {
    vec2 deltaTexCoord = (fragUV - pc.sunScreenPos) * (kDensity / float(kNumSamples));
    vec2 texCoord = fragUV;
    float illuminationDecay = 1.0;
    vec3 color = vec3(0.0);
    for (int i = 0; i < kNumSamples; ++i) {
        texCoord -= deltaTexCoord;
        vec3 samp = texture(brightMask, clamp(texCoord, 0.0, 1.0)).rgb;
        color += samp * illuminationDecay * kWeight;
        illuminationDecay *= kDecay;
    }
    outColor = vec4(color * pc.strength, 1.0);
}
