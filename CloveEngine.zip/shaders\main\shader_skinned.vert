#version 450

// Skinned variant of shader.vert. Pairs with the SAME shader.frag -- every
// out varying matches shader.vert's location/type exactly, so the fragment
// stage can't tell a skinned vertex from a static one.
//
// Descriptor layout is DECOUPLED from your static pipeline on purpose:
//   set 0 = YOUR existing frame descriptor set, reused by handle. The vertex
//           stage only reads the camera UBO (binding 0) out of it; the rest of
//           set 0 (materials, textures, shadow maps, IBL) is consumed by
//           shader.frag exactly as it already is. SkinnedRenderer never needs
//           to know set 0's full contents -- it takes the layout as a handle.
//   set 1 = YOUR existing env-map set, reused by handle -- shader.frag (paired
//           unchanged with this vertex stage) declares `layout(set = 1, ...)`
//           for envMap/ssaoTexture/shadowMapRaw, so this
//           vertex stage doesn't touch set 1 at all; it's just reserved.
//   set 2 = YOUR existing clusterLightingReadSetLayout, reused by handle --
//           shader.frag's pointLightsContribution() (added by the clustered-
//           lighting work) declares `layout(set = 2, ...)` for
//           LightsBuffer/ClusterLightIndicesBuffer/ClusterLightGridBuffer,
//           so set 2 was already taken by the time this comment was written;
//           this vertex stage doesn't touch it either.
//   set 3 = skinning data OWNED by SkinnedRenderer: per-instance transforms
//           (binding 0) and the joint-matrix palette (binding 1). Pushed out
//           to set 3 specifically because set 2 was claimed by cluster
//           lighting first.
// This is what lets the skinned pipeline slot in without rebuilding your
// material/texture descriptor layout.

layout(set = 0, binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;
    vec3 lightColor;
    vec4 ambientColorIntensity;
    int forceMaskForBlend;
} ubo;

struct SkinnedInstanceData {
    mat4 model;
    vec4 normalMatrixCol0;
    vec4 normalMatrixCol1;
    vec4 normalMatrixCol2;
    int materialIndex;
    int jointOffset;   // first index into the palette for this instance's rig
    int jointCount;
    int pad0;
};

layout(std430, set = 3, binding = 0) readonly buffer SkinnedInstanceBuffer {
    SkinnedInstanceData instances[];
} instanceBuffer;

layout(std430, set = 3, binding = 1) readonly buffer JointPalette {
    mat4 jointMatrices[];
} palette;

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec4 inNormal;
layout(location = 2) in vec2 inUV;
layout(location = 3) in vec4 inTangent;
layout(location = 4) in vec4 inColor;
layout(location = 5) in vec2 inUV2;
layout(location = 6) in uvec4 inJoints;
layout(location = 7) in vec4 inWeights;

layout(location = 0) out vec3 fragWorldPos;
layout(location = 1) out vec3 fragNormal;
layout(location = 2) out vec2 fragUV;
layout(location = 3) out vec4 fragTangent;
layout(location = 4) flat out int fragMaterialIndex;
layout(location = 5) out vec4 fragColor;
layout(location = 6) out vec2 fragUV2;

void main() {
    SkinnedInstanceData inst = instanceBuffer.instances[gl_InstanceIndex];
    int base = inst.jointOffset;

    mat4 skin =
        inWeights.x * palette.jointMatrices[base + int(inJoints.x)] +
        inWeights.y * palette.jointMatrices[base + int(inJoints.y)] +
        inWeights.z * palette.jointMatrices[base + int(inJoints.z)] +
        inWeights.w * palette.jointMatrices[base + int(inJoints.w)];

    if (inWeights.x + inWeights.y + inWeights.z + inWeights.w < 1e-4)
        skin = mat4(1.0);

    vec4 skinnedPos = skin * vec4(inPosition, 1.0);
    vec4 worldPos = inst.model * skinnedPos;
    gl_Position = ubo.proj * ubo.view * worldPos;

    mat3 normalMatrix = mat3(inst.normalMatrixCol0.xyz, inst.normalMatrixCol1.xyz, inst.normalMatrixCol2.xyz);
    mat3 skin3 = mat3(skin);

    fragWorldPos = worldPos.xyz;
    fragNormal = normalize(normalMatrix * (skin3 * inNormal.xyz));
    fragTangent = vec4(normalize(mat3(inst.model) * (skin3 * inTangent.xyz)), inTangent.w);
    fragUV = inUV;
    fragUV2 = inUV2;
    fragMaterialIndex = inst.materialIndex;
    fragColor = inColor;
}
