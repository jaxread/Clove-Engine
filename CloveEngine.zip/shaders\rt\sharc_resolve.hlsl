// ============================================================================
// sharc_resolve.hlsl -- Phase 4: SHaRC resolve pass.
//
// One thread per hash-grid entry: folds this frame's atomically-accumulated
// samples (sharc_update.hlsl's SharcAddVoxelData calls) into stable per-cell
// radiance, evicts stale entries, and clears the accumulation buffer for next
// frame. Almost verbatim RTXGI's own Samples/Pathtracer/SharcResolve.hlsl --
// see SharcResolveEntry itself (SharcCommon.h) for the real logic; this file
// is just the dispatch shell around it.
// ============================================================================

#define SHARC_ENABLE_64_BIT_ATOMICS 1
#define SHARC_UPDATE 0
#define SHARC_QUERY 0

#include "SharcCommon.h"

[[vk::binding(0, 0)]] RWStructuredBuffer<uint64_t> u_HashEntriesBuffer : register(u0, space0);
[[vk::binding(1, 0)]] RWStructuredBuffer<SharcAccumulationData> u_AccumulationBuffer : register(u1, space0);
[[vk::binding(2, 0)]] RWStructuredBuffer<SharcPackedData> u_ResolvedBuffer : register(u2, space0);

// Every field is an explicit float4/uint4 -- avoids relying on HLSL's
// scalar-packs-into-a-vector's-leftover-bytes cbuffer rule matching C++'s
// plain struct layout exactly; the C++ side (VulkanTypes.h) mirrors this
// field-for-field with the same alignas(16) discipline.
[[vk::push_constant]]
struct SharcResolvePushConstants {
    float4 cameraPosition;      // xyz = world position, w = sceneScale
    float4 cameraPositionPrev;  // xyz = world position, w unused
    uint4 params;                // x=capacity, y=accumulationFrameNum, z=staleFrameNumMax, w=frameIndex
    float4 misc;                 // x = radianceScale
} pc;

static const uint LINEAR_BLOCK_SIZE = 256;

[numthreads(LINEAR_BLOCK_SIZE, 1, 1)]
void main(uint3 dtid : SV_DispatchThreadID)
{
    SharcParameters sharcParameters;
    sharcParameters.gridParameters.cameraPosition = pc.cameraPosition.xyz;
    sharcParameters.gridParameters.logarithmBase = SHARC_GRID_LOGARITHM_BASE;
    sharcParameters.gridParameters.sceneScale = pc.cameraPosition.w;
    sharcParameters.gridParameters.levelBias = SHARC_GRID_LEVEL_BIAS;

    sharcParameters.hashMapData.capacity = pc.params.x;
    sharcParameters.hashMapData.hashEntriesBuffer = u_HashEntriesBuffer;

    sharcParameters.accumulationBuffer = u_AccumulationBuffer;
    sharcParameters.resolvedBuffer = u_ResolvedBuffer;
    sharcParameters.radianceScale = pc.misc.x;
    sharcParameters.enableAntiFireflyFilter = true;

    SharcResolveParameters resolveParameters;
    resolveParameters.cameraPositionPrev = pc.cameraPositionPrev.xyz;
    resolveParameters.accumulationFrameNum = pc.params.y;
    resolveParameters.staleFrameNumMax = pc.params.z;
    resolveParameters.frameIndex = pc.params.w;

    SharcResolveEntry(dtid.x, sharcParameters, resolveParameters);
}
