#version 450

// Bakes one face of the environment cubemap (VulkanApp.h's envMapImage) --
// reused as a cheap stand-in for both diffuse irradiance and prefiltered
// specular in shader.frag/shader_oit.frag (see their sampleEnvironment
// comments), instead of a real convolution/GGX prefilter pass. Only run on
// a dirty frame (envMapDirty, VulkanApp.h) -- see recordCommandBuffer's
// "Environment bake" comment.
//
// This is sky.frag's own gradient + sun-disc formula, duplicated rather
// than shared (same "identical to X, see its comment" precedent
// shader_oit.frag already sets for shader.frag's helpers) -- see sky.frag
// for the formula's own rationale. The only real difference is *how*
// worldDir is obtained: sky.frag reconstructs it from the main camera's
// view/proj for an on-screen pixel; this instead derives it analytically
// from which of the 6 fixed cube faces is currently being rendered (a
// push constant, not a matrix -- a cubemap face is always a fixed
// axis-aligned 90-degree view, so there's nothing to look up).
layout(location = 0) in vec2 fragUV;
layout(location = 0) out vec4 outColor;

// Same UBO prefix as sky.frag -- only lightDir/lightColor are actually read
// here, but view/proj/camPos still have to be declared in order to keep
// their std140 offsets (and so lightDir/lightColor's) lined up with every
// other shader reading this same binding 0.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir; // points FROM the light TOWARD the scene
    vec3 lightColor;
} ubo;

layout(push_constant) uniform PushConstants {
    int faceIndex;
} pc;

const float kPi = 3.14159265;

// Single-scattering Rayleigh + Mie sky color -- IDENTICAL copy of sky.frag's
// own atmosphereColor(); see that file for the full rationale/comments. Keep
// both in sync (this codebase has no shared-GLSL-include mechanism).
vec3 atmosphereColor(vec3 dir, vec3 sunDir, vec3 sunColor) {
    const vec3 betaR = vec3(5.8e-6, 13.5e-6, 33.1e-6) * 2.5e5;
    const float betaM = 21e-6 * 2.5e5;
    // Mie asymmetry -- lowered from 0.76, see sky.frag's identical constant
    // for why (the day-cycle "too bright" fix: the phase peak at cosTheta==1
    // scales like 1/(1-g)^3).
    const float g = 0.65;

    float cosTheta = dot(dir, sunDir);
    float phaseR = 3.0 / (16.0 * kPi) * (1.0 + cosTheta * cosTheta);
    float g2 = g * g;
    float phaseM = (1.0 - g2) / (4.0 * kPi * pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5));

    float cosZenith = max(dir.y, -0.02);
    float zenithDeg = degrees(acos(clamp(cosZenith, -1.0, 1.0)));
    float airmass = 1.0 / (cosZenith + 0.50572 * pow(96.07995 - zenithDeg, -1.6364));

    vec3 extinction = exp(-(betaR + betaM) * airmass);
    vec3 inscatter = (betaR * phaseR + betaM * phaseM) * (1.0 - extinction) / max(betaR + betaM, 1e-6);
    return sunColor * inscatter;
}

// Standard cube-face direction reconstruction (Vulkan/D3D face order:
// +X,-X,+Y,-Y,+Z,-Z, matching envMapFaceViews'/recordCommandBuffer's own
// face-index convention) -- uv is in [-1, 1], one corner of the face's own
// 90-degree view. Verified visually, not just on paper: a wrong sign here
// would show up as a mirrored/rotated reflection as the camera orbits (see
// this feature's plan verification notes).
vec3 cubeFaceDirection(int face, vec2 uv) {
    if (face == 0) return normalize(vec3(1.0, -uv.y, -uv.x));   // +X
    if (face == 1) return normalize(vec3(-1.0, -uv.y, uv.x));  // -X
    if (face == 2) return normalize(vec3(uv.x, 1.0, uv.y));    // +Y
    if (face == 3) return normalize(vec3(uv.x, -1.0, -uv.y));  // -Y
    if (face == 4) return normalize(vec3(uv.x, -uv.y, 1.0));   // +Z
    return normalize(vec3(-uv.x, -uv.y, -1.0));                 // -Z
}

void main() {
    vec2 uv = fragUV * 2.0 - 1.0;
    vec3 worldDir = cubeFaceDirection(pc.faceIndex, uv);

    // Identical to sky.frag's sun disc + gradient formula from here down --
    // see its comments for the reasoning behind each piece.
    vec3 sunDir = normalize(-ubo.lightDir);
    float sunDot = dot(worldDir, sunDir);

    float sunDisc = smoothstep(0.9995, 0.9998, sunDot);
    float sunGlow = smoothstep(0.995, 0.9993, sunDot) * 0.35;

    // Real scattering for the day-sky half -- see sky.frag's own identical
    // line for the full rationale.
    vec3 daySky = atmosphereColor(worldDir, sunDir, ubo.lightColor);

    vec3 nightColorTop = vec3(0.01, 0.015, 0.03);
    vec3 nightColorHorizon = vec3(0.04, 0.05, 0.09);
    float horizonMix = clamp(worldDir.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 nightSky = mix(nightColorHorizon, nightColorTop, horizonMix);

    const float kSkyReferenceLuminance = 4.0;
    // Floored -- see sky.frag's own identical comment (this pass is a
    // deliberate duplicate of its formula). Must match VulkanRender.cpp's
    // kMinSkyBrightnessFactor (updateUniformBuffer) and sky.frag's own.
    const float kMinSkyBrightnessFactor = 0.04;
    float lightLuminance = dot(ubo.lightColor, vec3(0.2126, 0.7152, 0.0722));
    float skyBrightnessFactor = clamp(lightLuminance / kSkyReferenceLuminance, kMinSkyBrightnessFactor, 1.0);

    // No hand-authored twilight-tint overlay anymore -- see sky.frag's own
    // identical comment for why real scattering already covers it.
    vec3 skyColor = mix(nightSky, daySky, skyBrightnessFactor);

    vec3 color = skyColor + ubo.lightColor * (sunDisc + sunGlow);
    outColor = vec4(color, 1.0);
}
