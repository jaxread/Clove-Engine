#version 450
#extension GL_EXT_nonuniform_qualifier : enable

// Companion to rsm.vert -- see its own comment. Computes this texel's
// outgoing flux (direct sunlight reflected toward the scene -- the
// "virtual point light" rsm_gather.comp treats every RSM texel as) and
// writes it alongside the world normal already interpolated from rsm.vert,
// so rsm_gather.comp never has to re-derive any lighting itself, just
// weight and sum what's already sitting here.
//
// Deliberately Lambertian (albedo * NdotL), not shader.frag's full
// Cook-Torrance BRDF: RSM only ever approximates the DIFFUSE bounce (real
// specular inter-reflection needs a much more expensive technique), so a
// plain diffuse response here is the right amount of physical accuracy,
// not a shortcut being taken. Same alpha-test logic as depth_prepass.frag
// (its own closest analog -- see that file's comment) so a foliage/fence
// card's transparent regions don't cast opaque flux either.

layout(location = 0) in vec2 fragUV;
layout(location = 1) flat in int fragMaterialIndex;
layout(location = 2) in vec4 fragColor;
layout(location = 3) in vec2 fragUV2;
layout(location = 4) in vec3 fragWorldNormal;

layout(location = 0) out vec4 outNormal; // xyz = world normal * 0.5 + 0.5 (UNORM-safe), w unused
layout(location = 1) out vec4 outFlux;   // rgb = outgoing flux (HDR), a unused

// Prefix of shader.frag's UniformBufferObject up through lightColor --
// forceMaskForBlend (needed below for BLEND-material alpha testing, same as
// depth_prepass.frag) is the next field after it, so this mirrors exactly
// that same scope and no further; nothing here needs view/proj (this pass
// doesn't use the camera at all) but they still have to be declared to keep
// every later field's byte offset correct (std140 is purely positional --
// see depth_prepass.frag's identical full-prefix mirror for the same
// reason).
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;   // points FROM the light TOWARD the scene
    vec3 lightColor; // already color * intensity
    vec4 ambientColorIntensity;
    int forceMaskForBlend;
} ubo;

layout(binding = 4) uniform sampler2D bindlessTextures[];

// Mirrors GpuMaterial field-for-field -- identical to shader.frag/
// depth_prepass.frag's own Material struct, see shader.frag's comment.
struct Material {
    vec4 baseColorFactor;
    vec4 emissiveFactor;
    int baseColorTexture;
    int metallicRoughnessTexture;
    int normalTexture;
    int occlusionTexture;
    int emissiveTexture;
    float metallicFactor;
    float roughnessFactor;
    float normalScale;
    float occlusionStrength;
    float alphaCutoff;
    int alphaMode; // 0 = OPAQUE, 1 = MASK, 2 = BLEND
    int doubleSided;
    int texCoordSets;
    int _pad0;
    int _pad1;
    int _pad2;
};

layout(std430, binding = 1) readonly buffer MaterialBuffer {
    Material materials[];
} materialBuffer;

const float kZeroAlphaEpsilon = 0.02;

// Identical to shader.frag/depth_prepass.frag's texCoordFor().
vec2 texCoordFor(int texCoordSets, int bit) {
    return ((texCoordSets & bit) != 0) ? fragUV2 : fragUV;
}

void main() {
    vec3 N = normalize(fragWorldNormal);
    outNormal = vec4(N * 0.5 + 0.5, 0.0);

    vec3 toLight = normalize(-ubo.lightDir);
    float ndotl = max(dot(N, toLight), 0.0);

    if (fragMaterialIndex < 0) {
        // No glTF material -- flat mid-grey albedo (same "reasonable
        // fallback" idea shader.frag's unlitMaterialFallback() uses), not
        // zero flux, so a material-less prop doesn't become a permanent
        // black hole for bounce light.
        outFlux = vec4(vec3(0.5) * ndotl * ubo.lightColor, 0.0);
        return;
    }

    Material mat = materialBuffer.materials[fragMaterialIndex];

    // glTF spec: COLOR_0 multiplies into baseColor alongside baseColorFactor
    // and the base color texture -- same as shader.frag/depth_prepass.frag.
    vec4 baseColor = mat.baseColorFactor * fragColor;
    if (mat.baseColorTexture >= 0) {
        baseColor *= texture(bindlessTextures[nonuniformEXT(mat.baseColorTexture)], texCoordFor(mat.texCoordSets, 1));
    }

    if (baseColor.a < kZeroAlphaEpsilon) {
        discard;
    }
    if (mat.alphaMode == 1) { // MASK
        if (baseColor.a < mat.alphaCutoff) discard;
    } else if (mat.alphaMode == 2) { // BLEND, only reachable here when forced to MASK
        if (ubo.forceMaskForBlend != 0) {
            float cutoff = mat.alphaCutoff > 0.0 ? mat.alphaCutoff : 0.5;
            if (baseColor.a < cutoff) discard;
        }
    }
    // alphaMode == 0 (OPAQUE): no cutoff test, matches shader.frag.

    // Metal has near-zero diffuse albedo (same physical idea shader.frag's
    // own F0/diffuse split relies on) -- fading baseColor's contribution
    // down by metallic is enough for this pass's purposes without needing
    // shader.frag's full F0/roughness machinery, since RSM never computes a
    // specular bounce at all.
    float metallic = mat.metallicFactor;
    if (mat.metallicRoughnessTexture >= 0) {
        // glTF packs this as (unused, roughness, metallic) in the G/B
        // channels -- same layout shader.frag's own sampling relies on.
        metallic *= texture(bindlessTextures[nonuniformEXT(mat.metallicRoughnessTexture)], texCoordFor(mat.texCoordSets, 2)).b;
    }
    vec3 diffuseAlbedo = baseColor.rgb * (1.0 - metallic);

    outFlux = vec4(diffuseAlbedo * ndotl * ubo.lightColor, 0.0);
}
