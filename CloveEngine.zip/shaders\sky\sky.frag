#version 450

// Simple procedural sky + visible sun disc, drawn as a background before the
// depth-tested opaque geometry in pass 1 (recordCommandBuffer, VulkanRender.
// cpp) so the sun's on-screen position always matches LightingUI's Sun Angle
// slider and its brightness matches the Sun Intensity slider -- both just
// read the same ubo.lightDir/lightColor every other lit fragment in the
// scene already uses, so there's no separate "sun position" state to keep in
// sync.
//
// Masked to background-only pixels via depth, not a stencil bit or a flag:
// createSkyPipeline (VulkanPipeline.cpp) sets depthCompareOp = EQUAL with
// depth writes off, and sky.vert pins every fragment's depth to exactly 1.0
// (the far plane) -- the same literal clear value the depth pre-pass wrote
// for anything it didn't touch. So this pass's fragments only survive the
// depth test where nothing opaque exists yet, and opaque geometry (already
// drawn into the depth buffer with real, smaller depth values by the
// pre-pass) is completely unaffected either way this is ordered relative to
// it in pass 1.

layout(location = 0) in vec2 fragUV;
layout(location = 0) out vec4 outColor;

layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir; // points FROM the light TOWARD the scene
    vec3 lightColor;
} ubo;

const float kPi = 3.14159265;

// Single-scattering Rayleigh + Mie sky color for direction `dir`, given the
// current sun direction and (already day/night-ramped, see
// updateUniformBuffer, VulkanRender.cpp) sun/moon color. No raymarching/loop
// -- optical depth uses the Kasten-Young (1989) closed-form airmass
// approximation instead of numeric integration, so this is a handful of
// vector ops, cheap enough per-pixel AND per-cubemap-texel (see
// sky_cubemap.frag's own copy of this same function). Returns the SCATTERED
// SKY color only, no sun disc -- main() below adds that on top.
//
// This is the canonical copy of this function -- sky_cubemap.frag/
// shader.frag/shader_oit.frag each carry their own duplicate (this codebase
// has no shared-GLSL-include mechanism; sky_cubemap.frag already duplicated
// sky.frag's old gradient formula the same way). Edit all four together.
vec3 atmosphereColor(vec3 dir, vec3 sunDir, vec3 sunColor) {
    // Rayleigh coefficients at ~680/550/440nm, Mie coefficient/asymmetry --
    // real Earth wavelength ratios (this is what makes the sky read blue and
    // the horizon read orange: blue scatters out fastest over a long path),
    // magnitude rescaled for this engine's unitless world rather than SI
    // units it has no other use for.
    const vec3 betaR = vec3(5.8e-6, 13.5e-6, 33.1e-6) * 2.5e5;
    const float betaM = 21e-6 * 2.5e5;
    // Mie asymmetry -- forward-scattering aureole around the sun. Lowered
    // from the original 0.76: at cosTheta==1 (looking straight at the sun,
    // OR -- see hemisphericAmbient()'s dir=(0,1,0) call, shader.frag -- the
    // sun transiting near zenith) the phase function's peak scales like
    // 1/(1-g)^3, so 0.76 produced a ~2.4 peak vs. this value's ~1.1 -- the
    // reported "too bright" window during the day cycle was the sun passing
    // near zenith, spiking hemisphericAmbient's ambient term (every surface
    // in the scene reads that, not just the visible sky) via this same
    // shared function.
    const float g = 0.65;

    float cosTheta = dot(dir, sunDir);
    float phaseR = 3.0 / (16.0 * kPi) * (1.0 + cosTheta * cosTheta);
    float g2 = g * g;
    float phaseM = (1.0 - g2) / (4.0 * kPi * pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5));

    // Kasten-Young airmass: optical path length through the atmosphere
    // relative to straight up, as a function of zenith angle only -- unlike
    // a plain 1/cosTheta secant, this stays finite all the way to the
    // horizon instead of blowing up.
    float cosZenith = max(dir.y, -0.02);
    float zenithDeg = degrees(acos(clamp(cosZenith, -1.0, 1.0)));
    float airmass = 1.0 / (cosZenith + 0.50572 * pow(96.07995 - zenithDeg, -1.6364));

    vec3 extinction = exp(-(betaR + betaM) * airmass);
    vec3 inscatter = (betaR * phaseR + betaM * phaseM) * (1.0 - extinction) / max(betaR + betaM, 1e-6);
    return sunColor * inscatter;
}

void main() {
    // Reconstruct this pixel's world-space view ray from NDC + the inverse
    // camera matrices -- cheap here since (thanks to the depth mask above)
    // early-Z only ever lets this fragment shader actually run for genuine
    // background pixels, never for the whole screen.
    vec2 ndc = fragUV * 2.0 - 1.0;
    vec4 viewPos = inverse(ubo.proj) * vec4(ndc, 1.0, 1.0);
    viewPos /= viewPos.w;
    vec3 worldDir = normalize(mat3(inverse(ubo.view)) * viewPos.xyz);

    // lightDir points FROM the light TOWARD the scene, so the direction a
    // camera would look *at* the sun is its negation.
    vec3 sunDir = normalize(-ubo.lightDir);
    float sunDot = dot(worldDir, sunDir);

    // Tight bright core plus a soft halo around it -- two smoothstep rings
    // rather than a single hard-edged circle.
    float sunDisc = smoothstep(0.9995, 0.9998, sunDot);
    float sunGlow = smoothstep(0.995, 0.9993, sunDot) * 0.35;

    // Real single-scatter Rayleigh+Mie atmosphere for the day-sky half of
    // the day/night blend below -- see atmosphereColor's own comment.
    // ubo.lightColor already carries the correct sun/moon ramp + intensity
    // (updateUniformBuffer), so this naturally dims/warms as the active
    // body sets with no extra driving logic needed here.
    vec3 daySky = atmosphereColor(worldDir, sunDir, ubo.lightColor);

    // Deep night palette -- near-black with a faint cool tint, same
    // horizon-brighter gradient shape a plain sky/ground hemisphere gradient
    // would have, but far dimmer and cooler overall. Kept as its own
    // hand-authored palette (not scattering-driven) since real Rayleigh/Mie
    // scattering has no notion of "night sky" -- with no direct sun/moon,
    // there's essentially nothing to scatter.
    vec3 nightColorTop = vec3(0.01, 0.015, 0.03);
    vec3 nightColorHorizon = vec3(0.04, 0.05, 0.09);
    float horizonMix = clamp(worldDir.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 nightSky = mix(nightColorHorizon, nightColorTop, horizonMix);

    // How "lit" the sky should look right now -- derived from ubo.lightColor's
    // own magnitude, NOT sunDir's elevation: elevation alone can't
    // distinguish "sun at zenith" (noon) from "moon at zenith" (midnight),
    // since the sun/moon swap (updateUniformBuffer, VulkanRender.cpp) always
    // puts whichever body is currently active above the horizon -- both read
    // as "some body straight up." lightColor's magnitude has no such
    // ambiguity: it already reflects the correct sun/moon cross-fade (and
    // how far through its own ramp that transition is) with no separate
    // day/night signal needed. kSkyReferenceLuminance is a rough
    // "approximately the sun's own default peak brightness" constant --
    // this is a purely cosmetic blend (not something any real lighting math
    // reads), so an approximate reference is fine; a much brighter moon
    // would legitimately brighten the night sky too under this formula,
    // which is physically reasonable, not a bug.
    const float kSkyReferenceLuminance = 4.0;
    // Floored, not left to hit true 0 -- ubo.lightColor is deliberately
    // exactly (0,0,0) for one frame right at the sun/moon crossover (both
    // independent day/night ramps bottom out together there, by
    // construction, so direct lighting's hard direction-switch is
    // invisible). Without this floor the sky dome crashed to its darkest
    // (near-black) palette at that exact instant -- a real sky is still lit
    // by ambient scatter with no direct sun/moon, so it should read as dim
    // twilight, not a black flash. Must match VulkanRender.cpp's own
    // identical kMinSkyBrightnessFactor (updateUniformBuffer) so the sky
    // dome and the baked env cubemap's own brightness correction agree.
    const float kMinSkyBrightnessFactor = 0.04;
    float lightLuminance = dot(ubo.lightColor, vec3(0.2126, 0.7152, 0.0722));
    float skyBrightnessFactor = clamp(lightLuminance / kSkyReferenceLuminance, kMinSkyBrightnessFactor, 1.0);

    // No hand-authored twilight-tint overlay anymore -- real Rayleigh
    // scattering already reddens the horizon as the sun/moon's elevation
    // drops (the longer airmass path at low elevation scatters out more
    // blue than red, atmosphereColor's own airmass term), so daySky itself
    // already carries the warm sunset/sunrise color where the old hack used
    // to paint one on.
    vec3 skyColor = mix(nightSky, daySky, skyBrightnessFactor);

    // ubo.lightColor is already the sun's own brightness (LightingUI's Sun
    // Intensity slider, see updateUniformBuffer) -- reusing it directly
    // means the visible disc's brightness always matches what's actually
    // lighting the scene, with no separate constant to keep in sync. This
    // can be well above 1.0 (HDR), same as everywhere else lightColor is
    // used -- the existing tonemap pass (tonemap.frag) handles compressing
    // it to displayable range same as any other bright fragment.
    vec3 color = skyColor + ubo.lightColor * (sunDisc + sunGlow);
    outColor = vec4(color, 1.0);
}
