#version 460
#extension GL_EXT_ray_query : require
#extension GL_GOOGLE_include_directive : require

// ============================================================================
// rt_shadow_trace.frag -- Phase 5 (NRD SIGMA_SHADOW). Deferred replacement
// for rt_shadows.glsl's old inline-in-shader.frag hard shadow ray: NRD needs
// the raw noisy signal written to a texture BEFORE denoising, then shader.frag
// reads back the DENOISED result -- it can no longer trace-and-composite in
// one step the way the pre-Phase-5 code did. Runs as its own fullscreen pass
// right after the depth pre-pass/SSAO (recordCommandBuffer), once the G-buffer
// (depth, packedGBufferImage's world normal) it needs is ready, and before
// pass 1 (shader.frag) ever runs.
//
// Output: IN_PENUMBRA for SIGMA_SHADOW, packed exactly like NRD.hlsli's
// SIGMA_FrontEnd_PackPenumbra (directional-light overload) -- ported to GLSL
// below since NRD's own packing helpers are HLSL-only.
// ============================================================================

layout(location = 0) in vec2 fragUV;
layout(location = 0) out float outPenumbra;

layout(set = 0, binding = 0) uniform accelerationStructureEXT rtTLAS;
layout(set = 0, binding = 1) uniform sampler2D depthBuffer;
// World-space oct-encoded normal + roughness + materialID -- see
// packedGBufferImage's own comment, VulkanApp.h. Only .xy (the oct-encoded
// normal) is used here.
layout(set = 0, binding = 2) uniform sampler2D packedNormalRoughness;

layout(push_constant) uniform PushConstants {
    mat4 invViewProj;
    // xyz = normalized direction TOWARD the sun, w = tan(sun angular
    // radius) -- reuses GraphicsUI's existing PCSS "Light Size" slider
    // (ubo.pcssLightSize) for the latter, the closest existing "how soft is
    // the sun" concept in this engine (see its own comment, VulkanTypes.h),
    // rather than adding a second, redundant softness control.
    vec4 lightDirAndTanAngle;
} pc;

#include "rt_shadows.glsl"

// Ported from NRD.hlsli's _NRD_DecodeUnitVector( p, false, true ) --
// unsigned oct decoding, bNormalize=true (matches
// NRD_FrontEnd_UnpackNormalAndRoughness's own call).
vec3 nrdDecodeUnitVector(vec2 p) {
    p = p * 2.0 - 1.0;
    vec3 n = vec3(p.xy, 1.0 - abs(p.x) - abs(p.y));
    float t = clamp(-n.z, 0.0, 1.0);
    n.xy -= t * (step(0.0, n.xy) * 2.0 - 1.0);
    return normalize(n);
}

// Ported from NRD.hlsli's SIGMA_FrontEnd_PackPenumbra (directional/infinite
// light overload).
float sigmaPackPenumbra(float distanceToOccluder, float tanOfLightAngularRadius) {
    const float kNrdFp16Max = 65504.0;
    float penumbraSize = distanceToOccluder * tanOfLightAngularRadius;
    float penumbraRadius = penumbraSize * 0.5;
    return distanceToOccluder >= kNrdFp16Max ? kNrdFp16Max : min(penumbraRadius, 32768.0);
}

void main() {
    float depth = texture(depthBuffer, fragUV).r;
    if (depth >= 1.0) {
        // Sky/background -- nothing to shade, nothing to shadow. NRD_FP16_MAX
        // packs as "fully lit" through sigmaPackPenumbra the same as an
        // actual unoccluded ray would, so this reads as lit rather than a
        // discontinuity SIGMA has to guess about.
        outPenumbra = sigmaPackPenumbra(65504.0, pc.lightDirAndTanAngle.w);
        return;
    }

    vec4 ndc = vec4(fragUV * 2.0 - 1.0, depth, 1.0);
    vec4 worldPosH = pc.invViewProj * ndc;
    vec3 worldPos = worldPosH.xyz / worldPosH.w;

    vec3 worldNormal = nrdDecodeUnitVector(texture(packedNormalRoughness, fragUV).xy);

    float distanceToOccluder = rtSunShadowDistance(worldPos, worldNormal, pc.lightDirAndTanAngle.xyz);
    outPenumbra = sigmaPackPenumbra(distanceToOccluder, pc.lightDirAndTanAngle.w);
}
