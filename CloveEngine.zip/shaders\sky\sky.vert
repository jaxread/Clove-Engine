#version 450

// Same "fullscreen triangle from just gl_VertexIndex" trick as
// oit_composite.vert (see its comment) -- no vertex/index buffer bound
// (VulkanPipeline.cpp's createSkyPipeline gives this an empty
// VkPipelineVertexInputStateCreateInfo). Unlike that post-process pass,
// gl_Position.z is pinned to 1.0 (== w, so NDC z ends up exactly 1.0, the
// far plane) instead of 0.0 -- see sky.frag's comment for why: this pass
// only ever shows through where the depth buffer still holds the far-plane
// clear value the depth pre-pass wrote, i.e. background pixels nothing
// opaque covered.
layout(location = 0) out vec2 fragUV;

void main() {
    vec2 uv = vec2((gl_VertexIndex << 1) & 2, gl_VertexIndex & 2);
    fragUV = uv;
    gl_Position = vec4(uv * 2.0 - 1.0, 1.0, 1.0);
}
