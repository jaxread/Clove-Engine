#version 450

// One axis of a separable 9-tap Gaussian blur -- two draws (direction =
// (1,0) then (0,1), see BlurPushConstants' comment, VulkanTypes.h) make one
// full blur pass for the standalone Blur effect (source: hdrResolveImage
// directly) -- see createPostProcessPipelines' comment (VulkanPipeline.cpp)
// for the full pass sequence. Vertex stage is oit_composite.vert, same reuse
// as tonemap.frag.
//
// Also the SSAO blur pass (ssaoRawImage -> ssaoPingImage -> ssaoBlurredImage,
// same pipeline reused rather than a dedicated one) -- ssao.frag's outColor
// packs RGB=bent normal, A=AO, so this has to blur all 4 channels rather
// than hardcoding alpha to 1 the way it used to when only RGB ever carried
// real data. Harmless for the standalone Blur effect above: nothing
// downstream (tonemap.frag) ever reads hdrResolveImage/blurredSceneImage's
// alpha channel.
layout(location = 0) in vec2 fragUV;

layout(location = 0) out vec4 outColor;

// Whichever source this draw is reading -- postProcessHdrDescriptorSet or
// postProcessPingDescriptorSet (VulkanApp.h), picked per-draw by
// recordCommandBuffer, not by anything in this shader.
layout(binding = 0) uniform sampler2D source;

layout(push_constant) uniform PushConstants {
    vec2 direction;
    float spread;
} pc;

// Standard discretized-Gaussian 9-tap weights (sigma ~2, normalized to sum
// to 1) -- a well-known, well-tested set rather than something derived here;
// good enough for a live-tunable blur where `spread` (below) already gives
// continuous radius control on top of this fixed shape.
const float kWeights[5] = float[](0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216);

void main() {
    vec2 texelStep = pc.direction * pc.spread;
    vec4 result = texture(source, fragUV) * kWeights[0];
    for (int i = 1; i < 5; ++i) {
        vec2 offset = texelStep * float(i);
        result += texture(source, fragUV + offset) * kWeights[i];
        result += texture(source, fragUV - offset) * kWeights[i];
    }
    outColor = result;
}
