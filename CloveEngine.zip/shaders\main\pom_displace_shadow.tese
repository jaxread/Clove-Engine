#version 450
#extension GL_EXT_nonuniform_qualifier : enable

// Shadow-caster variant of pom_displace.tese -- same barycentric
// interpolation and heightmap displacement (see that shader's own comment
// for the full "why"), but projects the displaced position through the
// directional light's lightViewProj[cascadeIndex] instead of the camera's
// view/proj, and writes no fragment-stage varyings at all (this pipeline --
// createTessellatedShadowPipeline, VulkanPipeline.cpp -- has no fragment
// stage, same as the ordinary shadow pipeline/shadow.vert it sits alongside).
// Paired with shader.vert (reused unchanged, exactly like the main
// tessellated pipeline) and pom_displace.tesc (also reused unchanged --
// its distance-from-camera tessellation level still makes sense here: a
// heightmapped caster close to the camera deserves a well-tessellated
// shadow, not just a well-tessellated visible surface) as this pipeline's
// control-point/control stages.
layout(triangles, equal_spacing, ccw) in;

// Full field list, matching shadow.vert's own identical declaration of this
// binding exactly -- lightViewProj isn't a prefix field (it comes after
// camPos/lightDir/lightColor/ambientColorIntensity/forceMaskForBlend), and a
// uniform block's layout is positional, so every preceding field has to be
// declared in order to reach it at the right offset.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;
    vec3 lightColor;
    vec4 ambientColorIntensity;
    int forceMaskForBlend;
    mat4 lightViewProj[4]; // literal 4 -- must match kNumShadowCascades (VulkanTypes.h)
} ubo;

// Same cascade-index push constant shadow.vert reads, just also readable
// from this stage now -- see cascadeIndexPushConstant's stageFlags,
// createGraphicsPipeline (VulkanPipeline.cpp), for why
// TESSELLATION_EVALUATION_BIT had to be added there alongside VERTEX_BIT.
layout(push_constant) uniform ShadowPushConstant {
    int cascadeIndex;
} pc;

// Identical full mirror of GpuMaterial to pom_displace.tese's -- same
// "array stride depends on the full declared size" reasoning, see its
// comment.
struct Material {
    vec4 baseColorFactor;
    vec4 emissiveFactor;
    int baseColorTexture;
    int metallicRoughnessTexture;
    int normalTexture;
    int occlusionTexture;
    int emissiveTexture;
    float metallicFactor;
    float roughnessFactor;
    float normalScale;
    float occlusionStrength;
    float alphaCutoff;
    int alphaMode;
    int doubleSided;
    int texCoordSets;
    int heightTexture;
    float heightScale;
    int _pad0;
};

layout(std430, binding = 1) readonly buffer MaterialBuffer {
    Material materials[];
} materialBuffer;

layout(binding = 4) uniform sampler2D bindlessTextures[];

layout(location = 0) in vec3 inWorldPos[];
layout(location = 1) in vec3 inNormal[];
layout(location = 2) in vec2 inUV[];
layout(location = 7) patch in int patchMaterialIndex;

void main() {
    vec3 bary = gl_TessCoord;
    vec3 worldPos = inWorldPos[0] * bary.x + inWorldPos[1] * bary.y + inWorldPos[2] * bary.z;
    vec3 normal = normalize(inNormal[0] * bary.x + inNormal[1] * bary.y + inNormal[2] * bary.z);
    vec2 uv = inUV[0] * bary.x + inUV[1] * bary.y + inUV[2] * bary.z;

    Material mat = materialBuffer.materials[patchMaterialIndex];
    // Same height convention as pom_displace.tese -- see its comment.
    if (mat.heightTexture >= 0) {
        float h = textureLod(bindlessTextures[nonuniformEXT(mat.heightTexture)], uv, 0.0).r;
        worldPos += normal * (h - 1.0) * mat.heightScale;
    }

    gl_Position = ubo.lightViewProj[pc.cascadeIndex] * vec4(worldPos, 1.0);
}
