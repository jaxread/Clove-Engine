#version 460
#extension GL_EXT_ray_query : require

// ============================================================================
// rt_debug.frag -- Phase 1 validation: trace camera PRIMARY rays through the
// TLAS and visualize hits. Depends only on the TLAS + a camera push constant,
// so it verifies BLAS/TLAS transforms and buffer offsets in isolation -- with
// zero dependence on shader.frag, the UBO, or the shadow code.
//
// Read: if the containers / road / barriers / trees appear as distinct colored
// shapes in the right screen positions, your acceleration structures are
// correct and you can move on to RT shadows. If geometry is missing, shifted,
// or scrambled, the bug is in Phase 1 (BLAS ranges, instance transforms, or
// buffer device addresses) -- not in the shadow code.
//
// Wiring: see RT_DEBUG_NOTES.md. Bind the TLAS at set 0 binding 0 for THIS
// pipeline, push the camera matrices, draw 3 vertices to the current color
// target when the "TLAS debug" toggle is on.
// ============================================================================

layout(location = 0) in vec2 inUV;
layout(location = 0) out vec4 outColor;

layout(set = 0, binding = 0) uniform accelerationStructureEXT rtTLAS;

layout(push_constant) uniform CameraPC {
    mat4 invView;   // inverse(view)
    mat4 invProj;   // inverse(proj)
    vec4 camPos;    // xyz = camera world position
} cam;

// Hash an instance index to a distinct color so different objects are readable.
vec3 hashColor(uint i) {
    uint h = i * 2654435761u;
    return vec3(float((h >> 16) & 0xFFu),
                float((h >> 8)  & 0xFFu),
                float( h        & 0xFFu)) / 255.0;
}

void main() {
    // Reconstruct a world-space primary ray from NDC.
    // If the image comes out vertically flipped, negate ndc.y (Vulkan clip-Y
    // convention vs. your projection's Y flip).
    vec2 ndc = inUV * 2.0 - 1.0;

    vec4 viewPos = cam.invProj * vec4(ndc, 1.0, 1.0);
    viewPos /= viewPos.w;
    vec3 dirView  = normalize(viewPos.xyz);
    vec3 dirWorld = normalize(mat3(cam.invView) * dirView);
    vec3 origin   = cam.camPos.xyz;

    rayQueryEXT rq;
    rayQueryInitializeEXT(rq, rtTLAS, gl_RayFlagsOpaqueEXT, 0xFF,
                          origin, 0.001, dirWorld, 100000.0);
    rayQueryProceedEXT(rq);

    if (rayQueryGetIntersectionTypeEXT(rq, true) ==
        gl_RayQueryCommittedIntersectionNoneEXT) {
        // Miss -> dark background so hits stand out.
        outColor = vec4(0.03, 0.04, 0.06, 1.0);
        return;
    }

    // Hit: tint by instance id, darken with distance for a depth cue.
    uint  instId = uint(rayQueryGetIntersectionInstanceCustomIndexEXT(rq, true));
    float t      = rayQueryGetIntersectionTEXT(rq, true);
    float depthCue = clamp(1.0 - t * 0.01, 0.15, 1.0); // tune 0.01 to your scene scale

    outColor = vec4(hashColor(instId) * depthCue, 1.0);
}
