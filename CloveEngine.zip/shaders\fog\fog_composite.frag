#version 450

// Composites fog_froxel.comp's already-integrated 3D texture onto the scene
// -- one texture3D sample per pixel (at that pixel's own depth-mapped Z
// slice), not a per-pixel raymarch, since the compute pass already walked
// and accumulated the whole ray once -- PLUS a second, cheap analytic
// "Exponential Height Fog" layer for everything past the froxel grid's own
// far plane (background/distant atmosphere, no shadow sampling, unbounded
// distance -- see heightFogAlpha() below). Vertex stage is oit_composite.vert,
// same fullscreen-triangle reuse as tonemap.frag/blur.frag/bloom_threshold.frag.
//
// Writes directly into hdrResolveImage via LOAD_OP_LOAD + blend state
// (srcColor*ONE + dstColor*SRC_ALPHA, createFogPipelines() -- VulkanPipeline.cpp)
// rather than sampling the existing scene color in this shader and blending
// it by hand -- a pass can't read and write the same color attachment at
// once, and fixed-function blending is exactly the premultiplied-alpha
// "over" operator this needs anyway (outAlpha here IS the combined
// transmittance already computed below, so dst_new = inscatteredLight +
// dst_old * transmittance, precisely the standard volumetric composite
// formula).
//
// Temporal reprojection (outHistory below) smooths out flicker from the
// froxel grid's own coarse spatial resolution aliasing under camera motion
// -- most visible as "swimming" god-ray/canopy-gap edges, since those are
// exactly the kind of high-frequency detail a grid far coarser than screen
// resolution (e.g. 240x135 froxel columns vs a 1920-wide screen) aliases
// hardest. Deliberately reprojects and blends the FINAL 2D composited result
// here, not fogAccumImage's own 3D per-voxel data: that 3D buffer stores
// light ALREADY ACCUMULATED from the camera out to each depth, which is
// inherently camera-position-dependent (the same voxel's "accumulated so
// far" value differs by definition once the camera has moved), so blending
// it across a moved camera would double-count/miscount extinction along the
// ray. The 2D composited result has no such issue -- this is the same
// "reproject and blend the final 2D image" approach real-time TAA already
// uses for screen-space aliasing generally (and matches how published
// real-time volumetric fog implementations, e.g. Frostbite's, actually do
// this rather than reprojecting the 3D volume itself). Height fog is
// deliberately left OUT of the reprojected history (see its own comment
// below) -- only the froxel result is temporally blended.

layout(location = 0) in vec2 fragUV;
layout(location = 0) out vec4 outColor;
// Same blended result as outColor, but written into fogHistoryImages'
// CURRENT-frame slot (VulkanApp.h) with a plain opaque overwrite (see
// createFogPipelines()'s own comment, VulkanPipeline.cpp, for the
// per-attachment blend state split) -- what NEXT frame's own reprojection
// reads as "last frame's result".
layout(location = 1) out vec4 outHistory;

layout(binding = 0) uniform sampler3D fogAccumImage;
// Same depth source SSAO already reads (depthResolveImage/depthImage
// depending on MSAA -- see recordCommandBuffer's own comment for why),
// re-bound here under this pass's own descriptor set.
layout(binding = 1) uniform sampler2D depthBuffer;
// Last real frame's own blended composite (outHistory above), read from
// whichever of fogHistoryImages ISN'T this frame's write target -- see
// VulkanApp::fogHistoryIndex's own comment for the per-frame ping-pong.
layout(binding = 2) uniform sampler2D fogHistoryImage;
// Cheapest possible UBO prefix (view/proj only) -- added purely so this
// shader can reconstruct world/previous-view-space positions for
// reprojection (and the height fog term below) without needing a second
// mat4 in the already-tight push-constant block (see FogCompositePushConstants'
// own comment, VulkanTypes.h, for why `proj` lives here instead of staying a
// push constant). Points at the SAME per-frame uniformBuffers[i] the main
// descriptor set already uses -- just a smaller GLSL-side mirror, exactly
// like fog_froxel.comp's own binding 0.
layout(binding = 3) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
} ubo;

layout(push_constant) uniform PushConstants {
    mat4 prevView;
    float nearPlane;
    float farPlane;
    int froxelDepth;
    float historyBlend;
    // --- Exponential Height Fog (background layer, see heightFogAlpha()) ---
    float heightFogDensity;
    float heightFogFalloff;
    float heightFogBaseHeight;
    vec3 heightFogColor;
} pc;

// Exact inverse of fog_froxel.comp's sliceToViewDepth() -- both must stay in
// sync (same nearPlane/farPlane/froxelDepth each frame, see
// recordCommandBuffer) or a pixel would sample a different slice than the
// one its own real depth actually falls into.
float depthToSlice(float viewDepth, float sliceCount, float nearZ, float farZ) {
    float t = log(max(viewDepth, nearZ) / nearZ) / log(farZ / nearZ);
    return clamp(t, 0.0, 1.0) * sliceCount;
}

// Closed-form UE4-style "Exponential Height Fog" optical depth, integrated
// along the view ray from distance s0 to t (NOT from the camera -- s0 is
// pc.farPlane, the froxel grid's own far distance, so this layer only ever
// covers what's PAST the froxel's range instead of double-fogging it).
// camY/rd.y drive how density falls off with world-space height, same
// formula (and the same falloff*rd.y ~ 0 "horizontal ray" singularity, an
// L'Hopital limit) any UE4-style height fog implementation needs.
float heightFogAlpha(float camY, vec3 rd, float s0, float t) {
    if (t <= s0) return 0.0;
    float k = pc.heightFogFalloff * rd.y;
    float base = pc.heightFogDensity * exp(-clamp(pc.heightFogFalloff * (camY - pc.heightFogBaseHeight), -80.0, 80.0));
    float integral;
    if (abs(k) > 1e-4) {
        integral = base * (exp(-k * s0) - exp(-k * t)) / k;
    } else {
        integral = base * exp(-k * s0) * (t - s0);
    }
    return 1.0 - exp(-clamp(integral, 0.0, 80.0));
}

void main() {
    float rawDepth = texture(depthBuffer, fragUV).r;
    // Sky/background -- still fog it using the far slice's accumulated
    // result (a light shaft crossing in front of open sky should still
    // show), rather than skipping entirely. Height fog below separately
    // treats this case as "an effectively infinite travel distance" (1e5)
    // instead of trusting the huge-but-finite view-space Z a depth this
    // close to 1.0 would otherwise reconstruct.
    bool isSky = rawDepth >= 1.0;
    float depth = isSky ? (1.0 - 1e-5) : rawDepth;

    // Same depth reconstruction trick as ssao.frag: NDC -> view-space Z via
    // inverse(proj), the standard trick every G-buffer-less-position
    // technique in this codebase already uses.
    mat4 invProj = inverse(ubo.proj);
    vec4 ndc = vec4(fragUV * 2.0 - 1.0, depth, 1.0);
    vec4 viewPosH = invProj * ndc;
    vec3 viewPos = viewPosH.xyz / viewPosH.w;
    float viewDepth = -viewPos.z;

    float slice = depthToSlice(viewDepth, float(pc.froxelDepth), pc.nearPlane, pc.farPlane);
    vec3 uvw = vec3(fragUV, (slice + 0.5) / float(pc.froxelDepth));
    vec4 fog = texture(fogAccumImage, uvw);

    // Reproject this fragment's own view-space position (already computed
    // above) into last frame's screen space: world-space is the common
    // frame both this frame's and last frame's view matrices share, so
    // going THIS view -> world -> PREVIOUS view -> previous clip is what
    // actually finds "where was this same point on screen last frame",
    // unlike naively reusing this frame's own screen UV (which is only
    // correct if the camera never moved).
    mat4 invView = inverse(ubo.view);
    vec4 worldPosH = invView * vec4(viewPos, 1.0);
    vec3 worldPos = worldPosH.xyz / worldPosH.w;
    vec4 prevViewPosH = pc.prevView * worldPosH;
    vec4 prevClip = ubo.proj * prevViewPosH;
    vec3 prevNdc = prevClip.xyz / prevClip.w;
    vec2 prevUV = prevNdc.xy * 0.5 + 0.5;

    // Valid only if the reprojected point actually lands on screen and was
    // in front of the previous camera (prevClip.w > 0) -- otherwise (a point
    // that just came into view, or the very first frame with no real history
    // yet) there's nothing sensible to blend with, so this frame's own fresh
    // result stands alone.
    bool historyValid = prevClip.w > 0.0 &&
        prevUV.x >= 0.0 && prevUV.x <= 1.0 &&
        prevUV.y >= 0.0 && prevUV.y <= 1.0;

    vec4 blended = fog;
    if (historyValid) {
        vec4 history = texture(fogHistoryImage, prevUV);
        blended = mix(fog, history, pc.historyBlend);
    }

    // outHistory carries only the froxel's own temporally-blended result --
    // see this file's own top comment for why height fog (cheap,
    // deterministic per pixel, no reprojection benefit) deliberately stays
    // out of the reprojected signal.
    outHistory = blended;

    // Height fog: camera position falls straight out of invView's own
    // translation column (view-space origin IS the camera), and view-space
    // distance already equals world-space distance for a rigid transform --
    // both reused here rather than recomputed.
    vec3 camPos = invView[3].xyz;
    vec3 rayDir = normalize(worldPos - camPos);
    float travelDistance = isSky ? 1e5 : length(viewPos);
    float heightAlpha = heightFogAlpha(camPos.y, rayDir, pc.farPlane, travelDistance);

    // Combine BEFORE the hardware blend -- this shader never reads
    // hdrResolveImage directly (LOAD_OP_LOAD only feeds the blend equation),
    // so both fog layers have to collapse into one (rgb, a) pair here. Height
    // fog composites as an "over" layer BEHIND the froxel's own result (folded
    // into what survives the froxel's own transmittance), matching it being
    // the farther of the two layers.
    vec3 combinedInscatter = blended.rgb + blended.a * pc.heightFogColor * heightAlpha;
    float combinedTransmittance = blended.a * (1.0 - heightAlpha);

    outColor = vec4(combinedInscatter, combinedTransmittance);
}
