#version 450

// Depth (+ view-space normal) pre-pass from the main camera's point of view,
// run before pass 1 in recordCommandBuffer (VulkanRender.cpp) so that pass
// can draw with depth writes off and an EQUAL compare instead of paying its
// full PBR shading cost for fragments later found to be overdrawn. Shares
// InstanceBuffer/UBO with shader.vert (same descriptor set, same
// pipelineLayout -- see createDepthPrepassPipeline, VulkanPipeline.cpp) but
// only declares the prefix of UniformBufferObject this stage actually needs
// (view/proj), and only outputs the handful of varyings depth_prepass.frag
// needs to alpha-test MASK/forced-MASK materials
// (fragUV/fragUV2/fragColor/fragMaterialIndex) plus, now, the view-space
// normal SSAO samples afterward (recordCommandBuffer's SSAO pass) -- no
// tangent/worldPos/lightSpacePos, none of which matter for either job.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
} ubo;

// Identical to shader.vert's InstanceData/InstanceBuffer -- see its comment
// there for why the full field list (not just model) has to be repeated even
// though this stage only reads .model: an SSBO array's element stride is
// derived from this struct's own declared layout, so a shorter declaration
// would make instances[] index with the wrong stride.
struct InstanceData {
    mat4 model;
    vec4 normalMatrixCol0;
    vec4 normalMatrixCol1;
    vec4 normalMatrixCol2;
    int materialIndex;
    int pad0;
    int pad1;
    int pad2;
};

layout(std430, binding = 3) readonly buffer InstanceBuffer {
    InstanceData instances[];
} instanceBuffer;

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec4 inNormal;
layout(location = 2) in vec2 inUV;
// Now used (Phase 2 G-buffer normal mapping) -- see fragViewTangent below.
layout(location = 3) in vec4 inTangent;
layout(location = 4) in vec4 inColor;
layout(location = 5) in vec2 inUV2;

layout(location = 2) out vec2 fragUV;
layout(location = 4) flat out int fragMaterialIndex;
layout(location = 5) out vec4 fragColor;
layout(location = 6) out vec2 fragUV2;
// View-space geometric normal -- SSAO's own input (see SsaoPushConstants'
// comment, VulkanTypes.h) and, as of Phase 2, also the basis
// depth_prepass.frag builds its normal-mapped G-buffer normal from.
layout(location = 7) out vec3 fragViewNormal;
// Linear view-space depth (camera-space Z, negated so it's a positive
// distance-from-camera value -- same sign convention as ssao.frag's own
// fragDist). Piggybacks on normalImage's alpha channel (depth_prepass.frag
// writes it into outNormal.w).
layout(location = 8) out float fragViewPosZ;
// View-space tangent (xyz) + handedness (w, untouched by the view rotation).
// Rotated into view space the same way fragViewNormal is -- mat3(ubo.view)
// is a pure rotation (no scale), so it preserves the orthogonality between
// tangent and normal that a TBN basis needs, same reasoning as
// fragViewNormal's own comment on world->view normal transform.
layout(location = 9) out vec4 fragViewTangent;

void main() {
    InstanceData inst = instanceBuffer.instances[gl_InstanceIndex];
    vec4 viewPos = ubo.view * (inst.model * vec4(inPosition, 1.0));
    gl_Position = ubo.proj * viewPos;
    fragViewPosZ = -viewPos.z;

    fragUV = inUV;
    fragUV2 = inUV2;
    fragMaterialIndex = inst.materialIndex;
    fragColor = inColor;

    // World normal via the instance's precomputed inverse-transpose (handles
    // non-uniform scale correctly, same reasoning as shader.vert's own
    // normal transform), then world -> view via just the view matrix's
    // upper 3x3 -- safe without its own inverse-transpose since the camera
    // view matrix is rigid (rotation + translation only, no scale).
    mat3 normalMatrix = mat3(inst.normalMatrixCol0.xyz, inst.normalMatrixCol1.xyz, inst.normalMatrixCol2.xyz);
    vec3 worldNormal = normalize(normalMatrix * inNormal.xyz);
    fragViewNormal = normalize(mat3(ubo.view) * worldNormal);

    // Same model-matrix (not inverse-transpose) transform shader.vert uses
    // for its own fragTangent -- a tangent is a surface direction, not a
    // normal, so it doesn't need the inverse-transpose treatment.
    vec3 worldTangent = normalize(mat3(inst.model) * inTangent.xyz);
    fragViewTangent = vec4(normalize(mat3(ubo.view) * worldTangent), inTangent.w);
}
