#version 450
#extension GL_EXT_nonuniform_qualifier : enable

// Weighted-blended order-independent transparency (McGuire & Bavoil 2013)
// accumulation pass for BLEND-mode materials. This is a deliberate near-
// duplicate of shader.frag's PBR shading rather than a shared code path:
// it writes two color outputs (accum + reveal), and a fragment shader
// output location without a matching pipeline color attachment is a
// Vulkan validation error -- so sharing one module between this
// (2-attachment) pipeline and the single-attachment graphicsPipeline
// isn't an option. Only ever bound for instances whose
// material is alphaMode == BLEND and not forced to MASK (see
// recordCommandBuffer, VulkanRender.cpp), so unlike shader.frag this
// doesn't need to branch on alphaMode at all -- it's always the BLEND
// case.
//
// No sorting, no back-to-front draw order requirement: every transparent
// fragment just accumulates into these two full-screen buffers in
// whatever order the GPU happens to rasterize them, and
// oit_composite.frag resolves the result afterward. That's what actually
// fixes the "blend material sorted wrong / disappears" problem this file
// exists for -- see the recordCommandBuffer comment for the composite math.

layout(location = 0) in vec3 fragWorldPos;
layout(location = 1) in vec3 fragNormal;
layout(location = 2) in vec2 fragUV;
layout(location = 3) in vec4 fragTangent;
layout(location = 4) flat in int fragMaterialIndex;
layout(location = 5) in vec4 fragColor;
// glTF's TEXCOORD_1 -- see shader.frag's fragUV2/texCoordFor comments.
layout(location = 6) in vec2 fragUV2;

// Premultiplied, weighted color+alpha (see main() below) -- additive
// blended (VulkanPipeline.cpp's createOitPipelines).
layout(location = 0) out vec4 outAccum;
// Raw (unweighted) alpha -- multiplicatively blended as dst *= (1 - src),
// so this ends up holding the running product of (1 - alpha) across every
// transparent fragment drawn at this pixel: "how much of the background
// still shows through".
layout(location = 1) out float outReveal;

// lightViewProj/cascadeSplitDepths mirror shader.frag's UBO exactly (see its
// comments) -- this pipeline needs both for its own cascade selection below.
// shadowNormalOffsetWorldSize has to still be declared (even though this
// shader, like before cascades existed, applies no normal-offset bias --
// see sampleCascade()'s comment) purely to keep shadowDebugVisualizeCascades
// after it at the right positional offset; a uniform block's layout is
// positional, so a field can only be skipped by not declaring anything
// *after* it, not by leaving a gap in the middle.
layout(binding = 0) uniform UniformBufferObject {
    mat4 view;
    mat4 proj;
    vec3 camPos;
    vec3 lightDir;
    vec3 lightColor;
    vec4 ambientColorIntensity;
    int forceMaskForBlend;
    mat4 lightViewProj[4]; // literal 4 -- must match kNumShadowCascades (VulkanTypes.h)
    vec4 cascadeSplitDepths;
    vec4 shadowNormalOffsetWorldSize; // unused here -- see comment above
    int shadowDebugVisualizeCascades;
    // Identical to shader.frag's ssaoEnabled -- see its comment there.
    int ssaoEnabled;
    // Identical to shader.frag's tail of the same name -- see
    // UniformBufferObject's own comment (VulkanTypes.h) for why these are
    // appended after the original last member rather than inserted earlier.
    float minAmbientFloor;
    // Identical to shader.frag's tail of the same name -- see its comments
    // there.
    float roughnessFloor;
    int geometricSpecularAAEnabled;
    // Identical to shader.frag's tail of the same name -- see its comments
    // there and UniformBufferObject::envBrightnessCorrection's own comment,
    // VulkanTypes.h.
    float envBrightnessCorrection;
    // Identical to shader.frag's PCSS tail -- see its comments there and
    // UniformBufferObject's own comments (VulkanTypes.h).
    int pcssEnabled;
    float pcssLightSize;
    float pcssQuality;
    // Identical to shader.frag's tail of the same name -- see its comments
    // there.
    float foliageTranslucencyStrength;
    // Identical to shader.frag's clustered-lighting tail -- see its comments
    // there and UniformBufferObject's own comments (VulkanTypes.h).
    int lightCount;
    ivec4 clusterGridDim;
    vec2 clusterDepthSliceScaleBias;
    vec2 clusterScreenTileSize;
} ubo;

layout(binding = 2) uniform sampler2DArrayShadow shadowMap;
layout(binding = 4) uniform sampler2D bindlessTextures[];
// Identical to shader.frag's envMap binding -- see its comment there.
layout(set = 1, binding = 0) uniform samplerCube envMap;
// Identical to shader.frag's ssaoTexture binding -- see its comment there.
layout(set = 1, binding = 1) uniform sampler2D ssaoTexture;
// Identical to shader.frag's shadowMapRaw binding -- see its comment there.
layout(set = 1, binding = 2) uniform sampler2DArray shadowMapRaw;
// Identical to shader.frag's clustered-lighting SSBOs (set 2) -- see their
// comments there.
struct Light {
    vec4 posRange;
    vec4 colorIntensity;
    vec4 coneDir;
    vec4 coneAngles;
};
layout(std430, set = 2, binding = 0) readonly buffer LightsBuffer {
    Light lights[];
};
struct ClusterLightGridEntry {
    uint offset;
    uint count;
};
layout(std430, set = 2, binding = 1) readonly buffer ClusterLightIndicesBuffer {
    uint clusterLightIndices[];
};
layout(std430, set = 2, binding = 2) readonly buffer ClusterLightGridBuffer {
    ClusterLightGridEntry clusterLightGrid[];
};

// Identical to shader.frag's clusterIndexForFragment() -- see its comment
// there.
uint clusterIndexForFragment(vec2 fragCoord, float fragViewDepth) {
    ivec3 gridDim = ubo.clusterGridDim.xyz;
    ivec2 tileXY = ivec2(fragCoord / ubo.clusterScreenTileSize);
    tileXY = clamp(tileXY, ivec2(0), gridDim.xy - ivec2(1));
    int slice = int(log2(max(fragViewDepth, 0.0001)) * ubo.clusterDepthSliceScaleBias.x - ubo.clusterDepthSliceScaleBias.y);
    slice = clamp(slice, 0, gridDim.z - 1);
    return uint(tileXY.x + gridDim.x * (tileXY.y + gridDim.y * slice));
}

struct Material {
    vec4 baseColorFactor;
    vec4 emissiveFactor;
    int baseColorTexture;
    int metallicRoughnessTexture;
    int normalTexture;
    int occlusionTexture;
    int emissiveTexture;
    float metallicFactor;
    float roughnessFactor;
    float normalScale;
    float occlusionStrength;
    float alphaCutoff;
    int alphaMode;
    int doubleSided;
    // Bit N set means that texture type samples fragUV2 instead of fragUV
    // -- see shader.frag's Material::texCoordSets comment for the bit-order
    // convention.
    int texCoordSets;
    int _pad0;
    int _pad1;
    int _pad2;
};

layout(std430, binding = 1) readonly buffer MaterialBuffer {
    Material materials[];
} materialBuffer;

const float kZeroAlphaEpsilon = 0.02;
const float kPi = 3.14159265359;

// Identical to shader.frag's texCoordFor() -- see its comment there.
vec2 texCoordFor(int texCoordSets, int bit) {
    return ((texCoordSets & bit) != 0) ? fragUV2 : fragUV;
}

// Identical to shader.frag's frontFacingSign() -- see its comment there.
// BLEND materials go through this pipeline instead of the opaque/mask one,
// but recordCommandBuffer sets the same dynamic double-sided cull mode for
// both, so the same backface normal/tangent-handedness flip is needed here.
float frontFacingSign() {
    return gl_FrontFacing ? 1.0 : -1.0;
}

// Same specialization-constant-driven shadow map size as shader.frag -- see
// its comment there.
layout(constant_id = 0) const float kShadowMapSize = 2048.0;
// Identical to shader.frag's kMaxEnvLod -- see its comment there.
layout(constant_id = 1) const float kMaxEnvLod = 6.0;

// Identical to shader.frag's envBRDFApprox()/atmosphereColor()/
// hemisphericAmbient()/sampleEnvironment() -- see their comments there.
vec2 envBRDFApprox(float NdotV, float roughness) {
    const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
    const vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
    vec4 r = roughness * c0 + c1;
    float a004 = min(r.x * r.x, exp2(-9.28 * NdotV)) * r.x + r.y;
    return vec2(-1.04, 1.04) * a004 + r.zw;
}

vec3 atmosphereColor(vec3 dir, vec3 sunDir, vec3 sunColor) {
    const vec3 betaR = vec3(5.8e-6, 13.5e-6, 33.1e-6) * 2.5e5;
    const float betaM = 21e-6 * 2.5e5;
    // Mie asymmetry -- lowered from 0.76, see shader.frag's identical
    // constant for why (the day-cycle "too bright" fix).
    const float g = 0.65;

    float cosTheta = dot(dir, sunDir);
    float phaseR = 3.0 / (16.0 * kPi) * (1.0 + cosTheta * cosTheta);
    float g2 = g * g;
    float phaseM = (1.0 - g2) / (4.0 * kPi * pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5));

    float cosZenith = max(dir.y, -0.02);
    float zenithDeg = degrees(acos(clamp(cosZenith, -1.0, 1.0)));
    float airmass = 1.0 / (cosZenith + 0.50572 * pow(96.07995 - zenithDeg, -1.6364));

    vec3 extinction = exp(-(betaR + betaM) * airmass);
    vec3 inscatter = (betaR * phaseR + betaM * phaseM) * (1.0 - extinction) / max(betaR + betaM, 1e-6);
    return sunColor * inscatter;
}

vec3 hemisphericAmbient(vec3 N) {
    vec3 sunDir = normalize(-ubo.lightDir);
    vec3 skyColor = atmosphereColor(vec3(0.0, 1.0, 0.0), sunDir, ubo.lightColor);
    const vec3 kGroundAlbedo = vec3(0.30, 0.28, 0.22);
    vec3 groundColor = skyColor * kGroundAlbedo * 0.5;
    return mix(groundColor, skyColor, dot(N, vec3(0.0, 1.0, 0.0)) * 0.5 + 0.5);
}

vec3 sampleEnvironment(vec3 N, vec3 V, vec3 albedo, vec3 F0, float roughness, float metallic) {
    vec3 diffuseIBL = hemisphericAmbient(N) * albedo * (1.0 - metallic);

    vec3 R = reflect(-V, N);
    vec3 prefiltered = textureLod(envMap, R, roughness * kMaxEnvLod).rgb;
    float NdotV = max(dot(N, V), 0.0);
    vec2 brdf = envBRDFApprox(NdotV, roughness);
    vec3 specularIBL = prefiltered * (F0 * brdf.x + brdf.y) * ubo.envBrightnessCorrection;

    return diffuseIBL + specularIBL;
}

// Identical to shader.frag's interleavedGradientNoise() -- see its comment
// there for why the PCF taps below need a per-pixel rotation, not just a
// fixed one.
float interleavedGradientNoise(vec2 screenPos) {
    return fract(52.9829189 * fract(dot(screenPos, vec2(0.06711056, 0.00583715))));
}

// Identical to shader.frag's viewSpaceDepth()/selectCascade() -- see their
// comments there.
float viewSpaceDepth(vec3 worldPos) {
    return -(ubo.view * vec4(worldPos, 1.0)).z;
}

int selectCascade(float viewDepth) {
    for (int i = 0; i < 3; ++i) {
        if (viewDepth < ubo.cascadeSplitDepths[i]) return i;
    }
    return 3;
}

// Identical to shader.frag's vogelDiskSample()/blockerSearch()/pcfShadow()
// -- see their comments there.
vec2 vogelDiskSample(int i, int count, float phi) {
    const float kGoldenAngle = 2.39996323;
    float r = sqrt((float(i) + 0.5) / float(count));
    float theta = float(i) * kGoldenAngle + phi;
    return r * vec2(cos(theta), sin(theta));
}

const int kMaxPcssBlockerTaps = 16;
const int kMaxPcssPcfTaps = 32;

vec2 blockerSearch(vec2 shadowUV, float layer, float compareDepth, float searchRadiusTexels, int numTaps, float phi) {
    vec2 texelSize = 1.0 / vec2(kShadowMapSize);
    float blockerSum = 0.0;
    float blockerCount = 0.0;
    for (int i = 0; i < kMaxPcssBlockerTaps; ++i) {
        if (i >= numTaps) break;
        vec2 uv = shadowUV + vogelDiskSample(i, numTaps, phi) * searchRadiusTexels * texelSize;
        float depth = texture(shadowMapRaw, vec3(uv, layer)).r;
        if (depth < compareDepth) {
            blockerSum += depth;
            blockerCount += 1.0;
        }
    }
    return vec2(blockerCount > 0.0 ? blockerSum / blockerCount : 0.0, blockerCount);
}

float pcfShadow(vec2 shadowUV, float layer, float compareDepth) {
    vec2 texelSize = 1.0 / vec2(kShadowMapSize);
    float noiseAngle = interleavedGradientNoise(gl_FragCoord.xy) * 6.2831853;

    if (ubo.pcssEnabled == 0) {
        const vec2 kRotatedTaps[8] = vec2[](
            vec2(-1.5, 0.5), vec2(0.5, 1.5), vec2(1.5, -0.5), vec2(-0.5, -1.5),
            vec2(-2.5, -1.0), vec2(-1.0, 2.5), vec2(2.5, 1.0), vec2(1.0, -2.5)
        );
        float sinA = sin(noiseAngle);
        float cosA = cos(noiseAngle);
        mat2 tapRotation = mat2(cosA, sinA, -sinA, cosA);
        float shadow = 0.0;
        for (int i = 0; i < 8; ++i) {
            vec2 uv = shadowUV + (tapRotation * kRotatedTaps[i]) * texelSize;
            shadow += texture(shadowMap, vec4(uv, layer, compareDepth));
        }
        return shadow / 8.0;
    }

    float q = clamp(ubo.pcssQuality, 0.0, 100.0) / 100.0;
    int blockerTaps = int(mix(6.0, float(kMaxPcssBlockerTaps), q));
    int pcfTaps = int(mix(14.0, float(kMaxPcssPcfTaps), q));
    const float kBlockerSearchRadiusTexels = 5.0;

    vec2 blockerResult = blockerSearch(shadowUV, layer, compareDepth, kBlockerSearchRadiusTexels, blockerTaps, noiseAngle);
    if (blockerResult.y < 1.0) {
        return 1.0;
    }
    float avgBlockerDepth = blockerResult.x;

    // See shader.frag's identical constants' comment for why
    // kMaxPenumbraTexels is capped modestly (undersampling a wide penumbra
    // reads as grain, not smoothness).
    const float kPenumbraScale = 50000.0;
    const float kMaxPenumbraTexels = 14.0;
    float penumbraTexels = clamp(
        ubo.pcssLightSize * (compareDepth - avgBlockerDepth) * kPenumbraScale,
        1.0, kMaxPenumbraTexels);

    float shadow = 0.0;
    for (int i = 0; i < kMaxPcssPcfTaps; ++i) {
        if (i >= pcfTaps) break;
        vec2 uv = shadowUV + vogelDiskSample(i, pcfTaps, noiseAngle) * penumbraTexels * texelSize;
        shadow += texture(shadowMap, vec4(uv, layer, compareDepth));
    }
    return shadow / float(pcfTaps);
}

// Same idea as shader.frag's sampleCascade(), minus the normal-offset bias:
// this pipeline has never applied one (no geometric normal available at the
// precision that'd need -- see the file comment above on why this is a
// near-duplicate rather than a shared path), same asymmetry as before
// cascades existed.
float sampleCascade(int cascade, vec3 worldPos) {
    vec4 lightClip = ubo.lightViewProj[cascade] * vec4(worldPos, 1.0);
    vec3 lightNDC = lightClip.xyz / lightClip.w;
    if (lightNDC.z < 0.0 || lightNDC.z > 1.0 ||
        lightNDC.x < -1.0 || lightNDC.x > 1.0 || lightNDC.y < -1.0 || lightNDC.y > 1.0) {
        return 1.0;
    }
    vec2 shadowUV = lightNDC.xy * 0.5 + 0.5;
    return pcfShadow(shadowUV, float(cascade), lightNDC.z);
}

// Identical selection/blend scheme as shader.frag's sampleShadow() -- see
// its comments there. Takes worldPos directly (this pipeline has no
// precomputed light-space varying to consume anymore -- cascade selection
// has to happen per-fragment by depth, which shader.vert can't resolve
// early the way it used to for a single fixed lightViewProj).
float sampleShadow(vec3 worldPos) {
    float viewDepth = viewSpaceDepth(worldPos);
    int cascade = selectCascade(viewDepth);
    float shadow = sampleCascade(cascade, worldPos);

    if (cascade < 3) {
        // Wider band + smoothstep easing -- see shader.frag's identical
        // comment for why (a narrow linear blend still reads as an
        // "instant" sharpness pop at the seam).
        float prevSplit = cascade == 0 ? 0.0 : ubo.cascadeSplitDepths[cascade - 1];
        float split = ubo.cascadeSplitDepths[cascade];
        float blendBand = (split - prevSplit) * 0.3;
        float blendStart = split - blendBand;
        if (viewDepth > blendStart) {
            float nextShadow = sampleCascade(cascade + 1, worldPos);
            float t = clamp((viewDepth - blendStart) / max(blendBand, 1e-4), 0.0, 1.0);
            t = t * t * (3.0 - 2.0 * t);
            shadow = mix(shadow, nextShadow, t);
        }
    }
    return shadow;
}

// Identical to shader.frag's cascadeDebugColor()/applyCascadeDebugTint() --
// see their comments there.
vec3 cascadeDebugColor(int cascade) {
    if (cascade == 0) return vec3(1.0, 0.3, 0.3);
    if (cascade == 1) return vec3(0.3, 1.0, 0.3);
    if (cascade == 2) return vec3(0.3, 0.4, 1.0);
    return vec3(1.0, 1.0, 0.3);
}

vec3 applyCascadeDebugTint(vec3 color, vec3 worldPos) {
    if (ubo.shadowDebugVisualizeCascades == 0) {
        return color;
    }
    int cascade = selectCascade(viewSpaceDepth(worldPos));
    return mix(color, cascadeDebugColor(cascade), 0.35);
}

float distributionGGX(vec3 N, vec3 H, float roughness) {
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.0);
    float NdotH2 = NdotH * NdotH;
    float denom = (NdotH2 * (a2 - 1.0) + 1.0);
    return a2 / max(kPi * denom * denom, 1e-6);
}

float geometrySchlickGGX(float NdotV, float roughness) {
    float r = roughness + 1.0;
    float k = (r * r) / 8.0;
    return NdotV / max(NdotV * (1.0 - k) + k, 1e-6);
}

float geometrySmith(float NdotV, float NdotL, float roughness) {
    return geometrySchlickGGX(NdotV, roughness) * geometrySchlickGGX(NdotL, roughness);
}

vec3 fresnelSchlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

// Identical to shader.frag's normalFiltering() (geometric specular AA,
// Toksvig-style normal-derivative variance) -- see its comment there for the
// full reasoning.
float normalFiltering(float perceptualRoughness, vec3 N) {
    vec3 du = dFdx(N);
    vec3 dv = dFdy(N);
    const float kSpecularAAVariance = 0.15;
    const float kSpecularAAThreshold = 0.20;
    float variance = kSpecularAAVariance * (dot(du, du) + dot(dv, dv));

    float alpha = perceptualRoughness * perceptualRoughness;
    float kernelAlpha = min(2.0 * variance, kSpecularAAThreshold);
    float filteredAlphaSquared = clamp(alpha * alpha + kernelAlpha, 0.0, 1.0);
    return sqrt(sqrt(filteredAlphaSquared));
}

// Identical to shader.frag's pointLightsContribution() -- see its comment
// there for the full reasoning (omnidirectional or optional cone, windowed
// inverse-square falloff, no shadow, clustered light lookup instead of
// looping every light in the scene).
vec3 pointLightsContribution(vec3 worldPos, vec3 N, vec3 V, vec3 albedo, vec3 F0, float roughness, float metallic) {
    vec3 result = vec3(0.0);
    float NdotV = max(dot(N, V), 0.0);

    uint clusterIdx = clusterIndexForFragment(gl_FragCoord.xy, viewSpaceDepth(worldPos));
    ClusterLightGridEntry grid = clusterLightGrid[clusterIdx];
    for (uint gi = 0u; gi < grid.count; ++gi) {
        uint i = clusterLightIndices[grid.offset + gi];
        vec3 toLight = lights[i].posRange.xyz - worldPos;
        float dist = length(toLight);
        vec3 L = toLight / max(dist, 1e-4);
        float NdotL = max(dot(N, L), 0.0);
        if (NdotL <= 0.0) continue;

        float coneFactor = 1.0;
        if (lights[i].coneDir.w > 0.5) {
            float cosAngle = dot(lights[i].coneDir.xyz, -L);
            coneFactor = smoothstep(lights[i].coneAngles.y, lights[i].coneAngles.x, cosAngle);
            if (coneFactor <= 0.0) continue;
        }

        float range = max(lights[i].posRange.w, 0.01);
        float distFactor = 1.0 / max(dist * dist, 0.01);
        float rangeWindow = clamp(1.0 - pow(dist / range, 4.0), 0.0, 1.0);
        distFactor *= rangeWindow * rangeWindow * coneFactor;
        if (distFactor <= 0.0) continue;

        vec3 H = normalize(V + L);
        float NDF = distributionGGX(N, H, roughness);
        float G = geometrySmith(NdotV, NdotL, roughness);
        vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);
        vec3 specular = (NDF * G * F) / max(4.0 * NdotV * NdotL, 1e-4);
        vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);

        vec3 lightColor = lights[i].colorIntensity.rgb * lights[i].colorIntensity.a;
        result += (kD * albedo / kPi + specular) * lightColor * NdotL * distFactor;
    }
    return result;
}

void main() {
    // fragMaterialIndex < 0 (no glTF material) never reaches this pipeline
    // in practice -- materialless primitives always draw as opaque/mask
    // (see materialFor() in recordCommandBuffer) -- but guard anyway rather
    // than assume and index materialBuffer out of range.
    if (fragMaterialIndex < 0) {
        discard;
    }

    Material mat = materialBuffer.materials[fragMaterialIndex];

    vec4 baseColor = mat.baseColorFactor * fragColor;
    if (mat.baseColorTexture >= 0) {
        baseColor *= texture(bindlessTextures[nonuniformEXT(mat.baseColorTexture)], texCoordFor(mat.texCoordSets, 1));
    }

    if (baseColor.a < kZeroAlphaEpsilon) {
        discard;
    }

    // Always the BLEND case -- see the file comment above.
    float outAlpha = baseColor.a;

    float metallic = mat.metallicFactor;
    // ubo.roughnessFloor replaces the old hardcoded 0.04 -- see shader.frag's
    // identical comment.
    float roughness = clamp(mat.roughnessFactor, ubo.roughnessFloor, 1.0);
    if (mat.metallicRoughnessTexture >= 0) {
        vec3 mr = texture(bindlessTextures[nonuniformEXT(mat.metallicRoughnessTexture)], texCoordFor(mat.texCoordSets, 2)).rgb;
        roughness = clamp(mr.g * mat.roughnessFactor, ubo.roughnessFloor, 1.0);
        metallic = mr.b * mat.metallicFactor;
    }

    float faceSign = frontFacingSign();
    vec3 N = normalize(fragNormal) * faceSign;
    if (mat.normalTexture >= 0 && dot(fragTangent.xyz, fragTangent.xyz) > 1e-8) {
        vec3 T = normalize(fragTangent.xyz - N * dot(fragTangent.xyz, N));
        vec3 B = cross(N, T) * (fragTangent.w * faceSign);
        mat3 TBN = mat3(T, B, N);
        vec3 sampledN = texture(bindlessTextures[nonuniformEXT(mat.normalTexture)], texCoordFor(mat.texCoordSets, 4)).rgb * 2.0 - 1.0;
        sampledN.xy *= mat.normalScale;
        N = normalize(TBN * normalize(sampledN));
    }

    // Geometric specular AA -- identical placement/reasoning as shader.frag's
    // main().
    if (ubo.geometricSpecularAAEnabled != 0) {
        roughness = normalFiltering(roughness, N);
        roughness = clamp(roughness, ubo.roughnessFloor, 1.0);
    }

    float occlusion = 1.0;
    if (mat.occlusionTexture >= 0) {
        float ao = texture(bindlessTextures[nonuniformEXT(mat.occlusionTexture)], texCoordFor(mat.texCoordSets, 8)).r;
        occlusion = mix(1.0, ao, mat.occlusionStrength);
    }

    vec3 emissive = mat.emissiveFactor.rgb;
    if (mat.emissiveTexture >= 0) {
        emissive *= texture(bindlessTextures[nonuniformEXT(mat.emissiveTexture)], texCoordFor(mat.texCoordSets, 16)).rgb;
    }

    vec3 V = normalize(ubo.camPos - fragWorldPos);
    vec3 L = normalize(-ubo.lightDir);
    vec3 H = normalize(V + L);

    vec3 albedo = baseColor.rgb;
    vec3 F0 = mix(vec3(0.04), albedo, metallic);

    float NdotL = max(dot(N, L), 0.0);
    float NdotV = max(dot(N, V), 0.0);
    // Hoisted out of the NdotL branch below -- identical to shader.frag's
    // tail of the same name, see its comments there.
    float shadowFactor = sampleShadow(fragWorldPos);

    vec3 lighting = vec3(0.0);
    if (NdotL > 0.0) {
        float NDF = distributionGGX(N, H, roughness);
        float G = geometrySmith(NdotV, NdotL, roughness);
        vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);
        vec3 specular = (NDF * G * F) / max(4.0 * NdotV * NdotL, 1e-4);
        vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);
        lighting = (kD * albedo / kPi + specular) * ubo.lightColor * NdotL * shadowFactor;
    }

    lighting += pointLightsContribution(fragWorldPos, N, V, albedo, F0, roughness, metallic);

    // Identical to shader.frag's foliage translucency term -- see its
    // comments there.
    if (mat.doubleSided != 0 && ubo.foliageTranslucencyStrength > 0.0) {
        const float kTranslucencyDistortion = 0.5;
        const float kTranslucencyPower = 4.0;
        const float kTranslucencyScale = 2.0;
        vec3 transmissionDir = L + N * kTranslucencyDistortion;
        float transmissionDot = pow(clamp(dot(V, -transmissionDir), 0.0, 1.0), kTranslucencyPower);
        lighting += albedo * ubo.lightColor * transmissionDot * kTranslucencyScale
            * shadowFactor * ubo.foliageTranslucencyStrength;
    }

    // Real (if cheap) image-based lighting -- identical to shader.frag's
    // main(), see its comment there.
    vec3 ambientTint = ubo.ambientColorIntensity.rgb * ubo.ambientColorIntensity.a;
    vec2 screenUV = gl_FragCoord.xy / vec2(textureSize(ssaoTexture, 0));
    // Identical to shader.frag's ssaoFactor/ambientN -- see their comments
    // there.
    vec4 ssaoSample = texture(ssaoTexture, screenUV);
    float ssaoFactor = ubo.ssaoEnabled != 0 ? ssaoSample.a : 1.0;
    vec3 ambientN = N;
    if (ubo.ssaoEnabled != 0) {
        vec3 bentView = transpose(mat3(ubo.view)) * ssaoSample.rgb;
        // Guard against normalize(~0), and the 25% damping -- see
        // shader.frag's identical logic for why (blur.frag smooths a
        // direction far less effectively than it smooths AO's scalar, so
        // the raw bent normal is noisier than intended -- this keeps only a
        // hint of it).
        float bentLenSq = dot(bentView, bentView);
        vec3 bentWorld = bentLenSq > 1e-8 ? bentView * inversesqrt(bentLenSq) : N;
        vec3 blended = mix(N, bentWorld, 0.25);
        float blendedLenSq = dot(blended, blended);
        ambientN = blendedLenSq > 1e-8 ? blended * inversesqrt(blendedLenSq) : N;
    }
    vec3 ambient = sampleEnvironment(ambientN, V, albedo, F0, roughness, metallic) * ambientTint * occlusion * ssaoFactor;

    // AO attenuates indirect light only -- see shader.frag's comment on the
    // identical line for why direct lighting doesn't get this multiply.
    // Stays linear HDR, no tonemap -- see shader.frag's comment on the
    // identical point for why: this accumulates into outAccum below in the
    // same linear space pass 1's opaque HDR target is in, so the single
    // final tonemap pass (tonemap.frag) tonemaps both together once,
    // instead of each getting compressed on its own curve before ever
    // being composited.
    // Tunable floor under direct+ambient, before emissive -- identical to
    // shader.frag's main(), see its comment there for the full reasoning.
    vec3 combined = max(ambient + lighting, vec3(ubo.minAmbientFloor)) + emissive;
    vec3 color = applyCascadeDebugTint(combined, fragWorldPos);

    // Weight function from McGuire & Bavoil's reference implementation:
    // favors fragments that are more opaque and closer to the camera (small
    // gl_FragCoord.z), so a nearly-opaque leaf close to the eye dominates
    // the accumulation more than a faint, distant one would -- an
    // approximation (true OIT would need per-fragment sorting), but a
    // well-tested one that avoids the "wrong instance wins" artifacts the
    // old CPU sort had.
    //
    // Clamp bounds scaled down 6x from the reference's [1e-2, 3e3] (to
    // [1/600, 500]), not just capped -- scaling both bounds by the same
    // factor preserves the *ratio* between min and max weight (what
    // actually drives the algorithm's fragment-favoring behavior)
    // identically to the original, just at a smaller absolute scale.
    // That headroom is what outAccum below needs now: this pipeline used
    // to tonemap color to [0,1] before this multiply (inline Reinhard, now
    // removed -- see this file's comment on the identical point), so the
    // original 3e3 ceiling times a ~1.0 color comfortably fit
    // R16G16B16A16_SFLOAT's ~65504 max. color is unclamped linear HDR now,
    // and a bright emissive/specular BLEND fragment (a stained-glass lamp
    // shade, a neon sign behind glass) can easily exceed 1.0 by 100x or
    // more -- at the old 3e3 ceiling, color=100 alone would push
    // outAccum.rgb to 3e5, past fp16's finite range into +Inf, which then
    // propagates through the composite's weighted average (a guard there
    // catches outright Inf/NaN, but its fallback -- averaging to white --
    // is exactly the "white garbage" this is meant to prevent in the first
    // place) and can reach the final tonemap pass as Inf/NaN too.
    float weight = clamp(
        pow(min(1.0, outAlpha * 10.0) + 0.01, 3.0) * 1e8 * pow(1.0 - gl_FragCoord.z * 0.9, 3.0),
        1.0 / 600.0, 500.0);

    // Clamped to 100 -- chosen alongside the weight rescale above so the
    // worst case (outAlpha=1, weight=500) tops out at 100*500=50000,
    // comfortably under fp16's ~65504 ceiling with room to spare. This
    // still lets translucent emissive/specular content read as genuinely
    // bright (100x a diffuse albedo of 1.0) up through the final ACES
    // tonemap, just not literally unbounded.
    vec3 accumColor = min(color, vec3(100.0));

    outAccum = vec4(accumColor * outAlpha, outAlpha) * weight;
    outReveal = outAlpha;
}
