#version 450

// Reflective Shadow Map raster pass -- renders the scene from the sun's
// point of view (same basic idea as shadow.vert) but into TWO extra color
// attachments (world normal, outgoing flux -- see rsm.frag) instead of
// depth-only, so rsm_gather.comp can later treat every RSM texel as a
// virtual point light bouncing indirect light back into the main scene. A
// completely separate, lower-resolution, non-cascaded render from the real
// shadow map -- see createRSMResources' comment (VulkanResources.cpp) for
// why the shadow pass's own pipeline/render targets can't just grow extra
// attachments (depth-only is baked deep into its setup, shared with the
// real cascades nothing else needs a fragment shader for).
//
// rsmViewProj arrives as a push constant, not a UBO field, purely because
// nothing else needs it broadly enough to be worth the "every consumer has
// to mirror the whole UBO prefix up to it" cost std140's append-only layout
// would otherwise impose (see UniformBufferObject's own comment,
// VulkanTypes.h) -- same reasoning shadow.vert's own ShadowPushConstants
// already established for cascadeIndex. Own dedicated pipeline layout
// (rsmPipelineLayout, VulkanPipeline.cpp) rather than reusing the shared
// one, since that one's push constant range is already fixed to
// ShadowPushConstants{cascadeIndex} -- a mat4 doesn't fit that shape.
layout(push_constant) uniform RSMPushConstants {
    mat4 rsmViewProj;
} pc;

// Identical to shader.vert/shadow.vert's own InstanceData/InstanceBuffer --
// see shadow.vert's comment for why the full field list (not just model)
// has to be repeated even though this stage only reads .model/materialIndex:
// an SSBO array's element stride is derived from this struct's own declared
// layout, so a shorter declaration would make instances[] index with the
// wrong stride.
struct InstanceData {
    mat4 model;
    vec4 normalMatrixCol0;
    vec4 normalMatrixCol1;
    vec4 normalMatrixCol2;
    int materialIndex;
    int pad0;
    int pad1;
    int pad2;
};

layout(std430, binding = 3) readonly buffer InstanceBuffer {
    InstanceData instances[];
} instanceBuffer;

layout(location = 0) in vec3 inPosition;
layout(location = 1) in vec4 inNormal;
layout(location = 2) in vec2 inUV;
layout(location = 3) in vec4 inTangent; // unused, see shadow.vert's identical comment on inUV/inTangent
layout(location = 4) in vec4 inColor;
layout(location = 5) in vec2 inUV2;

layout(location = 0) out vec2 fragUV;
layout(location = 1) flat out int fragMaterialIndex;
layout(location = 2) out vec4 fragColor;
layout(location = 3) out vec2 fragUV2;
// WORLD-space normal (not view-space like depth_prepass.vert's own
// fragViewNormal) -- rsm.frag both writes this straight into the RSM normal
// G-buffer and uses it directly to compute NdotL against ubo.lightDir,
// which is itself a world-space direction.
layout(location = 4) out vec3 fragWorldNormal;

void main() {
    InstanceData inst = instanceBuffer.instances[gl_InstanceIndex];
    gl_Position = pc.rsmViewProj * (inst.model * vec4(inPosition, 1.0));

    fragUV = inUV;
    fragUV2 = inUV2;
    fragMaterialIndex = inst.materialIndex;
    fragColor = inColor;

    mat3 normalMatrix = mat3(inst.normalMatrixCol0.xyz, inst.normalMatrixCol1.xyz, inst.normalMatrixCol2.xyz);
    fragWorldNormal = normalize(normalMatrix * inNormal.xyz);
}
