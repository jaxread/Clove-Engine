// ============================================================================
// rt_reflections.glsl -- Phase 3: trace one reflection ray and re-shade the hit.
//
// Forward-native (called from shader.frag where material params already exist).
// On hit: fetch the surface (rt_surface.glsl), evaluate the sun with an RT
// shadow ray at the hit (rt_shadows.glsl), plus a small ambient. On miss:
// sample the sky/environment. Returns incoming reflected radiance to add into
// the specular term.
//
// Requires (in the including shader), in addition to rt_surface/rt_shadows/
// pbr_brdf includes and their bindings:
//   layout(set = 2, binding = 0) uniform accelerationStructureEXT rtTLAS;
//   a way to sample the sky on miss (envMap) -- passed in as a helper result.
//
// First-cut shading simplification (documented in PHASE3_NOTES.md): the hit is
// lit by the sun (shadowed) + ambient using vertex color as an albedo proxy;
// full material/texture fetch at the hit is a later refinement.
// ============================================================================

#ifndef RT_REFLECTIONS_GLSL
#define RT_REFLECTIONS_GLSL

// sunDir points TOWARD the sun; sunColor is its radiance. skyColor is the
// environment sample to use on a miss (caller supplies, e.g. from envMap).
vec3 rtTraceReflection(vec3 worldPos, vec3 N, vec3 V,
                       vec3 sunDir, vec3 sunColor, vec3 ambient, vec3 skyColor) {
    vec3 R = reflect(-V, N);
    vec3 origin = worldPos + N * 0.02;   // avoid self-hit

    rayQueryEXT rq;
    rayQueryInitializeEXT(rq, rtTLAS, gl_RayFlagsOpaqueEXT, 0xFF,
                          origin, 0.001, R, 10000.0);
    rayQueryProceedEXT(rq);

    if (rayQueryGetIntersectionTypeEXT(rq, true) ==
        gl_RayQueryCommittedIntersectionNoneEXT) {
        return skyColor; // miss -> environment
    }

    HitSurface hit = fetchHitSurface(rq, origin, R);

    // Simple metallic-roughness stand-in for the hit material (first cut).
    vec3  albedo    = hit.vColor.rgb;
    float roughness = 0.6;
    float metallic  = 0.0;
    vec3  F0        = mix(vec3(0.04), albedo, metallic);

    // Sun with an RT shadow ray from the hit (reuses rt_shadows.glsl).
    vec3 Nh = hit.worldNormal;
    vec3 Vh = -R; // view at the hit is back along the reflection ray
    float sunVis = rtSunShadowHard(hit.worldPos, Nh, sunDir);
    vec3 direct = evaluateDirectLight(Nh, Vh, sunDir, sunColor * sunVis,
                                      albedo, F0, roughness, metallic);

    return direct + ambient * albedo;
}

#endif // RT_REFLECTIONS_GLSL
