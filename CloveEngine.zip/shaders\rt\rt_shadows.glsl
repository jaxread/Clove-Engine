// ============================================================================
// rt_shadows.glsl -- Phase 2: ray-query sun shadow for the forward shader.
//
// Included by shader.frag. Traces a shadow ray from the shaded surface toward
// the sun through the TLAS; returns 1.0 = lit, 0.0 = shadowed. This is the
// forward-native approach (no separate pass / G-buffer reconstruction): the ray
// query runs right in the fragment shader where the surface data already exists.
//
// Requirements in the including shader:
//   #extension GL_EXT_ray_query : require
//   layout(set = 2, binding = 0) uniform accelerationStructureEXT rtTLAS;
// and the TLAS descriptor bound (see INTEGRATION_NOTES.md, "Descriptor set 2").
//
// No denoising here -- a single hard shadow ray. Soft penumbra + denoise is a
// Phase 5 concern; jittered multi-ray is sketched at the bottom for when you
// want cheap softening before the denoiser lands.
// ============================================================================

#ifndef RT_SHADOWS_GLSL
#define RT_SHADOWS_GLSL

// Hard shadow: 1.0 lit, 0.0 occluded.
// worldPos    : shaded surface position (fragWorldPos)
// worldNormal : shaded surface normal   (normalize(fragNormal)) -- for offset
// lightDir    : normalized direction TOWARD the light (sun)
float rtSunShadowHard(vec3 worldPos, vec3 worldNormal, vec3 lightDir) {
    // Offset along the normal to avoid self-intersection (shadow acne). Scale
    // by a small epsilon; increase if acne appears on grazing surfaces.
    const float kNormalBias = 0.02;
    vec3 origin = worldPos + worldNormal * kNormalBias;

    rayQueryEXT rq;
    // Opaque + terminate on first hit: we only need "is anything in the way".
    rayQueryInitializeEXT(rq, rtTLAS,
        gl_RayFlagsTerminateOnFirstHitEXT | gl_RayFlagsOpaqueEXT,
        0xFF,                 // cull mask -- matches instance mask 0xFF
        origin, 0.001,        // tMin
        lightDir, 10000.0);   // tMax -- sun is effectively at infinity

    rayQueryProceedEXT(rq);

    // Any committed hit => occluded.
    if (rayQueryGetIntersectionTypeEXT(rq, true) != gl_RayQueryCommittedIntersectionNoneEXT)
        return 0.0;
    return 1.0;
}

// Optional cheap softening: average N jittered rays inside a small cone around
// the light direction. Call this instead of the hard version for a soft edge
// before you have NRD. `tangentJitter` should be two orthonormal vectors
// spanning the plane perpendicular to lightDir; `rand2` a per-pixel [0,1)^2.
float rtSunShadowSoft(vec3 worldPos, vec3 worldNormal, vec3 lightDir,
                      vec3 tU, vec3 tV, float coneRadius, int samples, vec2 rand2) {
    float lit = 0.0;
    for (int i = 0; i < samples; ++i) {
        // Cheap stratified-ish offset; replace rand2 rotation per sample as needed.
        float a = 6.2831853 * fract(rand2.x + float(i) * 0.61803399);
        float r = coneRadius * sqrt(fract(rand2.y + float(i) * 0.7548777));
        vec3 dir = normalize(lightDir + (cos(a) * r) * tU + (sin(a) * r) * tV);
        lit += rtSunShadowHard(worldPos, worldNormal, dir);
    }
    return lit / float(max(samples, 1));
}

// Phase 5 (NRD SIGMA_SHADOW): same hard shadow ray as rtSunShadowHard above,
// but returns the raw hit distance instead of a collapsed 0/1 -- SIGMA's own
// packing (SIGMA_FrontEnd_PackPenumbra, NRD.hlsli, ported to GLSL in
// rt_shadow_trace.frag) needs the actual occluder distance to size the
// penumbra, not just lit/shadowed. Returns a very large sentinel (matching
// NRD_FP16_MAX, see that pack function's own comment) when nothing is hit --
// SIGMA_FrontEnd_PackPenumbra checks `distanceToOccluder >= NRD_FP16_MAX` to
// mean "fully lit".
float rtSunShadowDistance(vec3 worldPos, vec3 worldNormal, vec3 lightDir) {
    const float kNormalBias = 0.02;
    const float kNrdFp16Max = 65504.0;
    vec3 origin = worldPos + worldNormal * kNormalBias;

    rayQueryEXT rq;
    rayQueryInitializeEXT(rq, rtTLAS,
        gl_RayFlagsTerminateOnFirstHitEXT | gl_RayFlagsOpaqueEXT,
        0xFF,
        origin, 0.001,
        lightDir, 10000.0);

    rayQueryProceedEXT(rq);

    if (rayQueryGetIntersectionTypeEXT(rq, true) == gl_RayQueryCommittedIntersectionNoneEXT)
        return kNrdFp16Max;
    return rayQueryGetIntersectionTEXT(rq, true);
}

#endif // RT_SHADOWS_GLSL
